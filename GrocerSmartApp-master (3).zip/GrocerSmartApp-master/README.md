# GrocerSmart 👋

A professional full-stack Inventory Management and Point-of-Sale (POS) system for modern retailers. Built with **Node.js**, **Express**, and **MongoDB** on the backend, and **React Native (Expo)** on the frontend.

## 📁 Project Structure

This repository is organized into two main parts:

- **`/frontend`**: The mobile application built with Expo and React Native. Includes POS, Inventory, Suppliers, and Analytics modules.
- **`/backend`**: The REST API built with Node.js and Express. Handles authentication, database logic, and financial calculations.

## 🚀 Getting Started

### 1. Backend Setup
Navigate to the backend directory and install dependencies:
```bash
cd backend
npm install
```
Create a `.env` file in the `/backend` folder with your MongoDB URI and JWT Secret. Then start the server:
```bash
npm start
```

### 2. Frontend Setup
Navigate to the frontend directory and install dependencies:
```bash
cd frontend
npm install
```
Start the Expo development server:
```bash
npx expo start
```

## ✨ Key Features

- **POS Module**: Direct keyboard input for quantities, searchable product selection, and transaction history.
- **Inventory Management**: Real-time stock tracking, conversion of bulk items to units, and supplier associations.
- **Financial Analytics**: Sales targets, expense tracking, and performance dashboards.
- **Role-Based Access**: Granular permissions for Admin, Manager, and Cashier roles.
- **Secure Sessions**: Persistent login and data security using `expo-secure-store`.

## 🛠 Tech Stack

- **Frontend**: React Native, Expo Router, Ionicons.
- **Backend**: Node.js, Express.js, JWT Authentication.
- **Database**: MongoDB (Mongoose).
- **Styling**: Premium custom UI components.

## 📄 License
This project is for private use by GrocerSmart.
