import { createContext, useContext, useState } from 'react';

type Order = {
  id: string;
  customer: string;
  product: string;
  quantity: string;
  price: string;
  notes?: string;
};

type OrderContextType = {
  orders: Order[];
  addOrder: (order: Order) => void;
  deleteOrder: (id: string) => void;
  updateOrder: (order: Order) => void; // 🔥 added
};

const OrderContext = createContext<OrderContextType | undefined>(undefined);

export const OrderProvider = ({ children }: any) => {
  const [orders, setOrders] = useState<Order[]>([]);

  const addOrder = (order: Order) => {
    setOrders((prev) => [...prev, order]);
  };

  const deleteOrder = (id: string) => {
    setOrders((prev) => prev.filter((o) => o.id !== id));
  };

  // 🔥 NEW FUNCTION
  const updateOrder = (updatedOrder: Order) => {
    setOrders((prev) =>
      prev.map((o) => (o.id === updatedOrder.id ? updatedOrder : o))
    );
  };

  return (
    <OrderContext.Provider
      value={{ orders, addOrder, deleteOrder, updateOrder }}
    >
      {children}
    </OrderContext.Provider>
  );
};

export const useOrders = () => {
  const context = useContext(OrderContext);
  if (!context) throw new Error('useOrders must be used inside OrderProvider');
  return context;
};