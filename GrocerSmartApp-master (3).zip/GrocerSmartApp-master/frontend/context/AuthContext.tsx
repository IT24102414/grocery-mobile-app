import { BASE_URL, setAuthToken } from "@/services/api";
import {
    createContext,
    ReactNode,
    useContext,
    useEffect,
    useMemo,
    useState,
} from "react";
import * as SecureStore from "expo-secure-store";

type AuthUser = {
  id?: string;
  username: string;
  displayName: string;
  role?: string;
};

type SignInPayload = {
  username: string;
  password: string;
};

type AuthContextValue = {
  user: AuthUser | null;
  token: string | null;
  isAuthenticated: boolean;
  signIn: (payload: SignInPayload) => Promise<void>;
  signOut: () => void;
};

type StoredSession = {
  user: AuthUser | null;
  token: string | null;
};

const STORAGE_KEY = "grocersmart.auth.session";

async function readStoredSession(): Promise<StoredSession> {
  try {
    const raw = await SecureStore.getItemAsync(STORAGE_KEY);
    if (!raw) return { user: null, token: null };
    const parsed = JSON.parse(raw) as Partial<StoredSession>;
    return {
      user: parsed.user ?? null,
      token: parsed.token ?? null,
    };
  } catch {
    return { user: null, token: null };
  }
}

async function storeSession(session: StoredSession) {
  setAuthToken(session.token);
  if (!session.user || !session.token) {
    await SecureStore.deleteItemAsync(STORAGE_KEY);
    return;
  }
  await SecureStore.setItemAsync(STORAGE_KEY, JSON.stringify(session));
}

const AuthContext = createContext<AuthContextValue | undefined>(undefined);

export function AuthProvider({ children }: { children: ReactNode }) {
  const [user, setUser] = useState<AuthUser | null>(null);
  const [token, setToken] = useState<string | null>(null);

  useEffect(() => {
    const init = async () => {
      const stored = await readStoredSession();
      setUser(stored.user);
      setToken(stored.token);
    };
    init();
  }, []);

  useEffect(() => {
    setAuthToken(token);
  }, [token]);

  const signIn = async ({ username, password }: SignInPayload) => {
    const trimmedUsername = username.trim();
    const trimmedPassword = password.trim();

    if (!trimmedUsername || !trimmedPassword) {
      throw new Error("Enter a username and password.");
    }

    try {
      const response = await fetch(`${BASE_URL}/auth/login`, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          username: trimmedUsername,
          password: trimmedPassword,
        }),
      });

      if (response.ok) {
        const payload = await response.json();
        const sessionData = payload?.data ?? payload;
        const authenticatedUser = sessionData?.user ?? sessionData;
        const nextToken = sessionData?.token ?? null;

        const nextUser = {
          id: String(authenticatedUser?._id || authenticatedUser?.id || ""),
          username: authenticatedUser?.username ?? trimmedUsername,
          displayName:
            authenticatedUser?.fullName ??
            authenticatedUser?.displayName ??
            authenticatedUser?.username ??
            trimmedUsername,
          role: authenticatedUser?.role ?? "CASHIER",
        };

        setUser(nextUser);
        setToken(nextToken);
        await storeSession({ user: nextUser, token: nextToken });
        return;
      }

      if (response.status === 404) {
        const nextUser = {
          username: trimmedUsername,
          displayName: trimmedUsername,
        };

        setUser(nextUser);
        setToken(null);
        await storeSession({ user: nextUser, token: null });
        return;
      }

      const message = await response.text();
      throw new Error(message || "Login failed.");
    } catch (error) {
      if (
        !(error instanceof TypeError) &&
        !(
          error instanceof Error &&
          /Network request failed/i.test(error.message)
        )
      ) {
        throw error;
      }

      const nextUser = {
        username: trimmedUsername,
        displayName: trimmedUsername,
      };

      setUser(nextUser);
      setToken(null);
      await storeSession({ user: nextUser, token: null });
    }
  };

  const signOut = async () => {
    setUser(null);
    setToken(null);
    await storeSession({ user: null, token: null });
  };

  const value = useMemo(
    () => ({
      user,
      token,
      isAuthenticated: user !== null,
      signIn,
      signOut,
    }),
    [token, user],
  );

  return <AuthContext.Provider value={value}>{children}</AuthContext.Provider>;
}

export function useAuth() {
  const context = useContext(AuthContext);

  if (!context) {
    throw new Error("useAuth must be used inside an AuthProvider.");
  }

  return context;
}
