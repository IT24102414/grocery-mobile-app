import { dashboardCards } from "@/constants/modules";
import { getResource, getResourceList } from "@/services/api";
import { useEffect, useMemo, useState } from "react";
import { Alert, ScrollView, StyleSheet, Text, View } from "react-native";

type RecordShape = Record<string, unknown>;

function toNumber(value: unknown) {
  const parsed = Number(value ?? 0);
  return Number.isFinite(parsed) ? parsed : 0;
}

function toText(value: unknown) {
  return String(value ?? "")
    .trim()
    .toLowerCase();
}

export function AnalyticsPanel() {
  const [loading, setLoading] = useState(true);
  const [data, setData] = useState<Record<string, RecordShape[]>>({});
  const [summary, setSummary] = useState<Record<string, RecordShape | null>>(
    {},
  );

  useEffect(() => {
    const load = async () => {
      try {
        setLoading(true);
        const [
          products,
          orders,
          creditCustomers,
          suppliers,
          cheques,
          salesSummary,
          inventorySummary,
        ] = await Promise.all([
          getResourceList<RecordShape>("/products"),
          getResourceList<RecordShape>("/orders"),
          getResourceList<RecordShape>("/credit-customers"),
          getResourceList<RecordShape>("/suppliers"),
          getResourceList<RecordShape>("/cheques"),
          getResource("/reports/sales"),
          getResource("/reports/inventory"),
        ]);

        setData({
          inventory: products,
          pos: orders,
          "credit-customers": creditCustomers,
          suppliers,
          cheques,
        });

        setSummary({
          sales: salesSummary,
          inventory: inventorySummary,
        });
      } catch (error) {
        Alert.alert(
          "Analytics failed",
          error instanceof Error ? error.message : "Please try again.",
        );
      } finally {
        setLoading(false);
      }
    };

    load();
  }, []);

  const metrics = useMemo(() => {
    const posRecords = data.pos ?? [];
    const inventoryRecords = data.inventory ?? [];
    const chequeRecords = data.cheques ?? [];
    const creditRecords = data["credit-customers"] ?? [];
    const supplierRecords = data.suppliers ?? [];

    const salesSummary = summary.sales;
    const inventorySummary = summary.inventory;

    const salesTotal =
      toNumber(
        (salesSummary as Record<string, unknown> | null)?.totalSales ??
          (salesSummary as Record<string, unknown> | null)?.totalAmount,
      ) ||
      posRecords.reduce(
        (sum, record) => sum + toNumber(record.totalAmount ?? record.amount),
        0,
      );

    const inventoryValue = inventoryRecords.reduce(
      (sum, record) =>
        sum +
        toNumber(
          record.stockLevels
            ? (record.stockLevels as Record<string, unknown>).bulkQty
            : record.quantity,
        ) *
          toNumber(record.unitCost ?? record.purchasePrice),
      0,
    );

    const pendingCheques = chequeRecords.filter(
      (record) => !["cleared", "paid"].includes(toText(record.status)),
    );
    const pendingChequeValue = pendingCheques.reduce(
      (sum, record) => sum + toNumber(record.amount),
      0,
    );
    const creditOutstanding = creditRecords.reduce(
      (sum, record) => sum + toNumber(record.currentBalance ?? record.balance),
      0,
    );
    const lowStockItems = inventoryRecords.filter(
      (record) =>
        toNumber(
          (record.stockLevels as Record<string, unknown> | undefined)
            ?.bulkQty ?? 0,
        ) +
          toNumber(
            (record.stockLevels as Record<string, unknown> | undefined)
              ?.retailQty ?? 0,
          ) <=
        toNumber(record.reorderPoint ?? 0),
    );
    const activeSuppliers = supplierRecords.filter((record) =>
      ["active", "onboarding", "approved"].includes(toText(record.status)),
    );

    return [
      {
        label: "POS sales",
        value: salesTotal.toLocaleString(),
        caption: `${posRecords.length} transactions`,
      },
      {
        label: "Inventory value",
        value: inventoryValue.toLocaleString(),
        caption: `${inventoryRecords.length} products`,
      },
      {
        label: "Pending cheques",
        value: pendingChequeValue.toLocaleString(),
        caption: `${pendingCheques.length} records`,
      },
      {
        label: "Credit balance",
        value: creditOutstanding.toLocaleString(),
        caption: `${creditRecords.length} customers`,
      },
      {
        label: "Low stock",
        value: String(lowStockItems.length),
        caption: "Items need replenishment",
      },
      {
        label: "Suppliers",
        value: String(activeSuppliers.length),
        caption: `${supplierRecords.length} total vendors`,
      },
      {
        label: "Inventory summary",
        value: String(
          (inventorySummary as Record<string, unknown> | null)?.totalProducts ??
            inventoryRecords.length,
        ),
        caption: "Live backend summary",
      },
    ];
  }, [data, summary]);

  return (
    <ScrollView contentContainerStyle={styles.container}>
      <View style={styles.hero}>
        <Text style={styles.kicker}>ANALYTICS</Text>
        <Text style={styles.title}>Operational overview</Text>
        <Text style={styles.description}>
          Metrics are calculated from the live records returned by the connected
          backend.
        </Text>
      </View>

      {loading ? (
        <View style={styles.loadingBox}>
          <Text style={styles.loadingText}>Loading analytics...</Text>
        </View>
      ) : (
        <View style={styles.grid}>
          {metrics.map((metric) => (
            <View key={metric.label} style={styles.metricCard}>
              <Text style={styles.metricLabel}>{metric.label}</Text>
              <Text style={styles.metricValue}>{metric.value}</Text>
              <Text style={styles.metricCaption}>{metric.caption}</Text>
            </View>
          ))}
        </View>
      )}

      <View style={styles.moduleRail}>
        <Text style={styles.railTitle}>Modules</Text>
        <View style={styles.railList}>
          {dashboardCards.map((card) => (
            <View key={card.key} style={styles.railCard}>
              <Text style={styles.railCardTitle}>{card.title}</Text>
              <Text style={styles.railCardDescription}>{card.description}</Text>
            </View>
          ))}
        </View>
      </View>
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: {
    padding: 16,
    backgroundColor: "#f4f7fb",
    gap: 16,
  },
  hero: {
    backgroundColor: "#0f172a",
    borderRadius: 28,
    padding: 20,
  },
  kicker: {
    color: "#93c5fd",
    fontSize: 11,
    letterSpacing: 1.2,
    marginBottom: 6,
  },
  title: {
    color: "#ffffff",
    fontSize: 28,
    fontWeight: "800",
  },
  description: {
    color: "#cbd5e1",
    marginTop: 8,
  },
  loadingBox: {
    paddingVertical: 48,
    alignItems: "center",
  },
  loadingText: {
    color: "#475569",
  },
  grid: {
    flexDirection: "row",
    flexWrap: "wrap",
    gap: 12,
  },
  metricCard: {
    width: "48%",
    backgroundColor: "#ffffff",
    borderRadius: 22,
    padding: 16,
    shadowColor: "#0f172a",
    shadowOpacity: 0.05,
    shadowRadius: 14,
    elevation: 2,
  },
  metricLabel: {
    color: "#64748b",
    fontSize: 12,
    marginBottom: 10,
  },
  metricValue: {
    fontSize: 24,
    fontWeight: "800",
    color: "#0f172a",
  },
  metricCaption: {
    marginTop: 8,
    color: "#475569",
  },
  moduleRail: {
    backgroundColor: "#ffffff",
    borderRadius: 24,
    padding: 18,
  },
  railTitle: {
    fontWeight: "800",
    fontSize: 16,
    color: "#0f172a",
    marginBottom: 12,
  },
  railList: {
    gap: 12,
  },
  railCard: {
    borderRadius: 18,
    padding: 14,
    backgroundColor: "#f8fafc",
  },
  railCardTitle: {
    fontWeight: "700",
    color: "#0f172a",
    marginBottom: 4,
  },
  railCardDescription: {
    color: "#64748b",
  },
});
