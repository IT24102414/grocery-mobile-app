import { createResource, getResourceList } from "@/services/api";
import { Picker } from "@react-native-picker/picker";
import { useEffect, useMemo, useState } from "react";
import {
    Alert,
    Pressable,
    ScrollView,
    StyleSheet,
    Text,
    TextInput,
    View,
} from "react-native";

type ProductRecord = Record<string, unknown> & { id?: string; _id?: string };

type ItemRow = {
  productId: string;
  qty: string;
  unitPrice: string;
  discount: string;
};

export function PosManager() {
  const [products, setProducts] = useState<ProductRecord[]>([]);
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [invoiceNo, setInvoiceNo] = useState("");
  const [paymentType, setPaymentType] = useState("CASH");
  const [customerId, setCustomerId] = useState("");
  const [note, setNote] = useState("");
  const [items, setItems] = useState<ItemRow[]>([
    { productId: "", qty: "1", unitPrice: "0", discount: "0" },
  ]);

  const loadProducts = async () => {
    setLoading(true);
    const productData = await getResourceList<ProductRecord>("/products");
    setProducts(productData);
    setLoading(false);
  };

  useEffect(() => {
    loadProducts();
  }, []);

  const updateItem = (index: number, key: keyof ItemRow, value: string) => {
    setItems((current) =>
      current.map((item, itemIndex) =>
        itemIndex === index ? { ...item, [key]: value } : item,
      ),
    );
  };

  const addItem = () => {
    setItems((current) => [
      ...current,
      { productId: "", qty: "1", unitPrice: "0", discount: "0" },
    ]);
  };

  const removeItem = (index: number) => {
    setItems((current) =>
      current.filter((_, itemIndex) => itemIndex !== index),
    );
  };

  const onChooseProduct = (index: number, productId: string) => {
    const product =
      products.find((item) => String(item.id ?? item._id) === productId) ??
      null;
    const nextPrice = Number(product?.unitPrice ?? 0);

    setItems((current) =>
      current.map((item, itemIndex) =>
        itemIndex === index
          ? {
              ...item,
              productId,
              unitPrice: String(nextPrice || item.unitPrice || "0"),
            }
          : item,
      ),
    );
  };

  const totalAmount = useMemo(
    () =>
      items.reduce(
        (sum, item) =>
          sum +
          Number(item.qty || 0) * Number(item.unitPrice || 0) -
          Number(item.discount || 0),
        0,
      ),
    [items],
  );

  const submit = async () => {
    const normalizedItems = items
      .filter((item) => item.productId)
      .map((item) => ({
        productId: item.productId,
        qty: Number(item.qty || 0),
        unitPrice: Number(item.unitPrice || 0),
        discount: Number(item.discount || 0),
      }));

    if (normalizedItems.length === 0) {
      Alert.alert("Missing items", "Add at least one product.");
      return;
    }

    if (paymentType.toUpperCase() === "CREDIT" && !customerId.trim()) {
      Alert.alert("Missing customer", "Credit sales require a customer ID.");
      return;
    }

    try {
      setSaving(true);
      await createResource("/orders", {
        invoiceNo: invoiceNo.trim() || undefined,
        paymentType: paymentType.toUpperCase(),
        customerId: customerId.trim() || undefined,
        creditCustomerId: customerId.trim() || undefined,
        note: note.trim() || undefined,
        items: normalizedItems,
      });

      setInvoiceNo("");
      setPaymentType("CASH");
      setCustomerId("");
      setNote("");
      setItems([{ productId: "", qty: "1", unitPrice: "0", discount: "0" }]);
      await loadProducts();
    } catch (error) {
      Alert.alert(
        "Save failed",
        error instanceof Error ? error.message : "Please try again.",
      );
    } finally {
      setSaving(false);
    }
  };

  return (
    <View style={styles.screen}>
      <View style={styles.header}>
        <View>
          <Text style={styles.kicker}>POINT OF SALE</Text>
          <Text style={styles.title}>New sale</Text>
          <Text style={styles.description}>
            Create sales, bill walk-ins, and record credit sales against
            customers.
          </Text>
        </View>
        <Pressable style={styles.reloadButton} onPress={loadProducts}>
          <Text style={styles.reloadText}>Refresh</Text>
        </Pressable>
      </View>

      {loading ? (
        <View style={styles.stateBox}>
          <Text style={styles.stateText}>Loading products...</Text>
        </View>
      ) : (
        <ScrollView contentContainerStyle={styles.form}>
          <TextInput
            placeholder="Invoice No"
            value={invoiceNo}
            onChangeText={setInvoiceNo}
            style={styles.input}
          />

          <View style={styles.row}>
            <View style={{ flex: 1 }}>
              <Text style={styles.label}>Payment Type</Text>
              <View style={styles.pickerWrap}>
                <Picker
                  selectedValue={paymentType}
                  onValueChange={(value) => setPaymentType(String(value))}
                >
                  <Picker.Item label="Cash" value="CASH" />
                  <Picker.Item label="Card" value="CARD" />
                  <Picker.Item label="Credit" value="CREDIT" />
                </Picker>
              </View>
            </View>

            <View style={{ flex: 1 }}>
              <Text style={styles.label}>Customer ID</Text>
              <TextInput
                placeholder="Credit customer ID"
                value={customerId}
                onChangeText={setCustomerId}
                style={styles.input}
              />
            </View>
          </View>

          <TextInput
            placeholder="Note"
            value={note}
            onChangeText={setNote}
            multiline
            style={[styles.input, styles.multilineInput]}
          />

          <Text style={styles.sectionTitle}>Items</Text>
          {items.map((item, index) => (
            <View key={`${index}-${item.productId}`} style={styles.itemCard}>
              <Text style={styles.label}>Product</Text>
              <View style={styles.pickerWrap}>
                <Picker
                  selectedValue={item.productId}
                  onValueChange={(value) =>
                    onChooseProduct(index, String(value))
                  }
                >
                  <Picker.Item label="Select product" value="" />
                  {products.map((product) => (
                    <Picker.Item
                      key={String(product.id ?? product._id)}
                      label={String(product.name ?? "Product")}
                      value={String(product.id ?? product._id)}
                    />
                  ))}
                </Picker>
              </View>

              <View style={styles.row}>
                <TextInput
                  placeholder="Qty"
                  value={item.qty}
                  onChangeText={(value) => updateItem(index, "qty", value)}
                  keyboardType="numeric"
                  style={[styles.input, { flex: 1 }]}
                />
                <TextInput
                  placeholder="Unit Price"
                  value={item.unitPrice}
                  onChangeText={(value) =>
                    updateItem(index, "unitPrice", value)
                  }
                  keyboardType="numeric"
                  style={[styles.input, { flex: 1 }]}
                />
              </View>

              <TextInput
                placeholder="Discount"
                value={item.discount}
                onChangeText={(value) => updateItem(index, "discount", value)}
                keyboardType="numeric"
                style={styles.input}
              />

              {items.length > 1 ? (
                <Pressable
                  onPress={() => removeItem(index)}
                  style={styles.removeButton}
                >
                  <Text style={styles.removeText}>Remove line</Text>
                </Pressable>
              ) : null}
            </View>
          ))}

          <Pressable style={styles.secondaryButton} onPress={addItem}>
            <Text style={styles.secondaryButtonText}>Add item</Text>
          </Pressable>

          <View style={styles.totalCard}>
            <Text style={styles.totalLabel}>Total</Text>
            <Text style={styles.totalValue}>
              {totalAmount.toLocaleString()}
            </Text>
          </View>

          <Pressable
            style={[styles.saveButton, saving && styles.disabled]}
            onPress={submit}
            disabled={saving}
          >
            <Text style={styles.saveButtonText}>
              {saving ? "Saving..." : "Save sale"}
            </Text>
          </Pressable>
        </ScrollView>
      )}
    </View>
  );
}

const styles = StyleSheet.create({
  screen: { flex: 1, backgroundColor: "#f4f7fb", padding: 16 },
  header: {
    backgroundColor: "#0f172a",
    borderRadius: 28,
    padding: 18,
    flexDirection: "row",
    justifyContent: "space-between",
    gap: 12,
  },
  kicker: {
    color: "#93c5fd",
    fontSize: 11,
    letterSpacing: 1.2,
    marginBottom: 6,
  },
  title: { color: "#fff", fontSize: 28, fontWeight: "800" },
  description: { color: "#cbd5e1", marginTop: 8, maxWidth: 320 },
  reloadButton: {
    backgroundColor: "#fff",
    borderRadius: 16,
    paddingHorizontal: 14,
    paddingVertical: 10,
    alignSelf: "flex-start",
  },
  reloadText: { color: "#0f172a", fontWeight: "700" },
  stateBox: { paddingVertical: 48, alignItems: "center" },
  stateText: { color: "#475569" },
  form: { gap: 14, paddingBottom: 24 },
  input: {
    backgroundColor: "#fff",
    borderRadius: 16,
    paddingHorizontal: 14,
    paddingVertical: 12,
    color: "#0f172a",
  },
  multilineInput: { minHeight: 90, textAlignVertical: "top" },
  label: { color: "#0f172a", fontWeight: "700", marginBottom: 8 },
  row: { flexDirection: "row", gap: 10, alignItems: "flex-start" },
  pickerWrap: { backgroundColor: "#fff", borderRadius: 16, overflow: "hidden" },
  sectionTitle: {
    fontSize: 16,
    fontWeight: "800",
    color: "#0f172a",
    marginTop: 4,
  },
  itemCard: { backgroundColor: "#fff", borderRadius: 22, padding: 16, gap: 10 },
  removeButton: { alignSelf: "flex-start" },
  removeText: { color: "#b91c1c", fontWeight: "700" },
  secondaryButton: {
    backgroundColor: "#e2e8f0",
    borderRadius: 16,
    paddingVertical: 14,
    alignItems: "center",
  },
  secondaryButtonText: { color: "#0f172a", fontWeight: "700" },
  totalCard: {
    backgroundColor: "#fff",
    borderRadius: 22,
    padding: 16,
    flexDirection: "row",
    justifyContent: "space-between",
  },
  totalLabel: { color: "#64748b" },
  totalValue: { color: "#0f172a", fontSize: 24, fontWeight: "800" },
  saveButton: {
    backgroundColor: "#0f766e",
    borderRadius: 18,
    paddingVertical: 16,
    alignItems: "center",
  },
  saveButtonText: { color: "#fff", fontWeight: "800" },
  disabled: { opacity: 0.7 },
});
