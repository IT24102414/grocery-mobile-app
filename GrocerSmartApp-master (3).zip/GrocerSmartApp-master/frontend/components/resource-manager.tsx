import type { ResourceConfig } from "@/constants/modules";
import {
    createResource,
    deleteResource,
    getResourceList,
    updateResource,
} from "@/services/api";
import { Ionicons } from "@expo/vector-icons";
import { useCallback, useEffect, useMemo, useState } from "react";
import {
    Alert,
    Modal,
    Pressable,
    ScrollView,
    StyleSheet,
    Text,
    TextInput,
    View,
} from "react-native";

type RecordShape = Record<string, unknown> & {
  id?: string | number;
  _id?: string | number;
};

function formatValue(value: unknown) {
  if (value === null || value === undefined || value === "") {
    return "—";
  }

  if (Array.isArray(value)) {
    return value.join(", ");
  }

  return String(value);
}

export function ResourceManager({ config }: { config: ResourceConfig }) {
  const [records, setRecords] = useState<RecordShape[]>([]);
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [modalVisible, setModalVisible] = useState(false);
  const [editingId, setEditingId] = useState<string | null>(null);
  const [formValues, setFormValues] = useState<Record<string, string>>({});

  const initialValues = useMemo(() => config.hydrateValues(null), [config]);

  const loadRecords = useCallback(async () => {
    setLoading(true);
    const data = await getResourceList<RecordShape>(config.endpoint);
    setRecords(data);
    setLoading(false);
  }, [config.endpoint]);

  useEffect(() => {
    setFormValues(initialValues);
    loadRecords();
  }, [initialValues, loadRecords]);

  const openCreate = () => {
    setEditingId(null);
    setFormValues(initialValues);
    setModalVisible(true);
  };

  const openEdit = (record: RecordShape) => {
    setEditingId(String(record.id ?? record._id ?? ""));
    setFormValues(config.hydrateValues(record));
    setModalVisible(true);
  };

  const closeModal = () => {
    setModalVisible(false);
    setEditingId(null);
  };

  const submit = async () => {
    const payload = config.buildPayload(formValues);
    const titleValue = String(payload[config.titleField] ?? "").trim();

    if (!titleValue) {
      Alert.alert(
        "Missing field",
        `${config.title} requires ${config.titleField}.`,
      );
      return;
    }

    try {
      setSaving(true);

      if (editingId) {
        await updateResource(config.endpoint, editingId, payload);
      } else {
        await createResource(config.endpoint, payload);
      }

      await loadRecords();
      closeModal();
    } catch (error) {
      Alert.alert(
        "Save failed",
        error instanceof Error ? error.message : "Please try again.",
      );
    } finally {
      setSaving(false);
    }
  };

  const removeRecord = async (id: string) => {
    try {
      await deleteResource(config.endpoint, id);
      await loadRecords();
    } catch (error) {
      Alert.alert(
        "Delete failed",
        error instanceof Error ? error.message : "Please try again.",
      );
    }
  };

  return (
    <View style={styles.screen}>
      <View style={[styles.header, { borderColor: config.accent }]}>
        <View>
          <Text style={styles.kicker}>BUSINESS MODULE</Text>
          <Text style={styles.title}>{config.title}</Text>
          <Text style={styles.description}>{config.description}</Text>
        </View>

        <Pressable
          style={[styles.addButton, { backgroundColor: config.accent }]}
          onPress={openCreate}
        >
          <Text style={styles.addButtonText}>Add</Text>
        </Pressable>
      </View>

      {loading ? (
        <View style={styles.stateBox}>
          <Text style={styles.stateText}>
            Loading {config.title.toLowerCase()}...
          </Text>
        </View>
      ) : records.length === 0 ? (
        <View style={styles.stateBox}>
          <Ionicons name={config.icon} size={28} color={config.accent} />
          <Text style={styles.emptyTitle}>{config.emptyMessage}</Text>
        </View>
      ) : (
        <ScrollView contentContainerStyle={styles.list}>
          {records.map((record) => (
            <View key={String(record.id ?? record._id)} style={styles.card}>
              <View style={styles.cardTop}>
                <View
                  style={[
                    styles.avatar,
                    { backgroundColor: `${config.accent}14` },
                  ]}
                >
                  <Text style={[styles.avatarText, { color: config.accent }]}>
                    {String(record[config.titleField] ?? config.title)
                      .charAt(0)
                      .toUpperCase()}
                  </Text>
                </View>

                <View style={{ flex: 1 }}>
                  <Text style={styles.cardTitle}>
                    {formatValue(record[config.titleField])}
                  </Text>
                  <Text style={styles.cardSubtitle}>
                    {config.summaryFields
                      .map((field) => `${field}: ${formatValue(record[field])}`)
                      .join(" · ")}
                  </Text>
                </View>
              </View>

              <View style={styles.cardActions}>
                <Pressable
                  style={styles.secondaryButton}
                  onPress={() => openEdit(record)}
                >
                  <Text style={styles.secondaryButtonText}>Edit</Text>
                </Pressable>

                <Pressable
                  style={styles.dangerButton}
                  onPress={() => {
                    Alert.alert(
                      "Delete record",
                      `Remove this ${config.title.toLowerCase()} item?`,
                      [
                        { text: "Cancel", style: "cancel" },
                        {
                          text: "Delete",
                          style: "destructive",
                          onPress: () =>
                            removeRecord(String(record.id ?? record._id)),
                        },
                      ],
                    );
                  }}
                >
                  <Text style={styles.dangerButtonText}>Delete</Text>
                </Pressable>
              </View>
            </View>
          ))}
        </ScrollView>
      )}

      <Modal visible={modalVisible} animationType="slide" transparent>
        <View style={styles.modalBackdrop}>
          <View style={styles.modalCard}>
            <View style={styles.modalHeader}>
              <Text style={styles.modalTitle}>
                {editingId ? `Edit ${config.title}` : `Create ${config.title}`}
              </Text>
              <Pressable onPress={closeModal}>
                <Text style={styles.closeText}>Close</Text>
              </Pressable>
            </View>

            <ScrollView contentContainerStyle={styles.form}>
              {config.fields.map((field) => (
                <View key={field.key} style={styles.fieldGroup}>
                  <Text style={styles.fieldLabel}>{field.label}</Text>
                  <TextInput
                    value={formValues[field.key] ?? ""}
                    onChangeText={(value) =>
                      setFormValues((current) => ({
                        ...current,
                        [field.key]: value,
                      }))
                    }
                    placeholder={field.placeholder}
                    keyboardType={field.keyboardType ?? "default"}
                    multiline={field.multiline}
                    style={[
                      styles.input,
                      field.multiline && styles.multilineInput,
                    ]}
                  />
                </View>
              ))}

              <Pressable
                style={[
                  styles.saveButton,
                  { backgroundColor: config.accent },
                  saving && styles.disabledButton,
                ]}
                onPress={submit}
                disabled={saving}
              >
                <Text style={styles.saveButtonText}>
                  {saving ? "Saving..." : "Save record"}
                </Text>
              </Pressable>
            </ScrollView>
          </View>
        </View>
      </Modal>
    </View>
  );
}

const styles = StyleSheet.create({
  screen: {
    flex: 1,
    backgroundColor: "#f4f7fb",
    padding: 16,
  },
  header: {
    borderWidth: 1,
    borderRadius: 24,
    padding: 18,
    backgroundColor: "#ffffff",
    marginBottom: 16,
    flexDirection: "row",
    justifyContent: "space-between",
    alignItems: "flex-start",
    gap: 12,
  },
  kicker: {
    fontSize: 11,
    letterSpacing: 1.3,
    color: "#6b7280",
    marginBottom: 4,
  },
  title: {
    fontSize: 26,
    fontWeight: "800",
    color: "#0f172a",
  },
  description: {
    marginTop: 6,
    color: "#475569",
  },
  addButton: {
    borderRadius: 16,
    paddingHorizontal: 18,
    paddingVertical: 12,
  },
  addButtonText: {
    color: "#ffffff",
    fontWeight: "700",
  },
  stateBox: {
    alignItems: "center",
    justifyContent: "center",
    paddingVertical: 60,
    gap: 10,
  },
  stateText: {
    color: "#475569",
  },
  emptyTitle: {
    color: "#0f172a",
    fontWeight: "700",
    fontSize: 16,
    textAlign: "center",
  },
  list: {
    gap: 12,
    paddingBottom: 24,
  },
  card: {
    backgroundColor: "#ffffff",
    borderRadius: 22,
    padding: 16,
    shadowColor: "#0f172a",
    shadowOpacity: 0.06,
    shadowRadius: 16,
    elevation: 2,
  },
  cardTop: {
    flexDirection: "row",
    gap: 12,
    alignItems: "center",
  },
  avatar: {
    width: 46,
    height: 46,
    borderRadius: 16,
    alignItems: "center",
    justifyContent: "center",
  },
  avatarText: {
    fontWeight: "800",
    fontSize: 16,
  },
  cardTitle: {
    fontSize: 17,
    fontWeight: "800",
    color: "#0f172a",
  },
  cardSubtitle: {
    marginTop: 4,
    color: "#64748b",
  },
  cardActions: {
    flexDirection: "row",
    gap: 10,
    marginTop: 14,
  },
  secondaryButton: {
    flex: 1,
    paddingVertical: 11,
    borderRadius: 14,
    alignItems: "center",
    backgroundColor: "#e2e8f0",
  },
  secondaryButtonText: {
    color: "#0f172a",
    fontWeight: "700",
  },
  dangerButton: {
    flex: 1,
    paddingVertical: 11,
    borderRadius: 14,
    alignItems: "center",
    backgroundColor: "#fee2e2",
  },
  dangerButtonText: {
    color: "#b91c1c",
    fontWeight: "700",
  },
  modalBackdrop: {
    flex: 1,
    backgroundColor: "rgba(15, 23, 42, 0.5)",
    justifyContent: "flex-end",
  },
  modalCard: {
    backgroundColor: "#ffffff",
    borderTopLeftRadius: 28,
    borderTopRightRadius: 28,
    padding: 20,
    maxHeight: "88%",
  },
  modalHeader: {
    flexDirection: "row",
    justifyContent: "space-between",
    alignItems: "center",
    marginBottom: 12,
  },
  modalTitle: {
    fontSize: 20,
    fontWeight: "800",
    color: "#0f172a",
  },
  closeText: {
    color: "#64748b",
    fontWeight: "700",
  },
  form: {
    gap: 14,
    paddingBottom: 20,
  },
  fieldGroup: {
    gap: 8,
  },
  fieldLabel: {
    color: "#0f172a",
    fontWeight: "700",
  },
  input: {
    borderWidth: 1,
    borderColor: "#dbe3ef",
    borderRadius: 16,
    paddingHorizontal: 14,
    paddingVertical: 12,
    backgroundColor: "#f8fafc",
    color: "#0f172a",
  },
  multilineInput: {
    minHeight: 92,
    textAlignVertical: "top",
  },
  saveButton: {
    marginTop: 6,
    borderRadius: 16,
    alignItems: "center",
    justifyContent: "center",
    paddingVertical: 14,
  },
  disabledButton: {
    opacity: 0.7,
  },
  saveButtonText: {
    color: "#ffffff",
    fontWeight: "800",
  },
});
