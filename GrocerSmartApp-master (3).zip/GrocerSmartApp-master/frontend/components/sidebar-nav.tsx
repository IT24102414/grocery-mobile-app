import { useAuth } from "@/context/AuthContext";
import { Ionicons } from "@expo/vector-icons";
import { useRouter } from "expo-router";
import { SafeAreaView } from "react-native-safe-area-context";
import {
  Alert,
  Pressable,
  ScrollView,
  StyleSheet,
  Text,
  TouchableOpacity,
  View,
  useColorScheme,
} from "react-native";

interface SidebarItem {
  name: string;
  label: string;
  icon: string;
  section?: string;
}

const SIDEBAR_ITEMS: SidebarItem[] = [
  // Core
  { name: "index", label: "Dashboard", icon: "grid", section: "Core" },
  { name: "pos", label: "Point of Sale", icon: "cart", section: "Core" },

  // Inventory
  { name: "inventory", label: "Products", icon: "cube", section: "Inventory" },
  { name: "convert-stock", label: "Convert Stock", icon: "swap-horizontal", section: "Inventory" },

  // Finance
  { name: "credit-customers", label: "Credit Customers", icon: "people", section: "Finance" },
  { name: "cheques", label: "Cheques", icon: "document-text", section: "Finance" },

  // Supply Chain
  { name: "suppliers", label: "Suppliers", icon: "briefcase", section: "Supply Chain" },
  { name: "purchase-orders", label: "Purchase Orders", icon: "cart-outline", section: "Supply Chain" },

  // Insights
  { name: "analytics", label: "Analytics", icon: "bar-chart", section: "Insights" },
  { name: "reports", label: "Reports", icon: "document-attach", section: "Insights" },

  // Admin
  { name: "users", label: "Users", icon: "people-circle", section: "Admin" },
  { name: "trash", label: "Trash", icon: "trash", section: "Admin" },
  { name: "settings", label: "Settings", icon: "settings", section: "Admin" },
];

const SECTION_ORDER = ["Core", "Inventory", "Finance", "Supply Chain", "Insights", "Admin"];

export interface SidebarNavProps {
  currentRoute?: string;
  onNavigate?: (routeName: string) => void;
  onClose?: () => void;
}

export default function SidebarNav({
  currentRoute,
  onNavigate,
  onClose,
}: SidebarNavProps) {
  const router = useRouter();
  const { user, signOut } = useAuth();
  const colorScheme = useColorScheme();
  const isDark = colorScheme === "dark";

  const handleNavigate = (routeName: string) => {
    if (onNavigate) onNavigate(routeName);
    if (routeName === "index") {
      router.push("/" as any);
    } else {
      router.push(`/${routeName}` as any);
    }
    onClose?.();
  };

  const handleLogout = () => {
    Alert.alert("Logout", "Are you sure you want to sign out?", [
      { text: "Cancel", style: "cancel" },
      {
        text: "Logout",
        style: "destructive",
        onPress: async () => {
          await signOut();
          router.replace("/login");
        },
      },
    ]);
  };

  const bgColor = isDark ? "#0f172a" : "#ffffff";
  const textColor = isDark ? "#f1f5f9" : "#0f172a";
  const borderColor = isDark ? "#1e293b" : "#e2e8f0";
  const sectionLabelColor = isDark ? "#475569" : "#94a3b8";
  const inactiveColor = isDark ? "#94a3b8" : "#64748b";
  const itemHoverBg = isDark ? "#1e293b" : "#f8fafc";
  const activeBg = isDark ? "rgba(15,118,110,0.18)" : "rgba(15,118,110,0.09)";
  const activeColor = "#0f766e";

  const grouped = SECTION_ORDER.map((section) => ({
    section,
    items: SIDEBAR_ITEMS.filter((item) => item.section === section),
  }));

  const isActive = (item: SidebarItem) => {
    if (item.name === "index") {
      return currentRoute === "index" || currentRoute === "(tabs)" || !currentRoute;
    }
    return currentRoute === item.name || currentRoute?.includes(item.name);
  };

  return (
    <>
      {/* Backdrop */}
      <Pressable style={styles.backdrop} onPress={onClose} />

      {/* Sidebar Panel */}
      <SafeAreaView style={[styles.sidebar, { backgroundColor: bgColor, borderRightColor: borderColor }]}>
        {/* Header */}
        <View style={[styles.header, { borderBottomColor: borderColor }]}>
          <View style={styles.logoRow}>
            <View style={styles.logoMark}>
              <Ionicons name="storefront" size={18} color="#fff" />
            </View>
            <View>
              <Text style={[styles.appName, { color: textColor }]}>GrocerSmart</Text>
              <Text style={[styles.appTagline, { color: inactiveColor }]}>Admin Portal</Text>
            </View>
          </View>
          <TouchableOpacity onPress={onClose} style={styles.closeButton} hitSlop={8}>
            <Ionicons name="close" size={20} color={inactiveColor} />
          </TouchableOpacity>
        </View>

        {/* User Chip */}
        <View style={[styles.userChip, { borderBottomColor: borderColor }]}>
          <View style={styles.userAvatar}>
            <Text style={styles.userAvatarText}>
              {(user?.displayName ?? "U").slice(0, 1).toUpperCase()}
            </Text>
          </View>
          <View style={{ flex: 1 }}>
            <Text style={[styles.userName, { color: textColor }]}>{user?.displayName ?? "User"}</Text>
            <Text style={[styles.userRole, { color: inactiveColor }]}>Administrator</Text>
          </View>
        </View>

        {/* Navigation Items */}
        <ScrollView
          style={styles.scrollArea}
          showsVerticalScrollIndicator={false}
          contentContainerStyle={{ paddingBottom: 16 }}
        >
          {grouped.map(({ section, items }) => (
            <View key={section} style={styles.sectionGroup}>
              <Text style={[styles.sectionLabel, { color: sectionLabelColor }]}>{section}</Text>
              {items.map((item) => {
                const active = isActive(item);
                return (
                  <TouchableOpacity
                    key={item.name}
                    style={[styles.navItem, { backgroundColor: active ? activeBg : "transparent" }]}
                    onPress={() => handleNavigate(item.name)}
                    activeOpacity={0.7}
                  >
                    <View
                      style={[
                        styles.navIconWrap,
                        active
                          ? { backgroundColor: activeColor }
                          : { backgroundColor: itemHoverBg },
                      ]}
                    >
                      <Ionicons
                        name={item.icon as any}
                        size={17}
                        color={active ? "#fff" : inactiveColor}
                      />
                    </View>
                    <Text
                      style={[
                        styles.navLabel,
                        {
                          color: active ? activeColor : textColor,
                          fontWeight: active ? "700" : "500",
                        },
                      ]}
                    >
                      {item.label}
                    </Text>
                    {active && <View style={styles.activeDot} />}
                  </TouchableOpacity>
                );
              })}
            </View>
          ))}
        </ScrollView>

        {/* Footer Logout */}
        <View style={[styles.footer, { borderTopColor: borderColor }]}>
          <TouchableOpacity style={styles.logoutBtn} onPress={handleLogout} activeOpacity={0.8}>
            <Ionicons name="log-out-outline" size={18} color="#ef4444" />
            <Text style={styles.logoutText}>Sign Out</Text>
          </TouchableOpacity>
        </View>
      </SafeAreaView>
    </>
  );
}

const SIDEBAR_WIDTH = 285;

const styles = StyleSheet.create({
  backdrop: {
    ...StyleSheet.absoluteFillObject,
    backgroundColor: "rgba(0,0,0,0.48)",
    zIndex: 100,
  },
  sidebar: {
    position: "absolute",
    top: 0,
    left: 0,
    bottom: 0,
    width: SIDEBAR_WIDTH,
    zIndex: 200,
    borderRightWidth: 1,
    shadowColor: "#000",
    shadowOpacity: 0.28,
    shadowRadius: 24,
    shadowOffset: { width: 6, height: 0 },
    elevation: 24,
  },
  header: {
    paddingHorizontal: 20,
    paddingVertical: 18,
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "space-between",
    borderBottomWidth: 1,
  },
  logoRow: { flexDirection: "row", alignItems: "center", gap: 12 },
  logoMark: {
    width: 38, height: 38, borderRadius: 12,
    backgroundColor: "#0f766e", alignItems: "center", justifyContent: "center",
  },
  appName: { fontSize: 15, fontWeight: "800", letterSpacing: 0.2 },
  appTagline: { fontSize: 10, fontWeight: "600", marginTop: 1, textTransform: "uppercase", letterSpacing: 0.5 },
  closeButton: { width: 32, height: 32, borderRadius: 8, alignItems: "center", justifyContent: "center" },
  userChip: {
    paddingHorizontal: 20, paddingVertical: 14,
    flexDirection: "row", alignItems: "center", gap: 12, borderBottomWidth: 1,
  },
  userAvatar: {
    width: 40, height: 40, borderRadius: 20,
    backgroundColor: "#0f766e", alignItems: "center", justifyContent: "center",
  },
  userAvatarText: { color: "#fff", fontSize: 16, fontWeight: "800" },
  userName: { fontWeight: "700", fontSize: 14 },
  userRole: { fontSize: 11, marginTop: 1 },
  scrollArea: { flex: 1 },
  sectionGroup: { paddingTop: 18, paddingHorizontal: 12, gap: 1 },
  sectionLabel: {
    fontSize: 9, fontWeight: "800", letterSpacing: 1.2,
    textTransform: "uppercase", paddingHorizontal: 8, marginBottom: 5,
  },
  navItem: {
    flexDirection: "row", alignItems: "center",
    paddingHorizontal: 8, paddingVertical: 9,
    borderRadius: 12, gap: 11, marginBottom: 1,
  },
  navIconWrap: {
    width: 32, height: 32, borderRadius: 9,
    alignItems: "center", justifyContent: "center",
  },
  navLabel: { flex: 1, fontSize: 14 },
  activeDot: { width: 6, height: 6, borderRadius: 3, backgroundColor: "#0f766e" },
  footer: { paddingHorizontal: 16, paddingVertical: 16, borderTopWidth: 1 },
  logoutBtn: {
    flexDirection: "row", alignItems: "center", gap: 10,
    paddingVertical: 12, paddingHorizontal: 12,
    borderRadius: 12, backgroundColor: "rgba(239,68,68,0.08)",
  },
  logoutText: { color: "#ef4444", fontWeight: "700", fontSize: 14 },
});
