import React, { useState, useMemo } from "react";
import {
  View,
  Text,
  TextInput,
  TouchableOpacity,
  FlatList,
  Modal,
  StyleSheet,
  SafeAreaView,
} from "react-native";
import { Ionicons } from "@expo/vector-icons";

interface SearchableDropdownProps {
  items: { label: string; value: any }[];
  value: any;
  onValueChange: (value: any) => void;
  placeholder: string;
  label?: string;
  allowCustom?: boolean;
  disabled?: boolean;
}

export default function SearchableDropdown({
  items,
  value,
  onValueChange,
  placeholder,
  label,
  allowCustom = false,
  disabled = false,
}: SearchableDropdownProps) {
  const [modalVisible, setModalVisible] = useState(false);
  const [search, setSearch] = useState("");

  const selectedItem = items.find((i) => i.value === value);
  const displayValue = selectedItem ? selectedItem.label : value ? String(value) : "";

  const filteredItems = useMemo(() => {
    return items.filter((item) =>
      item.label.toLowerCase().includes(search.toLowerCase())
    );
  }, [items, search]);

  const handleSelect = (item: { label: string; value: any }) => {
    onValueChange(item.value);
    setModalVisible(false);
    setSearch("");
  };

  const handleCustomAdd = () => {
    if (allowCustom && search.trim()) {
      onValueChange(search.trim());
      setModalVisible(false);
      setSearch("");
    }
  };

  return (
    <View style={styles.container}>
      {label && <Text style={styles.label}>{label}</Text>}
      <TouchableOpacity
        style={[styles.trigger, disabled && styles.disabledTrigger]}
        onPress={() => !disabled && setModalVisible(true)}
        activeOpacity={disabled ? 1 : 0.7}
      >
        <Text style={[styles.triggerText, !displayValue && styles.placeholder]}>
          {displayValue || placeholder}
        </Text>
        <Ionicons name="chevron-down" size={18} color="#94a3b8" />
      </TouchableOpacity>

      <Modal
        visible={modalVisible}
        animationType="slide"
        transparent={false}
        onRequestClose={() => setModalVisible(false)}
      >
        <SafeAreaView style={styles.modalContainer}>
          <View style={styles.modalHeader}>
            <TouchableOpacity
              onPress={() => setModalVisible(false)}
              style={styles.closeBtn}
            >
              <Ionicons name="arrow-back" size={24} color="#0f172a" />
            </TouchableOpacity>
            <Text style={styles.modalTitle}>{placeholder}</Text>
          </View>

          <View style={styles.searchBox}>
            <Ionicons name="search" size={20} color="#94a3b8" style={styles.searchIcon} />
            <TextInput
              style={styles.searchInput}
              placeholder="Search..."
              value={search}
              onChangeText={setSearch}
              autoFocus
            />
            {search.length > 0 && (
              <TouchableOpacity onPress={() => setSearch("")}>
                <Ionicons name="close-circle" size={18} color="#cbd5e1" />
              </TouchableOpacity>
            )}
          </View>

          <FlatList
            data={filteredItems}
            keyExtractor={(item, index) => String(item.value) + index}
            renderItem={({ item }) => (
              <TouchableOpacity
                style={[
                  styles.item,
                  item.value === value && styles.selectedItem,
                ]}
                onPress={() => handleSelect(item)}
              >
                <Text
                  style={[
                    styles.itemText,
                    item.value === value && styles.selectedItemText,
                  ]}
                >
                  {item.label}
                </Text>
                {item.value === value && (
                  <Ionicons name="checkmark" size={20} color="#0f766e" />
                )}
              </TouchableOpacity>
            )}
            ListEmptyComponent={
              allowCustom && search.trim() ? (
                <TouchableOpacity style={styles.customAddBtn} onPress={handleCustomAdd}>
                  <Ionicons name="add-circle-outline" size={20} color="#0f766e" />
                  <Text style={styles.customAddText}>Add "{search}" as new</Text>
                </TouchableOpacity>
              ) : (
                <View style={styles.emptyContainer}>
                  <Text style={styles.emptyText}>No matches found</Text>
                </View>
              )
            }
            contentContainerStyle={styles.listContent}
          />
        </SafeAreaView>
      </Modal>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    marginVertical: 4,
  },
  label: {
    fontSize: 11,
    fontWeight: "700",
    color: "#64748b",
    textTransform: "uppercase",
    letterSpacing: 0.8,
    marginBottom: 6,
  },
  trigger: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "space-between",
    backgroundColor: "#f8fafc",
    borderRadius: 14,
    paddingHorizontal: 16,
    paddingVertical: 14,
    borderWidth: 1,
    borderColor: "#e2e8f0",
  },
  triggerText: {
    fontSize: 15,
    color: "#0f172a",
  },
  placeholder: {
    color: "#94a3b8",
  },
  modalContainer: {
    flex: 1,
    backgroundColor: "#fff",
  },
  modalHeader: {
    flexDirection: "row",
    alignItems: "center",
    padding: 16,
    borderBottomWidth: 1,
    borderBottomColor: "#f1f5f9",
  },
  closeBtn: {
    marginRight: 16,
  },
  modalTitle: {
    fontSize: 18,
    fontWeight: "700",
    color: "#0f172a",
  },
  searchBox: {
    flexDirection: "row",
    alignItems: "center",
    margin: 16,
    paddingHorizontal: 12,
    backgroundColor: "#f1f5f9",
    borderRadius: 12,
    height: 48,
  },
  searchIcon: {
    marginRight: 10,
  },
  searchInput: {
    flex: 1,
    fontSize: 16,
    color: "#0f172a",
  },
  listContent: {
    paddingHorizontal: 16,
    paddingBottom: 40,
  },
  item: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "space-between",
    paddingVertical: 16,
    borderBottomWidth: 1,
    borderBottomColor: "#f1f5f9",
  },
  selectedItem: {
    backgroundColor: "#f0fdfa",
    marginHorizontal: -16,
    paddingHorizontal: 16,
  },
  itemText: {
    fontSize: 16,
    color: "#334155",
  },
  selectedItemText: {
    color: "#0f766e",
    fontWeight: "700",
  },
  emptyContainer: {
    paddingVertical: 40,
    alignItems: "center",
  },
  emptyText: {
    color: "#94a3b8",
    fontSize: 14,
  },
  customAddBtn: {
    flexDirection: "row",
    alignItems: "center",
    paddingVertical: 16,
    gap: 8,
  },
  customAddText: {
    fontSize: 16,
    color: "#0f766e",
    fontWeight: "600",
  },
  disabledTrigger: {
    backgroundColor: "#f1f5f9",
    borderColor: "#cbd5e1",
    opacity: 0.8,
  },
});
