import 'react';

declare global {
  namespace JSX {
    interface ElementClass {
      props: any;
    }
  }
}
