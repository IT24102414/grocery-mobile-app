import { BASE_URL, getAuthToken } from "@/services/api";
import { Ionicons } from "@expo/vector-icons";
import { useEffect, useState } from "react";
import {
  ActivityIndicator,
  Alert,
  Linking,
  ScrollView,
  StyleSheet,
  Text,
  TouchableOpacity,
  View,
} from "react-native";

const apiHeaders = () => ({
  "Content-Type": "application/json",
  ...(getAuthToken() ? { Authorization: `Bearer ${getAuthToken()}` } : {}),
});

const REPORT_TYPES = [
  {
    id: "inventory",
    title: "Inventory Report",
    subtitle: "Current stock levels and product catalog",
    icon: "cube",
    color: "#1d4ed8",
    endpoint: "/reports/inventory",
  },
  {
    id: "sales",
    title: "POS / Sales Report",
    subtitle: "All finalized invoice records",
    icon: "receipt",
    color: "#0f766e",
    endpoint: "/reports/sales",
  },
  {
    id: "credit-customers",
    title: "Credit Customers Report",
    subtitle: "Outstanding balance and credit exposure",
    icon: "people",
    color: "#7c3aed",
    endpoint: "/reports/credit-customers/pdf",
  },
  {
    id: "cheques",
    title: "Cheques Report",
    subtitle: "Banking instruments and due dates",
    icon: "document-text",
    color: "#b45309",
    endpoint: "/reports/cheques/pdf",
  },
  {
    id: "suppliers",
    title: "Suppliers Report",
    subtitle: "Vendor records and payment exposure",
    icon: "briefcase",
    color: "#334155",
    endpoint: "/reports/suppliers/pdf",
  },
  {
    id: "purchase-orders",
    title: "Purchase Orders Report",
    subtitle: "Procurement history and totals",
    icon: "cart",
    color: "#0369a1",
    endpoint: "/reports/purchase-orders/pdf",
  },
  {
    id: "users",
    title: "Users Report",
    subtitle: "System access audit log",
    icon: "person-circle",
    color: "#dc2626",
    endpoint: "/reports/users/pdf",
  },
];

export default function ReportsScreen() {
  const [generating, setGenerating] = useState<string | null>(null);
  const [stats, setStats] = useState<any>(null);
  const [statsLoading, setStatsLoading] = useState(true);

  const loadStats = async () => {
    setStatsLoading(true);
    try {
      const [salesRes, prodRes] = await Promise.all([
        fetch(`${BASE_URL}/sales?size=1000`, { headers: apiHeaders() }).then((r) => r.json()),
        fetch(`${BASE_URL}/products?status=ACTIVE&size=1000`, { headers: apiHeaders() }).then((r) => r.json()),
      ]);

      const sales = salesRes?.data?.content ?? salesRes?.data ?? salesRes?.content ?? [];
      const products = prodRes?.data?.content ?? prodRes?.data ?? prodRes?.content ?? [];

      const totalRevenue = Array.isArray(sales)
        ? sales.reduce((s: number, inv: any) => s + Number(inv.totalAmount ?? 0), 0)
        : 0;

      setStats({
        totalSales: Array.isArray(sales) ? sales.length : 0,
        totalRevenue,
        activeProducts: Array.isArray(products) ? products.length : 0,
      });
    } catch {
      setStats(null);
    } finally {
      setStatsLoading(false);
    }
  };

  useEffect(() => { loadStats(); }, []);

  const handleGenerateReport = async (report: typeof REPORT_TYPES[0]) => {
    setGenerating(report.id);
    try {
      // On mobile, we open the URL in the browser so the user can view/download
      const url = `${BASE_URL}${report.endpoint}`;
      const supported = await Linking.canOpenURL(url);
      if (supported) {
        await Linking.openURL(url);
      } else {
        Alert.alert("Info", "PDF downloads are available on desktop browsers. The report endpoint is ready at:\n\n" + url);
      }
    } catch (e: any) {
      Alert.alert("Error", "Failed to open report: " + (e.message ?? "Unknown error"));
    } finally {
      setGenerating(null);
    }
  };

  const formatCurrency = (val: number) =>
    new Intl.NumberFormat("en-IN", { style: "currency", currency: "LKR", maximumFractionDigits: 0 }).format(val);

  return (
    <ScrollView style={styles.screen} contentContainerStyle={styles.container} showsVerticalScrollIndicator={false}>
      {/* Header */}
      <View style={styles.headerCard}>
        <View style={styles.headerIcon}>
          <Ionicons name="bar-chart" size={22} color="#fff" />
        </View>
        <View style={{ flex: 1 }}>
          <Text style={styles.headerTitle}>Reports</Text>
          <Text style={styles.headerSub}>Generate and export business reports</Text>
        </View>
      </View>

      {/* Summary Stats */}
      {statsLoading ? (
        <ActivityIndicator color="#0f766e" style={{ marginVertical: 12 }} />
      ) : stats ? (
        <View style={styles.statsRow}>
          <View style={styles.statCard}>
            <Ionicons name="receipt" size={20} color="#0f766e" />
            <Text style={styles.statValue}>{stats.totalSales}</Text>
            <Text style={styles.statLabel}>Total Invoices</Text>
          </View>
          <View style={styles.statCard}>
            <Ionicons name="cash" size={20} color="#1d4ed8" />
            <Text style={styles.statValue}>{formatCurrency(stats.totalRevenue)}</Text>
            <Text style={styles.statLabel}>Total Revenue</Text>
          </View>
          <View style={styles.statCard}>
            <Ionicons name="cube" size={20} color="#7c3aed" />
            <Text style={styles.statValue}>{stats.activeProducts}</Text>
            <Text style={styles.statLabel}>Active Products</Text>
          </View>
        </View>
      ) : null}

      {/* Info Banner */}
      <View style={styles.infoBanner}>
        <Ionicons name="information-circle" size={18} color="#0369a1" />
        <Text style={styles.infoText}>
          Tap any report to open or download the PDF. Reports open in your device browser.
        </Text>
      </View>

      {/* Report Cards */}
      {REPORT_TYPES.map((report) => {
        const isGenerating = generating === report.id;
        return (
          <TouchableOpacity
            key={report.id}
            style={styles.reportCard}
            onPress={() => handleGenerateReport(report)}
            activeOpacity={0.8}
            disabled={isGenerating}
          >
            <View style={[styles.reportIcon, { backgroundColor: `${report.color}12` }]}>
              <Ionicons name={report.icon as any} size={24} color={report.color} />
            </View>
            <View style={{ flex: 1 }}>
              <Text style={styles.reportTitle}>{report.title}</Text>
              <Text style={styles.reportSubtitle}>{report.subtitle}</Text>
            </View>
            {isGenerating ? (
              <ActivityIndicator color={report.color} size="small" />
            ) : (
              <View style={[styles.reportArrow, { backgroundColor: `${report.color}12` }]}>
                <Ionicons name="download-outline" size={18} color={report.color} />
              </View>
            )}
          </TouchableOpacity>
        );
      })}
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  screen: { flex: 1, backgroundColor: "#f4f7fb" },
  container: { padding: 16, gap: 12, paddingBottom: 32 },
  headerCard: {
    backgroundColor: "#0f172a", borderRadius: 20,
    padding: 18, flexDirection: "row", alignItems: "center", gap: 14,
  },
  headerIcon: { width: 44, height: 44, borderRadius: 14, backgroundColor: "#0369a1", alignItems: "center", justifyContent: "center" },
  headerTitle: { color: "#fff", fontSize: 16, fontWeight: "800" },
  headerSub: { color: "#94a3b8", fontSize: 12, marginTop: 2 },
  statsRow: { flexDirection: "row", gap: 10 },
  statCard: {
    flex: 1, backgroundColor: "#fff", borderRadius: 16, padding: 14, alignItems: "center", gap: 6,
    shadowColor: "#0f172a", shadowOpacity: 0.04, shadowRadius: 8, elevation: 2,
  },
  statValue: { color: "#0f172a", fontSize: 13, fontWeight: "800", textAlign: "center" },
  statLabel: { color: "#94a3b8", fontSize: 10, fontWeight: "600", textAlign: "center" },
  infoBanner: {
    flexDirection: "row", alignItems: "flex-start", gap: 10,
    backgroundColor: "#e0f2fe", padding: 14, borderRadius: 14,
  },
  infoText: { flex: 1, color: "#0369a1", fontSize: 13, lineHeight: 19 },
  reportCard: {
    backgroundColor: "#fff", borderRadius: 18, padding: 16,
    flexDirection: "row", alignItems: "center", gap: 14,
    shadowColor: "#0f172a", shadowOpacity: 0.04, shadowRadius: 8, elevation: 2,
  },
  reportIcon: { width: 52, height: 52, borderRadius: 16, alignItems: "center", justifyContent: "center" },
  reportTitle: { color: "#0f172a", fontWeight: "700", fontSize: 15 },
  reportSubtitle: { color: "#64748b", fontSize: 12, marginTop: 3 },
  reportArrow: { width: 38, height: 38, borderRadius: 12, alignItems: "center", justifyContent: "center" },
});
