import { BASE_URL, getAuthToken } from "@/services/api";
import { Ionicons } from "@expo/vector-icons";
import { useEffect, useState } from "react";
import {
  ActivityIndicator,
  Alert,
  Modal,
  ScrollView,
  StyleSheet,
  Text,
  TextInput,
  TouchableOpacity,
  View,
} from "react-native";

const apiHeaders = () => ({
  "Content-Type": "application/json",
  ...(getAuthToken() ? { Authorization: `Bearer ${getAuthToken()}` } : {}),
});

const fetchCustomers = async (params: any = {}) => {
  const q = new URLSearchParams(Object.entries(params).filter(([, v]) => v != null).map(([k, v]) => [k, String(v)]));
  const res = await fetch(`${BASE_URL}/credit-customers?${q.toString()}`, { headers: apiHeaders() });
  const data = await res.json();
  return data?.data?.content ?? data?.data ?? data?.content ?? [];
};

const saveCustomer = async (payload: any, id?: string) => {
  const res = await fetch(`${BASE_URL}/credit-customers${id ? `/${id}` : ""}`, {
    method: id ? "PUT" : "POST",
    headers: apiHeaders(),
    body: JSON.stringify(payload),
  });
  const data = await res.json();
  if (!res.ok) throw new Error(data?.message ?? "Failed to save customer");
  return data;
};

const deleteCustomer = async (id: string) => {
  const res = await fetch(`${BASE_URL}/credit-customers/${id}`, { method: "DELETE", headers: apiHeaders() });
  if (!res.ok) {
    const data = await res.json();
    throw new Error(data?.message ?? "Failed to delete customer");
  }
};

export default function CreditCustomersScreen() {
  const [customers, setCustomers] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState("");
  const [modalVisible, setModalVisible] = useState(false);
  const [saving, setSaving] = useState(false);
  const [editId, setEditId] = useState<string | null>(null);
  const [form, setForm] = useState({
    name: "",
    phone: "",
    address: "",
    creditLimit: "50000",
    status: "ACTIVE",
    paymentTermsDays: "30",
    customerType: "CREDIT"
  });

  const load = async () => {
    setLoading(true);
    try {
      const data = await fetchCustomers({ size: 1000 });
      setCustomers(Array.isArray(data) ? data : []);
    } catch {
      setCustomers([]);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => { load(); }, []);

  const filtered = customers.filter(
    (c) =>
      c.name?.toLowerCase().includes(search.toLowerCase()) ||
      c.phone?.toLowerCase().includes(search.toLowerCase())
  );

  const openCreate = () => {
    setEditId(null);
    setForm({ name: "", phone: "", address: "", creditLimit: "50000", status: "ACTIVE", paymentTermsDays: "30", customerType: "CREDIT" });
    setModalVisible(true);
  };

  const openEdit = (customer: any) => {
    setEditId(customer.id ?? customer._id);
    setForm({
      name: customer.name || "",
      phone: customer.phone || "",
      address: customer.address || "",
      creditLimit: String(customer.creditLimit || "50000"),
      status: customer.status || "ACTIVE",
      paymentTermsDays: String(customer.paymentTermsDays || "30"),
      customerType: customer.customerType || "CREDIT"
    });
    setModalVisible(true);
  };

  const handleSave = async () => {
    if (!form.name || !form.phone) return Alert.alert("Error", "Name and Phone are required");
    setSaving(true);
    try {
      const payload = { ...form, creditLimit: Number(form.creditLimit), paymentTermsDays: Number(form.paymentTermsDays) };
      await saveCustomer(payload, editId || undefined);
      setModalVisible(false);
      load();
    } catch (e: any) {
      Alert.alert("Error", e.message);
    } finally {
      setSaving(false);
    }
  };

  const handleDelete = (customer: any) => {
    Alert.alert("Archive Customer", `Are you sure you want to archive "${customer.name}"?`, [
      { text: "Cancel", style: "cancel" },
      { text: "Archive", style: "destructive", onPress: async () => {
          try {
            await deleteCustomer(customer.id ?? customer._id);
            load();
          } catch (e: any) { Alert.alert("Error", e.message); }
        }
      },
    ]);
  };

  const formatCurrency = (val: any) => `Rs.${Number(val || 0).toLocaleString()}`;

  return (
    <View style={styles.screen}>
      {/* Header */}
      <View style={styles.headerCard}>
        <View style={styles.headerIcon}>
          <Ionicons name="people" size={22} color="#fff" />
        </View>
        <View style={{ flex: 1 }}>
          <Text style={styles.headerTitle}>Credit Customers</Text>
          <Text style={styles.headerSub}>Manage debts and credit limits</Text>
        </View>
        <TouchableOpacity style={styles.addBtn} onPress={openCreate} activeOpacity={0.8}>
          <Ionicons name="person-add" size={20} color="#fff" />
          <Text style={styles.addBtnText}>Add</Text>
        </TouchableOpacity>
      </View>

      {/* Stats Summary */}
      <View style={styles.statsBar}>
        <View style={styles.statBox}>
          <Text style={styles.statVal}>{customers.length}</Text>
          <Text style={styles.statLab}>Total</Text>
        </View>
        <View style={styles.statBox}>
          <Text style={[styles.statVal, { color: "#ef4444" }]}>
            {formatCurrency(customers.reduce((sum, c) => sum + Number(c.outstandingBalance || 0), 0))}
          </Text>
          <Text style={styles.statLab}>Total Debt</Text>
        </View>
      </View>

      {/* Search */}
      <View style={styles.searchRow}>
        <Ionicons name="search" size={18} color="#94a3b8" />
        <TextInput
          style={styles.searchInput}
          placeholder="Search name or phone..."
          placeholderTextColor="#94a3b8"
          value={search}
          onChangeText={setSearch}
        />
      </View>

      {loading ? (
        <ActivityIndicator size="large" color="#0f766e" style={{ marginTop: 40 }} />
      ) : (
        <ScrollView style={{ flex: 1 }} contentContainerStyle={styles.list} showsVerticalScrollIndicator={false}>
          {filtered.map((customer) => {
            const debt = Number(customer.outstandingBalance || 0);
            const limit = Number(customer.creditLimit || 0);
            const usage = limit > 0 ? (debt / limit) : 0;
            const progressColor = usage > 0.8 ? "#ef4444" : usage > 0.5 ? "#f59e0b" : "#10b981";

            return (
                <View key={customer.id ?? customer._id} style={styles.card}>
                  <TouchableOpacity 
                    style={{ flex: 1 }} 
                    onPress={() => openEdit(customer)} 
                    activeOpacity={0.7}
                  >
                    <View style={styles.cardHeader}>
                      <View style={styles.customerAvatar}>
                        <Text style={styles.avatarText}>{(customer.name || "?").charAt(0).toUpperCase()}</Text>
                      </View>
                      <View style={{ flex: 1 }}>
                        <Text style={styles.customerName}>{customer.name}</Text>
                        <Text style={styles.customerPhone}>{customer.phone}</Text>
                      </View>
                    </View>

                    <View style={styles.debtInfo}>
                      <View style={styles.debtRow}>
                        <Text style={styles.debtLabel}>Outstanding Balance</Text>
                        <Text style={[styles.debtValue, { color: progressColor }]}>{formatCurrency(debt)}</Text>
                      </View>
                      <View style={styles.progressBarBg}>
                        <View style={[styles.progressBarFill, { width: `${Math.min(100, usage * 100)}%`, backgroundColor: progressColor }]} />
                      </View>
                      <View style={styles.debtRow}>
                        <Text style={styles.limitText}>Limit: {formatCurrency(limit)}</Text>
                        <Text style={styles.limitText}>{Math.round(usage * 100)}% used</Text>
                      </View>
                    </View>
                  </TouchableOpacity>
                  
                  <TouchableOpacity 
                    style={styles.archiveActionBtn} 
                    onPress={() => handleDelete(customer)}
                  >
                    <Ionicons name="trash-outline" size={18} color="#ef4444" />
                  </TouchableOpacity>
                </View>
            );
          })}
        </ScrollView>
      )}

      {/* Customer Modal */}
      <Modal visible={modalVisible} animationType="slide" transparent onRequestClose={() => setModalVisible(false)}>
        <View style={styles.modalOverlay}>
          <View style={styles.modalCard}>
            <View style={styles.modalHeader}>
              <Text style={styles.modalTitle}>{editId ? "Modify Customer" : "New Credit Customer"}</Text>
              <TouchableOpacity onPress={() => setModalVisible(false)}>
                <Ionicons name="close" size={22} color="#64748b" />
              </TouchableOpacity>
            </View>

            <ScrollView contentContainerStyle={{ gap: 14 }} showsVerticalScrollIndicator={false}>
              <View style={styles.fieldGroup}>
                <Text style={styles.fieldLabel}>Full Name *</Text>
                <TextInput style={styles.fieldInput} value={form.name} onChangeText={(v) => setForm({...form, name: v})} placeholder="M.S. Buddhika" />
              </View>

              <View style={styles.fieldGroup}>
                <Text style={styles.fieldLabel}>Phone Number *</Text>
                <TextInput style={styles.fieldInput} value={form.phone} onChangeText={(v) => setForm({...form, phone: v})} keyboardType="phone-pad" placeholder="077 123 4567" />
              </View>

              <View style={styles.row}>
                <View style={[styles.fieldGroup, { flex: 1 }]}>
                  <Text style={styles.fieldLabel}>Credit Limit (LKR)</Text>
                  <TextInput style={styles.fieldInput} value={form.creditLimit} onChangeText={(v) => setForm({...form, creditLimit: v})} keyboardType="numeric" placeholder="50000" />
                </View>
                <View style={[styles.fieldGroup, { flex: 1 }]}>
                  <Text style={styles.fieldLabel}>Terms (Days)</Text>
                  <TextInput style={styles.fieldInput} value={form.paymentTermsDays} onChangeText={(v) => setForm({...form, paymentTermsDays: v})} keyboardType="numeric" placeholder="30" />
                </View>
              </View>

              <View style={styles.fieldGroup}>
                <Text style={styles.fieldLabel}>Customer Type</Text>
                <TextInput style={styles.fieldInput} value={form.customerType} onChangeText={(v) => setForm({...form, customerType: v})} placeholder="CREDIT / CASH" />
              </View>

              <View style={styles.fieldGroup}>
                <Text style={styles.fieldLabel}>Address</Text>
                <TextInput style={[styles.fieldInput, { height: 80 }]} value={form.address} onChangeText={(v) => setForm({...form, address: v})} multiline placeholder="Home or Office address" />
              </View>
            </ScrollView>

            <TouchableOpacity style={styles.saveBtn} onPress={handleSave} disabled={saving} activeOpacity={0.85}>
              {saving ? <ActivityIndicator color="#fff" /> : <Text style={styles.saveBtnText}>{editId ? "Update Customer" : "Register Customer"}</Text>}
            </TouchableOpacity>
          </View>
        </View>
      </Modal>
    </View>
  );
}

const styles = StyleSheet.create({
  screen: { flex: 1, backgroundColor: "#f4f7fb" },
  headerCard: {
    backgroundColor: "#0f172a", margin: 16, borderRadius: 20,
    padding: 18, flexDirection: "row", alignItems: "center", gap: 14,
  },
  headerIcon: { width: 44, height: 44, borderRadius: 14, backgroundColor: "#7c3aed", alignItems: "center", justifyContent: "center" },
  headerTitle: { color: "#fff", fontSize: 16, fontWeight: "800" },
  headerSub: { color: "#94a3b8", fontSize: 12, marginTop: 2 },
  addBtn: { flexDirection: "row", alignItems: "center", gap: 6, backgroundColor: "#0f766e", borderRadius: 12, paddingHorizontal: 16, paddingVertical: 10 },
  addBtnText: { color: "#fff", fontWeight: "700", fontSize: 13 },
  statsBar: { flexDirection: "row", marginHorizontal: 16, marginBottom: 12, gap: 12 },
  statBox: { flex: 1, backgroundColor: "#fff", borderRadius: 16, padding: 14, alignItems: "center", shadowColor: "#000", shadowOpacity: 0.04, shadowRadius: 6, elevation: 1 },
  statVal: { fontSize: 15, fontWeight: "800", color: "#0f172a" },
  statLab: { fontSize: 10, color: "#94a3b8", fontWeight: "700", textTransform: "uppercase", marginTop: 2 },
  searchRow: {
    flexDirection: "row", alignItems: "center", gap: 10,
    backgroundColor: "#fff", borderRadius: 14, marginHorizontal: 16, marginBottom: 12,
    paddingHorizontal: 14, paddingVertical: 12,
    shadowColor: "#0f172a", shadowOpacity: 0.04, shadowRadius: 8, elevation: 2,
  },
  searchInput: { flex: 1, color: "#0f172a", fontSize: 14 },
  list: { padding: 16, paddingTop: 4, gap: 12 },
  card: {
    backgroundColor: "#fff", borderRadius: 20, padding: 16, gap: 14,
    shadowColor: "#0f172a", shadowOpacity: 0.05, shadowRadius: 10, elevation: 2,
  },
  cardHeader: { flexDirection: "row", alignItems: "center", gap: 12 },
  customerAvatar: { width: 44, height: 44, borderRadius: 22, backgroundColor: "#7c3aed20", alignItems: "center", justifyContent: "center" },
  avatarText: { color: "#7c3aed", fontSize: 18, fontWeight: "800" },
  customerName: { color: "#0f172a", fontWeight: "700", fontSize: 15 },
  customerPhone: { color: "#94a3b8", fontSize: 12 },
  debtInfo: { gap: 6, backgroundColor: "#f8fafc", padding: 12, borderRadius: 14 },
  debtRow: { flexDirection: "row", justifyContent: "space-between", alignItems: "center" },
  debtLabel: { color: "#64748b", fontSize: 11, fontWeight: "600" },
  debtValue: { fontSize: 14, fontWeight: "800" },
  progressBarBg: { height: 6, backgroundColor: "#e2e8f0", borderRadius: 3, marginVertical: 4 },
  progressBarFill: { height: "100%", borderRadius: 3 },
  limitText: { fontSize: 10, color: "#94a3b8", fontWeight: "600" },
  archiveActionBtn: { padding: 12, backgroundColor: "#fef2f2", borderRadius: 12, marginLeft: 12, alignSelf: "center" },
  modalOverlay: { flex: 1, backgroundColor: "rgba(0,0,0,0.4)", justifyContent: "flex-end" },
  modalCard: { backgroundColor: "#fff", borderTopLeftRadius: 28, borderTopRightRadius: 28, padding: 24, gap: 18, maxHeight: "90%" },
  modalHeader: { flexDirection: "row", alignItems: "center", justifyContent: "space-between" },
  modalTitle: { color: "#0f172a", fontSize: 20, fontWeight: "800" },
  fieldGroup: { gap: 6 },
  fieldLabel: { color: "#64748b", fontSize: 11, fontWeight: "700", textTransform: "uppercase", letterSpacing: 0.8 },
  fieldInput: { backgroundColor: "#f8fafc", borderRadius: 14, paddingHorizontal: 16, paddingVertical: 14, color: "#0f172a", fontSize: 15, borderWidth: 1, borderColor: "#e2e8f0" },
  row: { flexDirection: "row", gap: 12 },
  saveBtn: { backgroundColor: "#0f766e", borderRadius: 16, paddingVertical: 16, alignItems: "center", marginTop: 8 },
  saveBtnText: { color: "#fff", fontWeight: "800", fontSize: 16 },
});
