import { BASE_URL, getAuthToken } from "@/services/api";
import { useAuth } from "@/context/AuthContext";
import { Ionicons } from "@expo/vector-icons";
import { Link, useRouter } from "expo-router";
import { useEffect, useState } from "react";
import {
  ActivityIndicator,
  Pressable,
  RefreshControl,
  ScrollView,
  StyleSheet,
  Text,
  TouchableOpacity,
  View,
} from "react-native";

const fmt = (val: number) =>
  new Intl.NumberFormat("en-IN", {
    style: "currency",
    currency: "LKR",
    maximumFractionDigits: 0,
  }).format(val);

const apiHeaders = () => ({
  "Content-Type": "application/json",
  ...(getAuthToken() ? { Authorization: `Bearer ${getAuthToken()}` } : {}),
});

const toList = (payload: any): any[] => {
  if (Array.isArray(payload)) return payload;
  if (Array.isArray(payload?.content)) return payload.content;
  if (Array.isArray(payload?.data?.content)) return payload.data.content;
  if (Array.isArray(payload?.data)) return payload.data;
  return [];
};

type Stats = {
  todaysSales: number;
  totalRevenue: number;
  lowStock: number;
  pendingCheques: number;
  creditBalance: number;
  activeProducts: number;
  salesCount: number;
};

type RecentSale = { id: string; invoiceNo?: string; publicId?: string; totalAmount: number; paymentType: string; createdAt: string };
type LowStockProduct = { id: string; name: string; totalRetailUnits: number; reorder: number };



export default function DashboardScreen() {
  const { user } = useAuth();
  const router = useRouter();

  const [loading, setLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);
  const [stats, setStats] = useState<Stats>({
    todaysSales: 0,
    totalRevenue: 0,
    lowStock: 0,
    pendingCheques: 0,
    creditBalance: 0,
    activeProducts: 0,
    salesCount: 0,
  });
  const [recentSales, setRecentSales] = useState<RecentSale[]>([]);
  const [lowStockProducts, setLowStockProducts] = useState<LowStockProduct[]>([]);

  const fetchData = async () => {
    try {
      const todayStr = new Date().toISOString().slice(0, 10);

      const [prodRes, custRes, chequeRes, salesRes] = await Promise.all([
        fetch(`${BASE_URL}/products?status=ACTIVE&size=1000`, { headers: apiHeaders() }).then((r) => r.json()).catch(() => ({})),
        fetch(`${BASE_URL}/credit-customers?size=1000`, { headers: apiHeaders() }).then((r) => r.json()).catch(() => ({})),
        fetch(`${BASE_URL}/cheques?size=1000`, { headers: apiHeaders() }).then((r) => r.json()).catch(() => ({})),
        fetch(`${BASE_URL}/sales?size=1000`, { headers: apiHeaders() }).then((r) => r.json()).catch(() => ({})),
      ]);

      const products = toList(prodRes);
      const customers = toList(custRes);
      const cheques = toList(chequeRes);
      const sales = toList(salesRes);

      // Low stock
      const lowStockList = products
        .map((p: any) => {
          const retail = Number(p?.stockLevels?.retailQty ?? 0);
          const bulk = Number(p?.stockLevels?.bulkQty ?? 0);
          const factor = Number(p?.unitConfig?.conversionFactor ?? 1);
          const totalRetailUnits = retail + bulk * factor;
          const reorder = Number(p?.reorderPoint ?? 10);
          return { ...p, totalRetailUnits, reorder };
        })
        .filter((p: any) => p.totalRetailUnits <= p.reorder)
        .sort((a: any, b: any) => a.totalRetailUnits - b.totalRetailUnits);

      // Finance
      const creditBalance = customers.reduce(
        (s: number, c: any) => s + Number(c.outstandingBalance ?? c.currentBalance ?? 0),
        0
      );
      const pendingCheques = cheques.filter(
        (c: any) => c.status === "PENDING" || c.status === "DEPOSITED"
      ).length;

      // Sales
      const totalRevenue = sales.reduce(
        (s: number, inv: any) => s + Number(inv.totalAmount ?? 0),
        0
      );
      const todaysSales = sales
        .filter((s: any) => (s.createdAt ?? "").slice(0, 10) === todayStr)
        .reduce((acc: number, s: any) => acc + Number(s.totalAmount ?? 0), 0);

      const recent = [...sales]
        .sort((a: any, b: any) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime())
        .slice(0, 5);

      setStats({
        todaysSales,
        totalRevenue,
        lowStock: lowStockList.length,
        pendingCheques,
        creditBalance,
        activeProducts: products.length,
        salesCount: sales.length,
      });
      setRecentSales(recent);
      setLowStockProducts(lowStockList.slice(0, 5));
    } catch (err) {
      console.error("Dashboard error:", err);
    }
  };

  const load = async (isRefresh = false) => {
    if (isRefresh) setRefreshing(true);
    else setLoading(true);
    await fetchData();
    setLoading(false);
    setRefreshing(false);
  };

  useEffect(() => { load(); }, []);

  const today = new Date().toLocaleDateString("en-US", {
    weekday: "long",
    month: "long",
    day: "numeric",
  });

  const KPI_CARDS = [
    {
      label: "Today's Revenue",
      value: fmt(stats.todaysSales),
      icon: "trending-up",
      color: "#0f766e",
      bg: "#f0fdfa",
      note: "Live sales",
    },
    {
      label: "Total Revenue",
      value: fmt(stats.totalRevenue),
      icon: "cash",
      color: "#1d4ed8",
      bg: "#eff6ff",
      note: `${stats.salesCount} invoices`,
    },
    {
      label: "Low Stock Items",
      value: String(stats.lowStock),
      icon: "alert-circle",
      color: stats.lowStock > 5 ? "#dc2626" : "#f59e0b",
      bg: stats.lowStock > 5 ? "#fef2f2" : "#fffbeb",
      note: stats.lowStock > 0 ? "Needs reorder" : "All good",
    },
    {
      label: "Pending Cheques",
      value: String(stats.pendingCheques),
      icon: "document-text",
      color: "#b45309",
      bg: "#fffbeb",
      note: "Due soon",
    },
    {
      label: "Outstanding Debt",
      value: fmt(stats.creditBalance),
      icon: "people",
      color: "#7c3aed",
      bg: "#faf5ff",
      note: "Credit balance",
    },
    {
      label: "Active Products",
      value: String(stats.activeProducts),
      icon: "cube",
      color: "#0369a1",
      bg: "#e0f2fe",
      note: "Catalog size",
    },
  ];

  return (
    <ScrollView
      style={styles.screen}
      contentContainerStyle={styles.container}
      showsVerticalScrollIndicator={false}
      refreshControl={
        <RefreshControl refreshing={refreshing} onRefresh={() => load(true)} tintColor="#0f766e" />
      }
    >
      {/* Hero Section */}
      <View style={styles.hero}>
        <View style={styles.heroGlow1} />
        <View style={styles.heroGlow2} />
        <View style={styles.heroContent}>
          <Text style={styles.heroKicker}>WELCOME BACK</Text>
          <Text style={styles.heroName}>{user?.displayName ?? "User"}</Text>
          <Text style={styles.heroDate}>{today}</Text>
          <View style={styles.storeBadge}>
            <View style={styles.storeDot} />
            <Text style={styles.storeBadgeText}>Store Active</Text>
          </View>
        </View>
        <View style={styles.heroActions}>
          <TouchableOpacity
            style={styles.heroPrimaryBtn}
            onPress={() => router.push("/(tabs)/pos" as any)}
            activeOpacity={0.85}
          >
            <Ionicons name="add" size={16} color="#fff" />
            <Text style={styles.heroPrimaryBtnText}>New POS Order</Text>
          </TouchableOpacity>
          <TouchableOpacity
            style={styles.heroSecondaryBtn}
            onPress={() => router.push("/(tabs)/credit-customers" as any)}
            activeOpacity={0.85}
          >
            <Ionicons name="person-add" size={15} color="#0f172a" />
            <Text style={styles.heroSecondaryBtnText}>Add Customer</Text>
          </TouchableOpacity>
        </View>
      </View>

      {/* KPI Cards */}
      {loading ? (
        <View style={styles.kpiLoadingContainer}>
          <ActivityIndicator color="#0f766e" size="large" />
          <Text style={styles.kpiLoadingText}>Loading dashboard data...</Text>
        </View>
      ) : (
        <View style={styles.kpiGrid}>
          {KPI_CARDS.map((kpi) => (
            <View key={kpi.label} style={[styles.kpiCard, { backgroundColor: kpi.bg }]}>
              <View style={[styles.kpiIconWrap, { backgroundColor: `${kpi.color}20` }]}>
                <Ionicons name={kpi.icon as any} size={20} color={kpi.color} />
              </View>
              <Text style={[styles.kpiValue, { color: kpi.color }]}>{kpi.value}</Text>
              <Text style={styles.kpiLabel}>{kpi.label}</Text>
              <Text style={styles.kpiNote}>{kpi.note}</Text>
            </View>
          ))}
        </View>
      )}

      {/* Recent POS Invoices */}
      {recentSales.length > 0 && (
        <View style={styles.sectionCard}>
          <View style={styles.sectionHeader}>
            <Text style={styles.sectionTitle}>Recent POS Invoices</Text>
            <TouchableOpacity onPress={() => router.push("/(tabs)/pos" as any)}>
              <Text style={styles.sectionLink}>View All</Text>
            </TouchableOpacity>
          </View>
          {recentSales.map((sale) => (
            <View key={sale.id} style={styles.saleRow}>
              <View style={styles.saleIconWrap}>
                <Ionicons name="receipt-outline" size={18} color="#0f766e" />
              </View>
              <View style={{ flex: 1 }}>
                <Text style={styles.saleId}>{sale.invoiceNo ?? sale.publicId ?? sale.id}</Text>
                <Text style={styles.saleMeta}>
                  {sale.paymentType ?? "CASH"} • {new Date(sale.createdAt).toLocaleDateString()}
                </Text>
              </View>
              <Text style={styles.saleAmount}>{fmt(sale.totalAmount)}</Text>
            </View>
          ))}
        </View>
      )}

      {/* Low Stock Watchlist */}
      {lowStockProducts.length > 0 && (
        <View style={styles.sectionCard}>
          <View style={styles.sectionHeader}>
            <Text style={styles.sectionTitle}>Low Stock Watchlist</Text>
            <TouchableOpacity onPress={() => router.push("/(tabs)/inventory" as any)}>
              <Text style={styles.sectionLink}>View All</Text>
            </TouchableOpacity>
          </View>
          {lowStockProducts.map((product) => (
            <View key={product.id} style={styles.stockRow}>
              <View style={styles.stockIconWrap}>
                <Ionicons name="cube-outline" size={18} color="#ef4444" />
              </View>
              <View style={{ flex: 1 }}>
                <Text style={styles.stockName}>{product.name}</Text>
                <Text style={styles.stockMeta}>Reorder at {product.reorder} units</Text>
              </View>
              <View style={styles.stockBadge}>
                <Text style={styles.stockBadgeText}>{product.totalRetailUnits} left</Text>
              </View>
            </View>
          ))}
        </View>
      )}


    </ScrollView>
  );
}

const styles = StyleSheet.create({
  screen: { flex: 1, backgroundColor: "#f4f7fb" },
  container: { padding: 16, gap: 16, paddingBottom: 32 },

  // Hero
  hero: {
    backgroundColor: "#0f172a", borderRadius: 28, padding: 22,
    overflow: "hidden", gap: 16,
  },
  heroGlow1: {
    position: "absolute", top: -40, right: -30,
    width: 160, height: 160, borderRadius: 80,
    backgroundColor: "rgba(15,118,110,0.28)",
  },
  heroGlow2: {
    position: "absolute", bottom: -30, left: 40,
    width: 120, height: 120, borderRadius: 60,
    backgroundColor: "rgba(59,130,246,0.15)",
  },
  heroContent: { zIndex: 1, gap: 6 },
  heroKicker: { color: "#5eead4", fontSize: 10, fontWeight: "800", letterSpacing: 2 },
  heroName: { color: "#ffffff", fontSize: 24, fontWeight: "900" },
  heroDate: { color: "#64748b", fontSize: 13 },
  storeBadge: {
    flexDirection: "row", alignItems: "center", gap: 6,
    alignSelf: "flex-start",
    backgroundColor: "rgba(16,185,129,0.15)",
    paddingHorizontal: 10, paddingVertical: 5,
    borderRadius: 999, marginTop: 4,
  },
  storeDot: { width: 6, height: 6, borderRadius: 3, backgroundColor: "#10b981" },
  storeBadgeText: { color: "#10b981", fontSize: 11, fontWeight: "700" },
  heroActions: { flexDirection: "row", gap: 10, zIndex: 1 },
  heroPrimaryBtn: {
    flexDirection: "row", alignItems: "center", gap: 6,
    backgroundColor: "#0f766e", borderRadius: 14,
    paddingHorizontal: 16, paddingVertical: 11,
  },
  heroPrimaryBtnText: { color: "#fff", fontWeight: "800", fontSize: 13 },
  heroSecondaryBtn: {
    flexDirection: "row", alignItems: "center", gap: 6,
    backgroundColor: "#ffffff", borderRadius: 14,
    paddingHorizontal: 14, paddingVertical: 11,
  },
  heroSecondaryBtnText: { color: "#0f172a", fontWeight: "700", fontSize: 13 },

  // KPI
  kpiLoadingContainer: { alignItems: "center", paddingVertical: 32, gap: 12 },
  kpiLoadingText: { color: "#94a3b8", fontSize: 13 },
  kpiGrid: { flexDirection: "row", flexWrap: "wrap", gap: 10 },
  kpiCard: {
    width: "47.5%", borderRadius: 20, padding: 16, gap: 6,
    shadowColor: "#0f172a", shadowOpacity: 0.04, shadowRadius: 8, elevation: 2,
  },
  kpiIconWrap: { width: 40, height: 40, borderRadius: 12, alignItems: "center", justifyContent: "center" },
  kpiValue: { fontSize: 18, fontWeight: "900", marginTop: 4 },
  kpiLabel: { color: "#0f172a", fontSize: 13, fontWeight: "700" },
  kpiNote: { color: "#94a3b8", fontSize: 11 },

  // Section Cards
  sectionCard: {
    backgroundColor: "#fff", borderRadius: 20, padding: 16,
    shadowColor: "#0f172a", shadowOpacity: 0.04, shadowRadius: 8, elevation: 2, gap: 10,
  },
  sectionHeader: { flexDirection: "row", alignItems: "center", justifyContent: "space-between" },
  sectionTitle: { color: "#0f172a", fontSize: 16, fontWeight: "800" },
  sectionLink: { color: "#0f766e", fontSize: 13, fontWeight: "700" },
  sectionSub: { color: "#94a3b8", fontSize: 12 },

  // Recent Sales
  saleRow: {
    flexDirection: "row", alignItems: "center", gap: 12,
    paddingVertical: 10, borderBottomWidth: 1, borderBottomColor: "#f1f5f9",
  },
  saleIconWrap: { width: 36, height: 36, borderRadius: 10, backgroundColor: "#f0fdfa", alignItems: "center", justifyContent: "center" },
  saleId: { color: "#0f172a", fontWeight: "700", fontSize: 14 },
  saleMeta: { color: "#94a3b8", fontSize: 11, marginTop: 2 },
  saleAmount: { color: "#0f766e", fontWeight: "800", fontSize: 14 },

  // Low Stock
  stockRow: {
    flexDirection: "row", alignItems: "center", gap: 12,
    paddingVertical: 10, borderBottomWidth: 1, borderBottomColor: "#f1f5f9",
  },
  stockIconWrap: { width: 36, height: 36, borderRadius: 10, backgroundColor: "#fef2f2", alignItems: "center", justifyContent: "center" },
  stockName: { color: "#0f172a", fontWeight: "700", fontSize: 14 },
  stockMeta: { color: "#94a3b8", fontSize: 11, marginTop: 2 },
  stockBadge: { backgroundColor: "#fef2f2", borderRadius: 8, paddingHorizontal: 10, paddingVertical: 5 },
  stockBadgeText: { color: "#ef4444", fontWeight: "800", fontSize: 12 },

});
