import React, { useState } from 'react';
import { View, Text, StyleSheet, TextInput, TouchableOpacity, ScrollView, ActivityIndicator, Alert } from 'react-native';
import { IconSymbol } from '@/components/ui/icon-symbol';

const API_BASE_URL = process.env.EXPO_PUBLIC_API_URL || 'http://10.118.221.102:8000/api';

export default function CreditScreen() {
  const [formData, setFormData] = useState({
    credit_limit: '50000',
    current_outstanding_balance: '15000',
    avg_bill_amount: '12000',
    total_paid: '10000',
    payment_ratio: '0.8',
    num_late_payments: '1',
    avg_delay: '5',
    max_delay: '15',
    recent_delay: '2',
    credit_utilization: '0.3'
  });

  const [loading, setLoading] = useState(false);
  const [result, setResult] = useState(null);

  const checkRisk = async () => {
    try {
      setLoading(true);
      const response = await fetch(`${API_BASE_URL}/ai/predict-credit`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(formData)
      });

      const json = await response.json();
      if (json.success) {
        setResult(json.data);
      } else {
        Alert.alert('Error', json.message || 'Failed to analyze risk');
      }
    } catch (error) {
      Alert.alert('Error', 'AI Service not reachable');
    } finally {
      setLoading(false);
    }
  };

  const renderInput = (label, key, placeholder) => (
    <View style={styles.inputGroup}>
      <Text style={styles.label}>{label}</Text>
      <TextInput
        style={styles.input}
        value={formData[key]}
        onChangeText={(v) => setFormData({ ...formData, [key]: v })}
        placeholder={placeholder}
        keyboardType="numeric"
      />
    </View>
  );

  return (
    <View style={styles.container}>
      <View style={styles.header}>
        <Text style={styles.headerTitle}>AI Credit Risk Assessment</Text>
      </View>

      <ScrollView style={styles.content}>
        <View style={styles.card}>
          <Text style={styles.cardTitle}>Customer Credit Profile</Text>
          {renderInput('Credit Limit (Rs.)', 'credit_limit', '50000')}
          {renderInput('Outstanding Balance (Rs.)', 'current_outstanding_balance', '15000')}
          {renderInput('Avg Bill Amount (Rs.)', 'avg_bill_amount', '12000')}
          {renderInput('Total Paid (Rs.)', 'total_paid', '10000')}
          {renderInput('Payment Ratio (0-1)', 'payment_ratio', '0.8')}
          {renderInput('Credit Utilization (0-1)', 'credit_utilization', '0.3')}
          {renderInput('Num Late Payments', 'num_late_payments', '1')}
          {renderInput('Avg Delay (Days)', 'avg_delay', '5')}
          {renderInput('Max Delay (Days)', 'max_delay', '15')}
          {renderInput('Recent Delay (Days)', 'recent_delay', '2')}
          
          <TouchableOpacity style={styles.button} onPress={checkRisk} disabled={loading}>
            {loading ? <ActivityIndicator color="#fff" /> : <Text style={styles.buttonText}>Analyze Risk</Text>}
          </TouchableOpacity>
        </View>

        {result && (
          <View style={[styles.resultCard, result.risk === 'High' ? styles.highRisk : styles.lowRisk]}>
            <View style={styles.resultHeader}>
              <IconSymbol 
                name={result.risk === 'High' ? 'paperplane.fill' : 'plus.circle.fill'} 
                size={32} 
                color={result.risk === 'High' ? '#EF4444' : '#10B981'} 
              />
              <View style={styles.resultMeta}>
                <Text style={styles.resultLabel}>Risk Level</Text>
                <Text style={[styles.resultValue, result.risk === 'High' ? styles.highText : styles.lowText]}>
                  {result.risk} Risk
                </Text>
              </View>
            </View>
            
            <View style={styles.divider} />
            
            <View style={styles.statRow}>
              <View style={styles.stat}>
                <Text style={styles.statLabel}>Probability</Text>
                <Text style={styles.statValue}>{(result.probability * 100).toFixed(1)}%</Text>
              </View>
              <View style={styles.stat}>
                <Text style={styles.statLabel}>Confidence</Text>
                <Text style={styles.statValue}>{result.confidence}%</Text>
              </View>
            </View>

            <Text style={styles.recommendation}>
              {result.risk === 'High' 
                ? 'CAUTION: This customer has a high probability of default. Consider reducing credit limit or requiring immediate payment.'
                : 'SAFE: This customer shows healthy repayment patterns. You can proceed with standard credit terms.'}
            </Text>
          </View>
        )}
      </ScrollView>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#F3F4F6',
  },
  header: {
    paddingTop: 60,
    paddingBottom: 20,
    backgroundColor: '#ffffff',
    alignItems: 'center',
    borderBottomWidth: 1,
    borderBottomColor: '#E5E7EB',
  },
  headerTitle: {
    fontSize: 20,
    fontWeight: 'bold',
    color: '#111827',
  },
  content: {
    padding: 16,
  },
  card: {
    backgroundColor: '#ffffff',
    padding: 20,
    borderRadius: 16,
    marginBottom: 20,
  },
  cardTitle: {
    fontSize: 18,
    fontWeight: 'bold',
    color: '#111827',
    marginBottom: 20,
  },
  inputGroup: {
    marginBottom: 16,
  },
  label: {
    fontSize: 14,
    color: '#4B5563',
    marginBottom: 8,
  },
  input: {
    backgroundColor: '#F9FAFB',
    borderWidth: 1,
    borderColor: '#D1D5DB',
    borderRadius: 8,
    padding: 12,
    fontSize: 16,
  },
  button: {
    backgroundColor: '#111827',
    padding: 16,
    borderRadius: 12,
    alignItems: 'center',
    marginTop: 10,
  },
  buttonText: {
    color: '#ffffff',
    fontSize: 16,
    fontWeight: 'bold',
  },
  resultCard: {
    padding: 20,
    borderRadius: 16,
    marginBottom: 40,
    borderWidth: 1,
  },
  highRisk: {
    backgroundColor: '#FEF2F2',
    borderColor: '#FECACA',
  },
  lowRisk: {
    backgroundColor: '#F0FDF4',
    borderColor: '#BBF7D0',
  },
  resultHeader: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  resultMeta: {
    marginLeft: 16,
  },
  resultLabel: {
    fontSize: 12,
    color: '#6B7280',
    textTransform: 'uppercase',
  },
  resultValue: {
    fontSize: 24,
    fontWeight: 'bold',
  },
  highText: { color: '#B91C1C' },
  lowText: { color: '#15803D' },
  divider: {
    height: 1,
    backgroundColor: '#E5E7EB',
    marginVertical: 16,
  },
  statRow: {
    flexDirection: 'row',
    justifyContent: 'space-around',
  },
  stat: {
    alignItems: 'center',
  },
  statLabel: {
    fontSize: 12,
    color: '#6B7280',
  },
  statValue: {
    fontSize: 18,
    fontWeight: 'bold',
    color: '#111827',
  },
  recommendation: {
    marginTop: 16,
    fontSize: 13,
    color: '#4B5563',
    fontStyle: 'italic',
    lineHeight: 18,
    textAlign: 'center',
  }
});
