// @ts-nocheck
import { BASE_URL, getAuthToken } from "@/services/api";
import { Ionicons } from "@expo/vector-icons";
import { useEffect, useState } from "react";
import {
  ActivityIndicator,
  Alert,
  Modal,
  ScrollView,
  StyleSheet,
  Text,
  TextInput,
  TouchableOpacity,
  View,
  Platform,
} from "react-native";
import DateTimePicker from "@react-native-community/datetimepicker";
import SearchableDropdown from "@/components/searchable-dropdown";

const apiHeaders = () => ({
  "Content-Type": "application/json",
  ...(getAuthToken() ? { Authorization: `Bearer ${getAuthToken()}` } : {}),
});

const fetchCheques = async (params: any = {}) => {
  const q = new URLSearchParams(Object.entries(params).filter(([, v]) => v != null).map(([k, v]) => [k, String(v)]));
  const res = await fetch(`${BASE_URL}/cheques?${q.toString()}`, { headers: apiHeaders() });
  const data = await res.json();
  return data?.data?.content ?? data?.data ?? data?.content ?? [];
};

const fetchCreditCustomers = async () => {
  const res = await fetch(`${BASE_URL}/credit-customers?status=ACTIVE&size=1000`, { headers: apiHeaders() });
  const data = await res.json();
  return data?.data?.content ?? data?.data ?? data?.content ?? [];
};

const fetchSuppliers = async () => {
  const res = await fetch(`${BASE_URL}/suppliers?size=1000`, { headers: apiHeaders() });
  const data = await res.json();
  return data?.data?.content ?? data?.data ?? data?.content ?? [];
};

const saveCheque = async (payload: any, id?: string) => {
  const res = await fetch(`${BASE_URL}/cheques${id ? `/${id}` : ""}`, {
    method: id ? "PUT" : "POST",
    headers: apiHeaders(),
    body: JSON.stringify(payload),
  });
  const data = await res.json();
  if (!res.ok) throw new Error(data?.message ?? "Failed to save cheque");
  return data;
};

const deleteCheque = async (id: string) => {
  const res = await fetch(`${BASE_URL}/cheques/${id}`, { method: "DELETE", headers: apiHeaders() });
  if (!res.ok) {
    const data = await res.json();
    throw new Error(data?.message ?? "Failed to delete cheque");
  }
};

const STATUS_COLORS: Record<string, string> = {
  PENDING: "#f59e0b",
  DEPOSITED: "#3b82f6",
  CLEARED: "#10b981",
  BOUNCED: "#ef4444",
  CANCELLED: "#64748b",
};

const BANKS = [
  "BOC", "People's Bank", "Commercial Bank", "HNB", "Sampath Bank", 
  "Seylan Bank", "NDB", "NTB", "Pan Asia Bank", "DFCC Bank",
  "Standard Chartered", "HSBC", "Cargills Bank", "Amana Bank", "Union Bank"
].map(b => ({ label: b, value: b }));

const MAIN_BRANCHES = [
  "Head Office", "Colombo 01", "Colombo 02", "Colombo 03", "Colombo 04", "Colombo 05", "Colombo 06", 
  "Bambalapitiya", "Kollupitiya", "Wellawatte", "Nugegoda", "Maharagama", 
  "Dehiwala", "Mount Lavinia", "Moratuwa", "Panadura", "Galle", "Kandy", 
  "Kurunegala", "Gampaha", "Negombo", "Matara", "Jaffna", "Batticaloa", 
  "Trincomalee", "Anuradhapura", "Polonnaruwa", "Badulla", "Nuwara Eliya", 
  "Ratnapura", "Kegalle", "Avissawella", "Homagama", "Kaduwela", "Malabe", 
  "Battaramulla", "Rajagiriya", "Nawala", "Kohuwala", "Boralesgamuwa", 
  "Piliyandala", "Wattala", "Kelaniya", "Kiribathgoda", "Kadawatha", 
  "Ja-Ela", "Minuwangoda", "Peliyagoda"
];

const STATUS_OPTIONS = [
  { label: "PENDING", value: "PENDING" },
  { label: "DEPOSITED", value: "DEPOSITED" },
  { label: "CLEARED", value: "CLEARED" },
  { label: "BOUNCED", value: "BOUNCED" }
];

const CHEQUE_TYPE_OPTIONS = [
  { label: "Incoming (From Customer)", value: "Incoming" },
  { label: "Outgoing (To Supplier)", value: "Outgoing" }
];

export default function ChequesScreen() {
  const [cheques, setCheques] = useState<any[]>([]);
  const [creditCustomers, setCreditCustomers] = useState<any[]>([]);
  const [suppliers, setSuppliers] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState("");
  const [modalVisible, setModalVisible] = useState(false);
  const [saving, setSaving] = useState(false);
  const [editId, setEditId] = useState<string | null>(null);
  const [showIssuePicker, setShowIssuePicker] = useState(false);
  const [showDuePicker, setShowDuePicker] = useState(false);
  const [form, setForm] = useState({
    chequeNumber: "",
    bankName: "",
    amount: "",
    dueDate: "",
    payeeName: "",
    status: "PENDING",
    note: "",
    branch: "",
    chequeType: "Incoming",
    issueDate: new Date().toISOString().slice(0, 10),
    customerId: null as string | null,
    supplierId: null as string | null
  });

  const load = async () => {
    setLoading(true);
    try {
      const [data, custData, suppData] = await Promise.all([
        fetchCheques({ size: 1000 }),
        fetchCreditCustomers(),
        fetchSuppliers()
      ]);
      setCheques(Array.isArray(data) ? data : []);
      setCreditCustomers(Array.isArray(custData) ? custData : []);
      setSuppliers(Array.isArray(suppData) ? suppData : []);
    } catch {
      setCheques([]);
      setCreditCustomers([]);
      setSuppliers([]);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => { load(); }, []);

  const filtered = cheques.filter(
    (c) =>
      c.chequeNumber?.toLowerCase().includes(search.toLowerCase()) ||
      c.bankName?.toLowerCase().includes(search.toLowerCase()) ||
      c.payeeName?.toLowerCase().includes(search.toLowerCase())
  );

  const openCreate = () => {
    setEditId(null);
    setForm({ chequeNumber: "", bankName: "", amount: "", dueDate: "", payeeName: "", status: "PENDING", note: "", branch: "", chequeType: "Incoming", issueDate: new Date().toISOString().slice(0, 10), customerId: null, supplierId: null });
    setModalVisible(true);
  };

  const openEdit = (cheque: any) => {
    setEditId(cheque.id ?? cheque._id);
    setForm({
      chequeNumber: cheque.chequeNumber || "",
      bankName: cheque.bankName || "",
      amount: String(cheque.amount || ""),
      dueDate: cheque.dueDate ? cheque.dueDate.slice(0, 10) : "",
      payeeName: cheque.payeeName || "",
      status: cheque.status || "PENDING",
      note: cheque.note || "",
      branch: cheque.branch || "",
      chequeType: cheque.chequeType || "Incoming",
      issueDate: cheque.issueDate ? cheque.issueDate.slice(0, 10) : "",
      customerId: cheque.customerId || cheque.customer?._id || cheque.customer || null,
      supplierId: cheque.supplierId || cheque.supplier?._id || cheque.supplier || null
    });
    setModalVisible(true);
  };

  const handleSave = async () => {
    if (!form.chequeNumber || !form.amount) return Alert.alert("Error", "Cheque number and Amount are required");
    setSaving(true);
    try {
      const payload = { ...form, amount: Number(form.amount) };
      await saveCheque(payload, editId || undefined);
      setModalVisible(false);
      load();
    } catch (e: any) {
      Alert.alert("Error", e.message);
    } finally {
      setSaving(false);
    }
  };

  const handleDelete = (cheque: any) => {
    Alert.alert("Delete Cheque", `Delete cheque "${cheque.chequeNumber}"?`, [
      { text: "Cancel", style: "cancel" },
      { text: "Delete", style: "destructive", onPress: async () => {
          try {
            await deleteCheque(cheque.id ?? cheque._id);
            load();
          } catch (e: any) { Alert.alert("Error", e.message); }
        }
      },
    ]);
  };

  const formatCurrency = (val: any) => `Rs.${Number(val || 0).toLocaleString()}`;

  const uniqueBranches = Array.from(new Set([
    ...MAIN_BRANCHES,
    ...cheques.map(c => c.branch).filter(Boolean)
  ])).map(b => ({ label: String(b), value: String(b) }));

  return (
    <View style={styles.screen}>
      {/* Header */}
      <View style={styles.headerCard}>
        <View style={styles.headerIcon}>
          <Ionicons name="document-text" size={22} color="#fff" />
        </View>
        <View style={{ flex: 1 }}>
          <Text style={styles.headerTitle}>Cheques Management</Text>
          <Text style={styles.headerSub}>Real-time banking instrumentation</Text>
        </View>
        <TouchableOpacity style={styles.addBtn} onPress={openCreate} activeOpacity={0.8}>
          <Ionicons name="add" size={20} color="#fff" />
          <Text style={styles.addBtnText}>New Cheque</Text>
        </TouchableOpacity>
      </View>

      {/* Search */}
      <View style={styles.searchRow}>
        <Ionicons name="search" size={18} color="#94a3b8" />
        <TextInput
          style={styles.searchInput}
          placeholder="Search number, bank, or payee..."
          placeholderTextColor="#94a3b8"
          value={search}
          onChangeText={setSearch}
        />
      </View>

      {loading ? (
        <ActivityIndicator size="large" color="#0f766e" style={{ marginTop: 40 }} />
      ) : (
        <ScrollView style={{ flex: 1 }} contentContainerStyle={styles.list} showsVerticalScrollIndicator={false}>
          {filtered.length === 0 ? (
            <View style={styles.empty}>
              <Ionicons name="document-text-outline" size={48} color="#e2e8f0" />
              <Text style={styles.emptyText}>No cheques recorded</Text>
            </View>
          ) : (
            filtered.map((cheque) => {
              const statusColor = STATUS_COLORS[cheque.status] || "#64748b";
              const isOverdue = cheque.status === "PENDING" && new Date(cheque.dueDate) < new Date();

              return (
                <View key={cheque.id ?? cheque._id} style={styles.card}>
                  <TouchableOpacity 
                    style={{ flex: 1 }} 
                    onPress={() => openEdit(cheque)} 
                    activeOpacity={0.7}
                  >
                    <View style={styles.cardTop}>
                      <View style={styles.bankTag}>
                        <Ionicons name="business-outline" size={12} color="#64748b" />
                        <Text style={styles.bankName}>{cheque.bankName || "Unknown Bank"}</Text>
                      </View>
                      <View style={[styles.statusBadge, { backgroundColor: `${statusColor}15` }]}>
                        <Text style={[styles.statusText, { color: statusColor }]}>{cheque.status}</Text>
                      </View>
                    </View>
                    
                    <View style={styles.cardBody}>
                      <View style={{ flex: 1 }}>
                        <Text style={styles.payeeName}>
                          {cheque.payeeName || 
                           (cheque.chequeType === 'Incoming' && creditCustomers.find(c => (c.id || c._id) === cheque.customerId)?.name) || 
                           (cheque.chequeType === 'Outgoing' && suppliers.find(s => (s.id || s._id) === cheque.supplierId)?.name) || 
                           "No Payee"}
                        </Text>
                        <Text style={styles.chequeNum}>No: {cheque.chequeNumber}</Text>
                      </View>
                      <Text style={styles.amountText}>{formatCurrency(cheque.amount)}</Text>
                    </View>

                    <View style={styles.cardFooter}>
                      <View style={styles.dueRow}>
                        <Ionicons name="calendar-outline" size={14} color={isOverdue ? "#ef4444" : "#94a3b8"} />
                        <Text style={[styles.dueDateText, isOverdue && { color: "#ef4444", fontWeight: "700" }]}>
                          Due: {cheque.dueDate ? new Date(cheque.dueDate).toLocaleDateString() : "N/A"}
                          {isOverdue ? " (Overdue)" : ""}
                        </Text>
                      </View>
                    </View>
                  </TouchableOpacity>
                  
                  <View style={styles.cardActionsRow}>
                    <TouchableOpacity onPress={() => handleDelete(cheque)} style={styles.deleteActionBtn}>
                      <Ionicons name="trash-outline" size={18} color="#ef4444" />
                    </TouchableOpacity>
                  </View>
                </View>
              );
            })
          )}
        </ScrollView>
      )}

      {/* Cheque Modal */}
      <Modal visible={modalVisible} animationType="slide" transparent onRequestClose={() => setModalVisible(false)}>
        <View style={styles.modalOverlay}>
          <View style={styles.modalCard}>
            <View style={styles.modalHeader}>
              <Text style={styles.modalTitle}>{editId ? "Update Instrument" : "Register Cheque"}</Text>
              <TouchableOpacity onPress={() => setModalVisible(false)}>
                <Ionicons name="close" size={22} color="#64748b" />
              </TouchableOpacity>
            </View>

            <ScrollView contentContainerStyle={{ gap: 14 }} showsVerticalScrollIndicator={false}>
              <View style={styles.row}>
                <View style={[styles.fieldGroup, { flex: 1.2 }]}>
                  <Text style={styles.fieldLabel}>Cheque Number *</Text>
                  <TextInput style={styles.fieldInput} value={form.chequeNumber} onChangeText={(v) => setForm({...form, chequeNumber: v})} placeholder="CX-123456" />
                </View>
                <View style={[styles.fieldGroup, { flex: 1 }]}>
                  <SearchableDropdown
                    label="Status"
                    placeholder="Search status..."
                    items={STATUS_OPTIONS}
                    value={form.status}
                    onValueChange={(val) => setForm({...form, status: val})}
                  />
                </View>
              </View>

              <SearchableDropdown
                label="Bank Name *"
                placeholder="Search bank..."
                items={BANKS}
                value={form.bankName}
                onValueChange={(val) => setForm({...form, bankName: val})}
                allowCustom
              />

              <SearchableDropdown
                label="Branch Name"
                placeholder="Search branch..."
                items={uniqueBranches}
                value={form.branch}
                onValueChange={(val) => setForm({...form, branch: val})}
                allowCustom
              />

              {form.chequeType === "Incoming" && (
                <SearchableDropdown
                  label="Customer (Incoming)"
                  placeholder="Select customer..."
                  items={creditCustomers.map(c => ({ label: `${c.name} (${c.phone})`, value: c.id || c._id }))}
                  value={form.customerId}
                  onValueChange={(val) => {
                    const c = creditCustomers.find(cust => (cust.id || cust._id) === val);
                    setForm({...form, customerId: val, payeeName: c ? c.name : form.payeeName});
                  }}
                />
              )}

              {form.chequeType === "Outgoing" && (
                <SearchableDropdown
                  label="Supplier (Outgoing)"
                  placeholder="Select supplier..."
                  items={suppliers.map(s => ({ label: `${s.name} (${s.contactNumber || s.phone || ''})`, value: s.id || s._id }))}
                  value={form.supplierId}
                  onValueChange={(val) => {
                    const s = suppliers.find(sup => (sup.id || sup._id) === val);
                    setForm({...form, supplierId: val, payeeName: s ? s.name : form.payeeName});
                  }}
                />
              )}

              <View style={styles.row}>
                <View style={[styles.fieldGroup, { flex: 1 }]}>
                  <SearchableDropdown
                    label="Type"
                    placeholder="Select type..."
                    items={CHEQUE_TYPE_OPTIONS}
                    value={form.chequeType}
                    onValueChange={(val) => setForm({...form, chequeType: val})}
                  />
                </View>
                <View style={[styles.fieldGroup, { flex: 1 }]}>
                  <Text style={styles.fieldLabel}>Issue Date</Text>
                  <TouchableOpacity 
                    style={styles.fieldInput} 
                    onPress={() => setShowIssuePicker(true)}
                    activeOpacity={0.7}
                  >
                    <Text style={{ color: form.issueDate ? "#0f172a" : "#94a3b8" }}>
                      {form.issueDate || "Select Date"}
                    </Text>
                  </TouchableOpacity>
                  {showIssuePicker && (
                    <DateTimePicker
                      value={form.issueDate ? new Date(form.issueDate) : new Date()}
                      mode="date"
                      display={Platform.OS === 'ios' ? 'spinner' : 'default'}
                      onChange={(event, selectedDate) => {
                        setShowIssuePicker(false);
                        if (selectedDate) setForm({ ...form, issueDate: selectedDate.toISOString().split('T')[0] });
                      }}
                    />
                  )}
                </View>
              </View>

              <View style={styles.row}>
                <View style={[styles.fieldGroup, { flex: 1 }]}>
                  <Text style={styles.fieldLabel}>Amount (LKR) *</Text>
                  <TextInput style={styles.fieldInput} value={form.amount} onChangeText={(v) => setForm({...form, amount: v})} keyboardType="numeric" placeholder="0.00" />
                </View>
                <View style={[styles.fieldGroup, { flex: 1 }]}>
                  <Text style={styles.fieldLabel}>Due Date</Text>
                  <TouchableOpacity 
                    style={styles.fieldInput} 
                    onPress={() => setShowDuePicker(true)}
                    activeOpacity={0.7}
                  >
                    <Text style={{ color: form.dueDate ? "#0f172a" : "#94a3b8" }}>
                      {form.dueDate || "Select Date"}
                    </Text>
                  </TouchableOpacity>
                  {showDuePicker && (
                    <DateTimePicker
                      value={form.dueDate ? new Date(form.dueDate) : new Date()}
                      mode="date"
                      display={Platform.OS === 'ios' ? 'spinner' : 'default'}
                      onChange={(event, selectedDate) => {
                        setShowDuePicker(false);
                        if (selectedDate) setForm({ ...form, dueDate: selectedDate.toISOString().split('T')[0] });
                      }}
                    />
                  )}
                </View>
              </View>



            </ScrollView>

            <TouchableOpacity style={styles.saveBtn} onPress={handleSave} disabled={saving} activeOpacity={0.85}>
              {saving ? <ActivityIndicator color="#fff" /> : <Text style={styles.saveBtnText}>{editId ? "Update Cheque" : "Save Cheque"}</Text>}
            </TouchableOpacity>
          </View>
        </View>
      </Modal>
    </View>
  );
}

const styles = StyleSheet.create({
  screen: { flex: 1, backgroundColor: "#f4f7fb" },
  headerCard: {
    backgroundColor: "#0f172a", margin: 16, borderRadius: 20,
    padding: 18, flexDirection: "row", alignItems: "center", gap: 14,
  },
  headerIcon: { width: 44, height: 44, borderRadius: 14, backgroundColor: "#b45309", alignItems: "center", justifyContent: "center" },
  headerTitle: { color: "#fff", fontSize: 16, fontWeight: "800" },
  headerSub: { color: "#94a3b8", fontSize: 12, marginTop: 2 },
  addBtn: { flexDirection: "row", alignItems: "center", gap: 6, backgroundColor: "#0f766e", borderRadius: 12, paddingHorizontal: 16, paddingVertical: 10 },
  addBtnText: { color: "#fff", fontWeight: "700", fontSize: 13 },
  searchRow: {
    flexDirection: "row", alignItems: "center", gap: 10,
    backgroundColor: "#fff", borderRadius: 14, marginHorizontal: 16, marginBottom: 12,
    paddingHorizontal: 14, paddingVertical: 12,
    shadowColor: "#0f172a", shadowOpacity: 0.04, shadowRadius: 8, elevation: 2,
  },
  searchInput: { flex: 1, color: "#0f172a", fontSize: 14 },
  list: { padding: 16, paddingTop: 4, gap: 12 },
  empty: { alignItems: "center", paddingTop: 60, gap: 12 },
  emptyText: { color: "#94a3b8", fontSize: 14, fontWeight: "600" },
  card: {
    flexDirection: "row",
    backgroundColor: "#fff", borderRadius: 20, padding: 16, gap: 12,
    shadowColor: "#0f172a", shadowOpacity: 0.05, shadowRadius: 10, elevation: 2,
  },
  cardTop: { flexDirection: "row", justifyContent: "space-between", alignItems: "center" },
  bankTag: { flexDirection: "row", alignItems: "center", gap: 6 },
  bankName: { color: "#64748b", fontSize: 11, fontWeight: "700", textTransform: "uppercase" },
  statusBadge: { borderRadius: 8, paddingHorizontal: 8, paddingVertical: 4 },
  statusText: { fontSize: 10, fontWeight: "800" },
  cardBody: { flexDirection: "row", alignItems: "center", justifyContent: "space-between", borderBottomWidth: 1, borderBottomColor: "#f1f5f9", paddingBottom: 12 },
  payeeName: { color: "#0f172a", fontWeight: "800", fontSize: 15 },
  chequeNum: { color: "#94a3b8", fontSize: 12, marginTop: 2 },
  amountText: { color: "#0f766e", fontWeight: "900", fontSize: 17 },
  cardFooter: { flexDirection: "row", justifyContent: "space-between", alignItems: "center" },
  dueRow: { flexDirection: "row", alignItems: "center", gap: 6 },
  dueDateText: { fontSize: 12, color: "#64748b" },
  cardActionsRow: { borderLeftWidth: 1, borderLeftColor: "#f1f5f9", paddingLeft: 16, justifyContent: "center" },
  deleteActionBtn: { padding: 8, backgroundColor: "#fef2f2", borderRadius: 10 },
  modalOverlay: { flex: 1, backgroundColor: "rgba(0,0,0,0.4)", justifyContent: "flex-end" },
  modalCard: { backgroundColor: "#fff", borderTopLeftRadius: 28, borderTopRightRadius: 28, padding: 24, gap: 18, maxHeight: "90%" },
  modalHeader: { flexDirection: "row", alignItems: "center", justifyContent: "space-between" },
  modalTitle: { color: "#0f172a", fontSize: 20, fontWeight: "800" },
  fieldGroup: { gap: 6 },
  fieldLabel: { color: "#64748b", fontSize: 11, fontWeight: "700", textTransform: "uppercase", letterSpacing: 0.8 },
  fieldInput: { backgroundColor: "#f8fafc", borderRadius: 14, paddingHorizontal: 16, paddingVertical: 14, color: "#0f172a", fontSize: 15, borderWidth: 1, borderColor: "#e2e8f0" },
  row: { flexDirection: "row", gap: 12 },
  selectWrap: { backgroundColor: "#f8fafc", borderRadius: 14, paddingHorizontal: 16, paddingVertical: 14, borderWidth: 1, borderColor: "#e2e8f0", alignItems: "center" },
  selectText: { fontWeight: "800", fontSize: 14 },
  statusChips: { flexDirection: "row", flexWrap: "wrap", gap: 8 },
  statusChip: { borderWidth: 1, borderColor: "#e2e8f0", borderRadius: 10, paddingHorizontal: 10, paddingVertical: 6 },
  statusChipText: { fontSize: 10, fontWeight: "700", color: "#64748b" },
  saveBtn: { backgroundColor: "#0f766e", borderRadius: 16, paddingVertical: 16, alignItems: "center", marginTop: 8 },
  saveBtnText: { color: "#fff", fontWeight: "800", fontSize: 16 },
});
