import { BASE_URL, getAuthToken } from "@/services/api";
import { Ionicons } from "@expo/vector-icons";
import { useEffect, useState } from "react";
import {
  ActivityIndicator,
  Alert,
  Modal,
  ScrollView,
  StyleSheet,
  Text,
  TextInput,
  TouchableOpacity,
  View,
} from "react-native";

const apiHeaders = () => ({
  "Content-Type": "application/json",
  ...(getAuthToken() ? { Authorization: `Bearer ${getAuthToken()}` } : {}),
});

const fetchProducts = async () => {
  const res = await fetch(`${BASE_URL}/products?status=ACTIVE&size=1000`, { headers: apiHeaders() });
  const data = await res.json();
  return data?.data?.content ?? data?.data ?? data?.content ?? [];
};

const convertStock = async (payload: any) => {
  const res = await fetch(`${BASE_URL}/inventory/convert`, {
    method: "POST",
    headers: apiHeaders(),
    body: JSON.stringify(payload),
  });
  const data = await res.json();
  if (!res.ok) throw new Error(data?.message ?? "Conversion failed");
  return data;
};

export default function ConvertStockScreen() {
  const [products, setProducts] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [converting, setConverting] = useState(false);
  const [search, setSearch] = useState("");
  const [selectedProduct, setSelectedProduct] = useState<any>(null);
  const [qty, setQty] = useState("1");
  const [modalVisible, setModalVisible] = useState(false);

  const load = async () => {
    setLoading(true);
    try {
      const list = await fetchProducts();
      setProducts(Array.isArray(list) ? list : []);
    } catch {
      setProducts([]);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => { load(); }, []);

  const filtered = products.filter(
    (p) =>
      p.name?.toLowerCase().includes(search.toLowerCase()) ||
      p.publicId?.toLowerCase().includes(search.toLowerCase())
  );

  const openConvert = (product: any) => {
    setSelectedProduct(product);
    setQty("1");
    setModalVisible(true);
  };

  const handleConvert = async () => {
    if (!selectedProduct) return;
    const bulkQty = Number(qty);
    if (!bulkQty || bulkQty <= 0) {
      Alert.alert("Error", "Enter a valid quantity");
      return;
    }
    setConverting(true);
    try {
      await convertStock({ productId: selectedProduct.id ?? selectedProduct._id, bulkQty });
      Alert.alert("Success", `Converted ${bulkQty} bulk unit(s) for ${selectedProduct.name}`);
      setModalVisible(false);
      load();
    } catch (e: any) {
      Alert.alert("Error", e.message ?? "Conversion failed");
    } finally {
      setConverting(false);
    }
  };

  const getStockColor = (product: any) => {
    const retail = Number(product?.stockLevels?.retailQty ?? 0);
    const bulk = Number(product?.stockLevels?.bulkQty ?? 0);
    const factor = Number(product?.unitConfig?.conversionFactor ?? 1);
    const total = retail + bulk * factor;
    const reorder = Number(product?.reorderPoint ?? 10);
    return total <= reorder ? "#ef4444" : "#0f766e";
  };

  return (
    <View style={styles.screen}>
      {/* Header */}
      <View style={styles.headerCard}>
        <View style={styles.headerIcon}>
          <Ionicons name="swap-horizontal" size={22} color="#fff" />
        </View>
        <View style={{ flex: 1 }}>
          <Text style={styles.headerTitle}>Convert Stock</Text>
          <Text style={styles.headerSub}>Convert bulk units to retail inventory</Text>
        </View>
      </View>

      {/* Info Banner */}
      <View style={styles.infoBanner}>
        <Ionicons name="information-circle" size={18} color="#0369a1" />
        <Text style={styles.infoText}>
          Select a product to convert bulk stock into retail units using the configured conversion factor.
        </Text>
      </View>

      {/* Search */}
      <View style={styles.searchRow}>
        <Ionicons name="search" size={18} color="#94a3b8" />
        <TextInput
          style={styles.searchInput}
          placeholder="Search products..."
          placeholderTextColor="#94a3b8"
          value={search}
          onChangeText={setSearch}
        />
      </View>

      {loading ? (
        <ActivityIndicator size="large" color="#0f766e" style={{ marginTop: 40 }} />
      ) : (
        <ScrollView
          style={{ flex: 1 }}
          contentContainerStyle={styles.list}
          showsVerticalScrollIndicator={false}
        >
          {filtered.map((product) => {
            const bulkQty = Number(product?.stockLevels?.bulkQty ?? 0);
            const retailQty = Number(product?.stockLevels?.retailQty ?? 0);
            const factor = Number(product?.unitConfig?.conversionFactor ?? 1);
            const stockColor = getStockColor(product);

            return (
              <View key={product.id ?? product._id} style={styles.card}>
                <View style={styles.cardLeft}>
                  <View style={[styles.productIcon, { backgroundColor: `${stockColor}15` }]}>
                    <Ionicons name="cube" size={22} color={stockColor} />
                  </View>
                  <View style={{ flex: 1 }}>
                    <Text style={styles.productName}>{product.name}</Text>
                    <Text style={styles.productId}>{product.publicId}</Text>
                    <View style={styles.stockRow}>
                      <View style={styles.stockPill}>
                        <Text style={styles.stockPillLabel}>Bulk</Text>
                        <Text style={[styles.stockPillValue, { color: bulkQty <= 0 ? "#ef4444" : "#0f172a" }]}>
                          {bulkQty} {product.unitConfig?.bulkUnit ?? "Case"}
                        </Text>
                      </View>
                      <View style={styles.stockPill}>
                        <Text style={styles.stockPillLabel}>Retail</Text>
                        <Text style={[styles.stockPillValue, { color: stockColor }]}>
                          {retailQty} {product.unitConfig?.retailUnit ?? "Piece"}
                        </Text>
                      </View>
                      <View style={styles.stockPill}>
                        <Text style={styles.stockPillLabel}>Factor</Text>
                        <Text style={styles.stockPillValue}>×{factor}</Text>
                      </View>
                    </View>
                  </View>
                </View>
                <TouchableOpacity
                  style={[styles.convertBtn, bulkQty <= 0 && styles.convertBtnDisabled]}
                  onPress={() => openConvert(product)}
                  disabled={bulkQty <= 0}
                  activeOpacity={0.8}
                >
                  <Ionicons name="swap-horizontal" size={16} color={bulkQty <= 0 ? "#94a3b8" : "#fff"} />
                  <Text style={[styles.convertBtnText, bulkQty <= 0 && { color: "#94a3b8" }]}>
                    Convert
                  </Text>
                </TouchableOpacity>
              </View>
            );
          })}
        </ScrollView>
      )}

      {/* Convert Modal */}
      <Modal visible={modalVisible} animationType="slide" transparent onRequestClose={() => setModalVisible(false)}>
        <View style={styles.modalOverlay}>
          <View style={styles.modalCard}>
            <View style={styles.modalHeader}>
              <View>
                <Text style={styles.modalTitle}>Convert Stock</Text>
                <Text style={styles.modalSub}>{selectedProduct?.name}</Text>
              </View>
              <TouchableOpacity onPress={() => setModalVisible(false)}>
                <Ionicons name="close" size={22} color="#64748b" />
              </TouchableOpacity>
            </View>

            {selectedProduct && (
              <View style={styles.conversionInfo}>
                <View style={styles.convInfo}>
                  <Ionicons name="cube-outline" size={20} color="#7c3aed" />
                  <Text style={styles.convInfoLabel}>Bulk in Stock</Text>
                  <Text style={styles.convInfoValue}>
                    {selectedProduct.stockLevels?.bulkQty ?? 0} {selectedProduct.unitConfig?.bulkUnit ?? "Case"}
                  </Text>
                </View>
                <Ionicons name="arrow-forward" size={20} color="#94a3b8" />
                <View style={styles.convInfo}>
                  <Ionicons name="storefront-outline" size={20} color="#0f766e" />
                  <Text style={styles.convInfoLabel}>Retail per Bulk</Text>
                  <Text style={styles.convInfoValue}>
                    {selectedProduct.unitConfig?.conversionFactor ?? 1} {selectedProduct.unitConfig?.retailUnit ?? "Piece"}
                  </Text>
                </View>
              </View>
            )}

            <View style={styles.fieldGroup}>
              <Text style={styles.fieldLabel}>Bulk Quantity to Convert *</Text>
              <TextInput
                style={styles.fieldInput}
                value={qty}
                onChangeText={setQty}
                keyboardType="numeric"
                placeholder="1"
                placeholderTextColor="#94a3b8"
              />
              {selectedProduct && qty && Number(qty) > 0 && (
                <Text style={styles.calcHint}>
                  = {Number(qty) * (selectedProduct.unitConfig?.conversionFactor ?? 1)} retail units will be added
                </Text>
              )}
            </View>

            <TouchableOpacity style={styles.saveBtn} onPress={handleConvert} disabled={converting} activeOpacity={0.85}>
              {converting ? (
                <ActivityIndicator color="#fff" />
              ) : (
                <>
                  <Ionicons name="swap-horizontal" size={18} color="#fff" />
                  <Text style={styles.saveBtnText}>Confirm Conversion</Text>
                </>
              )}
            </TouchableOpacity>
          </View>
        </View>
      </Modal>
    </View>
  );
}

const styles = StyleSheet.create({
  screen: { flex: 1, backgroundColor: "#f4f7fb" },
  headerCard: {
    backgroundColor: "#0f172a", margin: 16, borderRadius: 20,
    padding: 18, flexDirection: "row", alignItems: "center", gap: 14,
  },
  headerIcon: {
    width: 44, height: 44, borderRadius: 14,
    backgroundColor: "#7c3aed", alignItems: "center", justifyContent: "center",
  },
  headerTitle: { color: "#fff", fontSize: 16, fontWeight: "800" },
  headerSub: { color: "#94a3b8", fontSize: 12, marginTop: 2 },
  infoBanner: {
    flexDirection: "row", alignItems: "flex-start", gap: 10,
    backgroundColor: "#e0f2fe", marginHorizontal: 16, marginBottom: 12,
    padding: 14, borderRadius: 14,
  },
  infoText: { flex: 1, color: "#0369a1", fontSize: 13, lineHeight: 19 },
  searchRow: {
    flexDirection: "row", alignItems: "center", gap: 10,
    backgroundColor: "#fff", borderRadius: 14, marginHorizontal: 16, marginBottom: 12,
    paddingHorizontal: 14, paddingVertical: 12,
    shadowColor: "#0f172a", shadowOpacity: 0.04, shadowRadius: 8, elevation: 2,
  },
  searchInput: { flex: 1, color: "#0f172a", fontSize: 14 },
  list: { padding: 16, paddingTop: 4, gap: 10 },
  card: {
    backgroundColor: "#fff", borderRadius: 18, padding: 16,
    flexDirection: "row", alignItems: "center", gap: 12,
    shadowColor: "#0f172a", shadowOpacity: 0.04, shadowRadius: 8, elevation: 2,
  },
  cardLeft: { flex: 1, flexDirection: "row", alignItems: "flex-start", gap: 12 },
  productIcon: { width: 46, height: 46, borderRadius: 14, alignItems: "center", justifyContent: "center" },
  productName: { color: "#0f172a", fontWeight: "700", fontSize: 15 },
  productId: { color: "#94a3b8", fontSize: 11, marginTop: 2 },
  stockRow: { flexDirection: "row", gap: 8, marginTop: 8, flexWrap: "wrap" },
  stockPill: { backgroundColor: "#f8fafc", borderRadius: 8, paddingHorizontal: 10, paddingVertical: 6, gap: 2 },
  stockPillLabel: { color: "#94a3b8", fontSize: 9, fontWeight: "700", textTransform: "uppercase" },
  stockPillValue: { color: "#0f172a", fontSize: 12, fontWeight: "800" },
  convertBtn: {
    backgroundColor: "#0f766e", borderRadius: 12,
    paddingHorizontal: 14, paddingVertical: 10,
    flexDirection: "row", alignItems: "center", gap: 6,
  },
  convertBtnDisabled: { backgroundColor: "#f1f5f9" },
  convertBtnText: { color: "#fff", fontWeight: "700", fontSize: 13 },
  modalOverlay: { flex: 1, backgroundColor: "rgba(0,0,0,0.4)", justifyContent: "flex-end" },
  modalCard: {
    backgroundColor: "#fff", borderTopLeftRadius: 28, borderTopRightRadius: 28,
    padding: 24, gap: 20,
  },
  modalHeader: { flexDirection: "row", alignItems: "flex-start", justifyContent: "space-between" },
  modalTitle: { color: "#0f172a", fontSize: 20, fontWeight: "800" },
  modalSub: { color: "#64748b", fontSize: 13, marginTop: 2 },
  conversionInfo: {
    flexDirection: "row", alignItems: "center", justifyContent: "space-around",
    backgroundColor: "#f8fafc", borderRadius: 16, padding: 16,
  },
  convInfo: { alignItems: "center", gap: 4 },
  convInfoLabel: { color: "#94a3b8", fontSize: 10, fontWeight: "700", textTransform: "uppercase" },
  convInfoValue: { color: "#0f172a", fontSize: 14, fontWeight: "800" },
  fieldGroup: { gap: 6 },
  fieldLabel: { color: "#64748b", fontSize: 11, fontWeight: "700", textTransform: "uppercase", letterSpacing: 0.8 },
  fieldInput: {
    backgroundColor: "#f8fafc", borderRadius: 14, paddingHorizontal: 16, paddingVertical: 14,
    color: "#0f172a", fontSize: 15, borderWidth: 1, borderColor: "#e2e8f0",
  },
  calcHint: { color: "#0f766e", fontSize: 12, fontWeight: "600", marginTop: 4 },
  saveBtn: {
    backgroundColor: "#7c3aed", borderRadius: 16, paddingVertical: 16,
    flexDirection: "row", alignItems: "center", justifyContent: "center", gap: 10, marginTop: 4,
  },
  saveBtnText: { color: "#fff", fontWeight: "800", fontSize: 16 },
});
