// @ts-nocheck

import { BASE_URL, getAuthToken } from "@/services/api";
import { Ionicons } from "@expo/vector-icons";
import { useEffect, useState } from "react";
import {
  ActivityIndicator,
  Alert,
  Modal,
  ScrollView,
  StyleSheet,
  Text,
  TextInput,
  TouchableOpacity,
  View,
  FlatList,
  Platform,
} from "react-native";
import DateTimePicker from '@react-native-community/datetimepicker';
import { Picker } from '@react-native-picker/picker';
import { getSalesTargets, setSalesTarget, updateSalesTarget, getFinancialSummary } from "@/services/analyticsApi";

import { getExpenses, createExpense, updateExpense, deleteExpense } from "@/services/expenseApi";



const apiHeaders = () => ({
  "Content-Type": "application/json",
  ...(getAuthToken() ? { Authorization: `Bearer ${getAuthToken()}` } : {}),
});

export default function AnalyticsScreen() {
  const [loading, setLoading] = useState(true);
  const [data, setData] = useState<any>(null);
  const [summary, setSummary] = useState<any>(null);
  const [targets, setTargets] = useState<any[]>([]);
  const [expenses, setExpenses] = useState<any[]>([]);
  
  const [targetModalVisible, setTargetModalVisible] = useState(false);
  const [expenseModalVisible, setExpenseModalVisible] = useState(false);
  
  const [targetAmount, setTargetAmount] = useState("");
  const [editingTargetId, setEditingTargetId] = useState<string | null>(null);
  
  const [expForm, setExpForm] = useState({ 
    id: "", 
    title: "", 
    amount: "", 
    category: "Other", 
    date: new Date(),
    note: "" 
  });
  const [showDatePicker, setShowDatePicker] = useState(false);
  const [showTimePicker, setShowTimePicker] = useState(false);




  const fetchAnalytics = async () => {
    setLoading(true);
    try {
      // Fetching sales, products, targets, summary and expenses
      const [salesRes, prodRes, targetRes, summaryRes, expenseRes] = await Promise.all([
        fetch(`${BASE_URL}/sales?size=1000`, { headers: apiHeaders() }).then((r) => r.json()),
        fetch(`${BASE_URL}/products?status=ACTIVE&size=1000`, { headers: apiHeaders() }).then((r) => r.json()),
        getSalesTargets().catch(() => []),
        getFinancialSummary().catch(() => null),
        getExpenses().catch(() => []),
      ]);



      const sales = salesRes?.data?.content ?? salesRes?.data ?? salesRes?.content ?? [];
      const products = prodRes?.data?.content ?? prodRes?.data ?? prodRes?.content ?? [];

      // Calculate Top Products
      const productSales: Record<string, { name: string; qty: number; revenue: number }> = {};
      sales.forEach((sale: any) => {
        (sale.items || []).forEach((item: any) => {
          const pid = item.productId || item.product?._id || "unknown";
          if (!productSales[pid]) {
            const p = products.find((x: any) => (x.id || x._id) === pid);
            productSales[pid] = { name: p?.name || item.name || "Unknown", qty: 0, revenue: 0 };
          }
          productSales[pid].qty += Number(item.qtySold || item.quantity || 0);
          productSales[pid].revenue += Number(item.lineTotal || (item.quantity * item.price) || 0);
        });
      });

      const topProducts = Object.values(productSales)
        .sort((a, b) => b.revenue - a.revenue)
        .slice(0, 5);

      // Monthly sales (dummy grouped for now)
      const totalRevenue = sales.reduce((s: number, i: any) => s + Number(i.totalAmount), 0);
      const avgOrder = sales.length > 0 ? totalRevenue / sales.length : 0;

      setData({
        totalRevenue,
        avgOrder,
        orderCount: sales.length,
        topProducts,
        activeProducts: products.length,
      });
      setTargets(targetRes || []);
      setSummary(summaryRes);
      setExpenses(expenseRes || []);


    } catch {
      setData(null);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => { fetchAnalytics(); }, []);

  const handleSaveTarget = async () => {
    if (!targetAmount) return;
    const currentMonth = new Date().toISOString().slice(0, 7);
    try {
      if (editingTargetId) {
        await updateSalesTarget(editingTargetId, { targetAmount: Number(targetAmount) });
      } else {
        await setSalesTarget({ month: currentMonth, targetAmount: Number(targetAmount) });
      }
      setTargetModalVisible(false);
      setTargetAmount("");
      setEditingTargetId(null);
      fetchAnalytics();
    } catch (err: any) {
      Alert.alert("Error", err.message);
    }
  };

  const handleSaveExpense = async () => {
    // Validation
    if (!expForm.title.trim()) return Alert.alert("Validation", "Please enter a title");
    if (!expForm.amount || isNaN(Number(expForm.amount))) return Alert.alert("Validation", "Please enter a valid amount");
    
    try {
      const payload = { 
        ...expForm, 
        amount: Number(expForm.amount),
        date: expForm.date.toISOString()
      };

      if (expForm.id) await updateExpense(expForm.id, payload);
      else await createExpense(payload);
      
      setExpenseModalVisible(false);
      setExpForm({ id: "", title: "", amount: "", category: "Other", date: new Date(), note: "" });
      fetchAnalytics();
    } catch (err: any) { Alert.alert("Error", err.message); }
  };


  const handleDeleteExpense = (id: string) => {
    Alert.alert("Delete Expense", "Are you sure?", [
      { text: "Cancel", style: "cancel" },
      { text: "Delete", style: "destructive", onPress: async () => {
          await deleteExpense(id);
          setExpenseModalVisible(false);
          fetchAnalytics();
        } 
      }

    ]);
  };


  const currentMonth = new Date().toISOString().slice(0, 7);
  const activeTarget = targets.find(t => t.month === currentMonth);
  const progress = activeTarget ? (data?.totalRevenue / activeTarget.targetAmount) : 0;


  const formatCurrency = (val: any) =>
    new Intl.NumberFormat("en-IN", { style: "currency", currency: "LKR", maximumFractionDigits: 0 }).format(val);

  if (loading) {
    return (
      <View style={[styles.screen, { justifyContent: "center", alignItems: "center" }]}>
        <ActivityIndicator size="large" color="#0369a1" />
        <Text style={styles.loadingText}>Analyzing business data...</Text>
      </View>
    );
  }


  return (
    <ScrollView style={styles.screen} contentContainerStyle={styles.container} showsVerticalScrollIndicator={false}>
      {/* Header */}
      <View style={styles.headerCard}>
        <View style={styles.headerIcon}>
          <Ionicons name="stats-chart" size={22} color="#fff" />
        </View>
        <View style={{ flex: 1 }}>
          <Text style={styles.headerTitle}>Business Analytics</Text>
          <Text style={styles.headerSub}>Sales performance and inventory insights</Text>
        </View>
        <TouchableOpacity style={styles.refreshBtn} onPress={fetchAnalytics}>
          <Ionicons name="refresh" size={18} color="#fff" />
        </TouchableOpacity>
      </View>

      {/* Financial Health Summary */}
      <View style={styles.summaryGrid}>
        <View style={[styles.summaryCard, { backgroundColor: '#0f172a' }]}>
            <Text style={styles.summaryLabel}>Net Profit</Text>
            <Text style={styles.summaryValue}>{formatCurrency(summary?.netProfit)}</Text>
            <View style={styles.marginBadge}>
                <Text style={styles.marginText}>{summary?.margin?.toFixed(1)}% Margin</Text>
            </View>
        </View>
        <View style={styles.summaryCard}>
            <Text style={[styles.summaryLabel, { color: '#64748b' }]}>Expenses</Text>
            <Text style={[styles.summaryValue, { color: '#ef4444' }]}>{formatCurrency(summary?.totalExpenses)}</Text>
            <TouchableOpacity onPress={() => {
                setExpForm({ id: "", title: "", amount: "", category: "Other", date: new Date(), note: "" });
                setExpenseModalVisible(true);
            }} style={styles.addExpBtn}>

                <Ionicons name="add-circle" size={16} color="#0369a1" />
                <Text style={styles.addExpText}>Record</Text>
            </TouchableOpacity>
        </View>
      </View>


      {/* Main Stats */}
      <View style={styles.mainStats}>
        <View style={styles.primaryStat}>
          <View style={{ flexDirection: 'row', justifyContent: 'space-between', width: '100%', marginBottom: 12 }}>
            <Text style={styles.primaryLab}>Lifetime Revenue</Text>
            <TouchableOpacity 
              onPress={() => {
                setEditingTargetId(activeTarget?._id || null);
                setTargetAmount(activeTarget?.targetAmount?.toString() || "");
                setTargetModalVisible(true);
              }}

              style={styles.targetBadge}
            >
              <Ionicons name="flag" size={12} color="#0369a1" />
              <Text style={styles.targetBadgeText}>
                {activeTarget ? `Goal: ${formatCurrency(activeTarget.targetAmount)}` : "Set Goal"}
              </Text>
            </TouchableOpacity>
          </View>
          <Text style={styles.primaryVal}>{formatCurrency(data?.totalRevenue || 0)}</Text>
          
          {activeTarget && (
            <View style={{ width: '100%', marginTop: 20 }}>
              <View style={{ flexDirection: 'row', justifyContent: 'space-between', marginBottom: 6 }}>
                <Text style={styles.progressText}>{Math.round(progress * 100)}% of monthly target</Text>
                <Text style={styles.progressText}>{formatCurrency(activeTarget.targetAmount - data?.totalRevenue)} left</Text>
              </View>
              <View style={styles.targetProgressContainer}>
                <View style={[styles.targetProgressFill, { width: `${Math.min(progress * 100, 100)}%` }]} />
              </View>
            </View>
          )}
        </View>
        <View style={styles.statRow}>
          <View style={styles.statBox}>
            <Text style={styles.statVal}>{data?.orderCount}</Text>
            <Text style={styles.statLab}>Total Orders</Text>
          </View>
          <View style={styles.statBox}>
            <Text style={styles.statVal}>{formatCurrency(data?.avgOrder || 0)}</Text>
            <Text style={styles.statLab}>Avg. Invoice</Text>
          </View>
        </View>
      </View>


      {/* Top Products */}
      <View style={styles.sectionCard}>
        <Text style={styles.sectionTitle}>Top Performing Products</Text>
        <Text style={styles.sectionSub}>By gross revenue</Text>
        
        <View style={styles.productList}>
          {(data?.topProducts || []).map((p: any, i: number) => {
            const maxRev = data.topProducts[0]?.revenue || 1;
            const barWidth = (p.revenue / maxRev) * 100;
            return (
              <View key={i} style={styles.productRow}>
                <View style={styles.productInfo}>
                  <Text style={styles.productName}>{p.name}</Text>
                  <Text style={styles.productRevenue}>{formatCurrency(p.revenue)} • {p.qty} sold</Text>
                </View>
                <View style={styles.barContainer}>
                  <View style={[styles.barFill, { width: `${barWidth}%` }]} />
                </View>
              </View>
            );
          })}
        </View>
      </View>

      {/* Health Indicators */}
      <View style={styles.grid}>
        <View style={styles.gridCard}>
          <Ionicons name="pulse" size={24} color="#10b981" />
          <Text style={styles.gridVal}>Healthy</Text>
          <Text style={styles.gridLab}>Store Status</Text>
        </View>
        <View style={styles.gridCard}>
          <Ionicons name="cube-outline" size={24} color="#3b82f6" />
          <Text style={styles.gridVal}>{data?.activeProducts}</Text>
          <Text style={styles.gridLab}>SKUs Tracked</Text>
        </View>
      </View>

      {/* Recent Expenses List */}
      <View style={styles.sectionCard}>
        <Text style={styles.sectionTitle}>Recent Expenses</Text>
        {expenses.length > 0 ? (
            <View style={{ marginTop: 12, gap: 10 }}>
                {expenses.slice(0, 3).map((ex, i) => (
                    <TouchableOpacity 
                        key={i} 
                        style={styles.expenseItem}
                        onLongPress={() => handleDeleteExpense(ex._id)}
                        onPress={() => {
                            setExpForm({ 
                                id: ex._id, 
                                title: ex.title, 
                                amount: ex.amount.toString(), 
                                category: ex.category,
                                date: new Date(ex.date),
                                note: ex.note || ""
                            });
                            setExpenseModalVisible(true);
                        }}

                    >
                        <View style={styles.expenseIcon}>
                            <Ionicons name="receipt-outline" size={16} color="#64748b" />
                        </View>
                        <View style={{ flex: 1 }}>
                            <Text style={styles.expenseTitle}>{ex.title}</Text>
                            <Text style={styles.expenseSub}>{ex.category} • {new Date(ex.date).toLocaleDateString()}</Text>
                        </View>
                        <Text style={styles.expenseAmount}>-{formatCurrency(ex.amount)}</Text>
                    </TouchableOpacity>
                ))}
            </View>
        ) : (
            <Text style={styles.emptyText}>No expenses recorded yet</Text>
        )}
      </View>

      {/* Tip Banner */}
      <View style={styles.tipBanner}>
        <Ionicons name="bulb-outline" size={20} color="#0369a1" />
        <Text style={styles.tipText}>
          Your top product accounts for {Math.round((data?.topProducts[0]?.revenue / (data?.totalRevenue || 1)) * 100)}% of total revenue.
        </Text>
      </View>

      {/* Target Modal */}
      <Modal visible={targetModalVisible} transparent animationType="fade">
        <View style={styles.modalOverlay}>
          <View style={styles.modalContent}>
            <Text style={styles.modalTitle}>{editingTargetId ? "Update Monthly Goal" : "Set Monthly Goal"}</Text>
            <Text style={styles.modalSub}>Revenue target for {currentMonth}</Text>
            <TextInput
              style={styles.input}
              placeholder="Enter amount (LKR)"
              keyboardType="numeric"
              value={targetAmount}
              onChangeText={setTargetAmount}
              autoFocus
            />
            <View style={styles.modalActions}>
              <TouchableOpacity style={styles.cancelBtn} onPress={() => setTargetModalVisible(false)}>
                <Text style={styles.cancelBtnText}>Cancel</Text>
              </TouchableOpacity>
              <TouchableOpacity style={styles.saveBtn} onPress={handleSaveTarget}>
                <Text style={styles.saveBtnText}>Save Goal</Text>
              </TouchableOpacity>
            </View>
          </View>
        </View>
      </Modal>

      {/* Expense Modal */}
      <Modal visible={expenseModalVisible} transparent animationType="slide">
        <View style={styles.modalOverlay}>
          <View style={styles.modalContent}>
            <View style={styles.modalHeader}>
                <Text style={styles.modalTitle}>{expForm.id ? "Edit Expense" : "Record Expense"}</Text>
                {expForm.id && (
                    <TouchableOpacity onPress={() => handleDeleteExpense(expForm.id)}>
                        <Ionicons name="trash-outline" size={20} color="#ef4444" />
                    </TouchableOpacity>
                )}
            </View>

            <ScrollView style={{ maxHeight: 400 }} showsVerticalScrollIndicator={false}>
                <View style={{ gap: 12 }}>
                    <Text style={styles.inputLabel}>Title</Text>
                    <TextInput
                        style={styles.input}
                        placeholder="e.g. Electricity Bill"
                        value={expForm.title}
                        onChangeText={t => setExpForm(p => ({ ...p, title: t }))}
                    />

                    <Text style={styles.inputLabel}>Amount (LKR)</Text>
                    <TextInput
                        style={styles.input}
                        placeholder="0.00"
                        keyboardType="numeric"
                        value={expForm.amount}
                        onChangeText={a => setExpForm(p => ({ ...p, amount: a }))}
                    />

                    <Text style={styles.inputLabel}>Category</Text>
                    <View style={styles.pickerContainer}>
                        <Picker
                            selectedValue={expForm.category}
                            onValueChange={v => setExpForm(p => ({ ...p, category: v }))}
                            style={styles.picker}
                        >
                            <Picker.Item label="Other" value="Other" />
                            <Picker.Item label="Rent" value="Rent" />
                            <Picker.Item label="Salaries" value="Salaries" />
                            <Picker.Item label="Utilities" value="Utilities" />
                            <Picker.Item label="Inventory Loss" value="Inventory Loss" />
                            <Picker.Item label="Marketing" value="Marketing" />
                            <Picker.Item label="Maintenance" value="Maintenance" />
                        </Picker>
                    </View>

                    <Text style={styles.inputLabel}>Date & Time</Text>
                    <View style={{ flexDirection: 'row', gap: 8 }}>
                        <TouchableOpacity 
                            style={[styles.input, { flex: 1, flexDirection: 'row', alignItems: 'center', gap: 8 }]}
                            onPress={() => setShowDatePicker(true)}
                        >
                            <Ionicons name="calendar-outline" size={16} color="#64748b" />
                            <Text>{expForm.date.toLocaleDateString()}</Text>
                        </TouchableOpacity>
                        <TouchableOpacity 
                            style={[styles.input, { flex: 1, flexDirection: 'row', alignItems: 'center', gap: 8 }]}
                            onPress={() => setShowTimePicker(true)}
                        >
                            <Ionicons name="time-outline" size={16} color="#64748b" />
                            <Text>{expForm.date.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}</Text>
                        </TouchableOpacity>
                    </View>

                    {showDatePicker && (
                        <DateTimePicker
                            value={expForm.date}
                            mode="date"
                            onChange={(e, d) => {
                                setShowDatePicker(false);
                                if (d) setExpForm(p => ({ ...p, date: d }));
                            }}
                        />
                    )}
                    {showTimePicker && (
                        <DateTimePicker
                            value={expForm.date}
                            mode="time"
                            onChange={(e, d) => {
                                setShowTimePicker(false);
                                if (d) setExpForm(p => ({ ...p, date: d }));
                            }}
                        />
                    )}

                    <Text style={styles.inputLabel}>Notes (Optional)</Text>
                    <TextInput
                        style={[styles.input, { height: 80, textAlignVertical: 'top' }]}
                        placeholder="Add more details..."
                        multiline
                        value={expForm.note}
                        onChangeText={n => setExpForm(p => ({ ...p, note: n }))}
                    />
                </View>
            </ScrollView>

            <View style={styles.modalActions}>
              <TouchableOpacity style={styles.cancelBtn} onPress={() => setExpenseModalVisible(false)}>
                <Text style={styles.cancelBtnText}>Cancel</Text>
              </TouchableOpacity>
              <TouchableOpacity style={styles.saveBtn} onPress={handleSaveExpense}>
                <Text style={styles.saveBtnText}>Save</Text>
              </TouchableOpacity>
            </View>
          </View>
        </View>
      </Modal>


    </ScrollView>

  );
}

const styles = StyleSheet.create({
  screen: { flex: 1, backgroundColor: "#f4f7fb" },
  container: { padding: 16, gap: 16, paddingBottom: 32 },
  loadingText: { marginTop: 12, color: "#64748b", fontWeight: "600", textAlign: "center" },

  headerCard: {
    backgroundColor: "#0f172a", borderRadius: 20,
    padding: 18, flexDirection: "row", alignItems: "center", gap: 14,
  },
  headerIcon: { width: 44, height: 44, borderRadius: 14, backgroundColor: "#0369a1", alignItems: "center", justifyContent: "center" },
  headerTitle: { color: "#fff", fontSize: 16, fontWeight: "800" },
  headerSub: { color: "#94a3b8", fontSize: 12, marginTop: 2 },
  refreshBtn: { padding: 8 },
  summaryGrid: { flexDirection: 'row', gap: 12 },
  summaryCard: { flex: 1, backgroundColor: '#fff', borderRadius: 20, padding: 16, gap: 4, elevation: 2, shadowColor: '#000', shadowOpacity: 0.05, shadowRadius: 10 },
  summaryLabel: { fontSize: 11, color: '#94a3b8', fontWeight: '700', textTransform: 'uppercase' },
  summaryValue: { fontSize: 18, fontWeight: '900', color: '#fff' },
  marginBadge: { alignSelf: 'flex-start', backgroundColor: '#059669', paddingHorizontal: 8, paddingVertical: 2, borderRadius: 6, marginTop: 4 },
  marginText: { color: '#fff', fontSize: 10, fontWeight: '800' },
  addExpBtn: { flexDirection: 'row', alignItems: 'center', gap: 4, marginTop: 4 },
  addExpText: { fontSize: 11, color: '#0369a1', fontWeight: '700' },
  mainStats: { gap: 10 },
  primaryStat: { backgroundColor: "#fff", borderRadius: 20, padding: 20, alignItems: "center", shadowColor: "#000", shadowOpacity: 0.05, shadowRadius: 10, elevation: 2 },
  primaryVal: { fontSize: 28, fontWeight: "900", color: "#0f172a" },
  primaryLab: { fontSize: 13, color: "#94a3b8", fontWeight: "700", textTransform: "uppercase" },
  targetBadge: { flexDirection: 'row', alignItems: 'center', gap: 4, backgroundColor: '#e0f2fe', paddingHorizontal: 10, paddingVertical: 4, borderRadius: 12 },
  targetBadgeText: { color: '#0369a1', fontSize: 11, fontWeight: '700' },
  progressText: { fontSize: 11, color: '#64748b', fontWeight: '600' },
  targetProgressContainer: { height: 10, backgroundColor: '#f1f5f9', borderRadius: 5, overflow: 'hidden' },
  targetProgressFill: { height: '100%', backgroundColor: '#10b981', borderRadius: 5 },
  statRow: { flexDirection: "row", gap: 10 },
  statBox: { flex: 1, backgroundColor: "#fff", borderRadius: 18, padding: 16, alignItems: "center", shadowColor: "#000", shadowOpacity: 0.05, shadowRadius: 8, elevation: 1 },
  statVal: { fontSize: 18, fontWeight: "800", color: "#0f172a" },
  statLab: { fontSize: 11, color: "#94a3b8", fontWeight: "700", textTransform: "uppercase", marginTop: 2 },
  sectionCard: { backgroundColor: "#fff", borderRadius: 20, padding: 20, shadowColor: "#000", shadowOpacity: 0.05, shadowRadius: 10, elevation: 2 },
  sectionTitle: { fontSize: 16, fontWeight: "800", color: "#0f172a" },
  sectionSub: { fontSize: 12, color: "#94a3b8", marginTop: 2, marginBottom: 16 },
  productList: { gap: 16 },
  productRow: { gap: 6 },
  productInfo: { flexDirection: "row", justifyContent: "space-between", alignItems: "flex-end" },
  productName: { color: "#334155", fontWeight: "700", fontSize: 14 },
  productRevenue: { color: "#94a3b8", fontSize: 11 },
  barContainer: { height: 8, backgroundColor: "#f1f5f9", borderRadius: 4, overflow: "hidden" },
  barFill: { height: "100%", backgroundColor: "#0369a1", borderRadius: 4 },
  grid: { flexDirection: "row", gap: 12 },
  gridCard: { flex: 1, backgroundColor: "#fff", borderRadius: 18, padding: 16, alignItems: "center", gap: 6, shadowColor: "#000", shadowOpacity: 0.04, shadowRadius: 8, elevation: 1 },
  gridVal: { fontSize: 16, fontWeight: "800", color: "#0f172a" },
  gridLab: { fontSize: 10, color: "#94a3b8", fontWeight: "700", textTransform: "uppercase" },
  tipBanner: { flexDirection: "row", alignItems: "center", gap: 12, backgroundColor: "#e0f2fe", padding: 16, borderRadius: 18 },
  tipText: { flex: 1, color: "#0369a1", fontSize: 13, lineHeight: 18, fontWeight: "500" },
  expenseItem: { flexDirection: 'row', alignItems: 'center', gap: 12, paddingVertical: 8 },
  expenseIcon: { width: 32, height: 32, backgroundColor: '#f1f5f9', borderRadius: 8, alignItems: 'center', justifyContent: 'center' },
  expenseTitle: { fontSize: 14, fontWeight: '700', color: '#334155' },
  expenseSub: { fontSize: 11, color: '#94a3b8' },
  expenseAmount: { fontSize: 14, fontWeight: '800', color: '#ef4444' },
  emptyText: { color: '#94a3b8', textAlign: 'center', marginVertical: 20, fontSize: 14, fontStyle: 'italic' },
  modalOverlay: { flex: 1, backgroundColor: 'rgba(0,0,0,0.5)', justifyContent: 'center', padding: 20 },
  modalContent: { backgroundColor: '#fff', borderRadius: 24, padding: 24, gap: 16 },
  modalTitle: { fontSize: 18, fontWeight: '800', color: '#0f172a' },
  modalSub: { fontSize: 13, color: '#64748b', marginTop: -8 },
  input: { backgroundColor: '#f8fafc', borderRadius: 12, padding: 12, fontSize: 15, fontWeight: '600', color: '#0f172a', borderWidth: 1, borderColor: '#e2e8f0' },
  inputLabel: { fontSize: 12, color: '#64748b', fontWeight: '700', marginBottom: -4, marginTop: 4 },
  pickerContainer: { backgroundColor: '#f8fafc', borderRadius: 12, borderWidth: 1, borderColor: '#e2e8f0', overflow: 'hidden' },
  picker: { height: 50, width: '100%' },
  modalHeader: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', marginBottom: 8 },
  modalActions: { flexDirection: 'row', gap: 12, marginTop: 8 },
  cancelBtn: { flex: 1, padding: 16, alignItems: 'center' },
  cancelBtnText: { color: '#64748b', fontWeight: '700' },
  saveBtn: { flex: 2, backgroundColor: '#0f172a', padding: 16, borderRadius: 12, alignItems: 'center' },
  saveBtnText: { color: '#fff', fontWeight: '700' },
});