import { useAuth } from "@/context/AuthContext";
import { Ionicons } from "@expo/vector-icons";
import { useRouter } from "expo-router";
import {
  ActivityIndicator,
  Alert,
  Modal,
  ScrollView,
  StyleSheet,
  Text,
  TextInput,
  TouchableOpacity,
  View,
} from "react-native";
import { useState, useEffect } from "react";
import * as SecureStore from "expo-secure-store";
import { updateResource } from "@/services/api";

const SETTINGS_SECTIONS = [
  {
    title: "Account",
    items: [
      { id: "profile", icon: "person-circle-outline", label: "Profile", desc: "View your personal account details" },
      { id: "password", icon: "lock-closed-outline", label: "Security", desc: "Update your login password" },
    ],
  },
  {
    title: "Business",
    items: [
      { id: "shop", icon: "business-outline", label: "Shop Details", desc: "Update shop name, address & phone" },
    ],
  },
  {
    title: "Support",
    items: [
      { id: "about", icon: "information-circle-outline", label: "About GrocerSmart", desc: "Version info and licenses" },
    ],
  },
];

export default function SettingsScreen() {
  const { user, signOut } = useAuth();
  const router = useRouter();

  const [shopVisible, setShopVisible] = useState(false);
  const [profileVisible, setProfileVisible] = useState(false);
  const [aboutVisible, setAboutVisible] = useState(false);
  const [passwordVisible, setPasswordVisible] = useState(false);
  
  const [newPassword, setNewPassword] = useState("");
  const [confirmPassword, setConfirmPassword] = useState("");
  const [updatingPassword, setUpdatingPassword] = useState(false);
  
  const [shopName, setShopName] = useState("GrocerSmart Store");
  const [shopAddress, setShopAddress] = useState("123 Main St, Colombo");
  const [shopPhone, setShopPhone] = useState("011 234 5678");

  useEffect(() => {
    const loadShopInfo = async () => {
      try {
        const saved = await SecureStore.getItemAsync("grocersmart.shop_info");
        if (saved) {
          const parsed = JSON.parse(saved);
          setShopName(parsed.name || "GrocerSmart Store");
          setShopAddress(parsed.address || "");
          setShopPhone(parsed.phone || "");
        }
      } catch (e) {}
    };
    loadShopInfo();
  }, []);

  const saveShopInfo = async () => {
    try {
      await SecureStore.setItemAsync("grocersmart.shop_info", JSON.stringify({
        name: shopName, address: shopAddress, phone: shopPhone
      }));
      setShopVisible(false);
      Alert.alert("Success", "Shop details updated successfully");
    } catch (e) {
      Alert.alert("Error", "Failed to save shop info");
    }
  };

  const handleUpdatePassword = async () => {
    if (!newPassword || newPassword.length < 8) {
      return Alert.alert("Error", "Password must be at least 8 characters long.");
    }
    if (newPassword !== confirmPassword) {
      return Alert.alert("Error", "Passwords do not match.");
    }

    setUpdatingPassword(true);
    try {
      if (!user?.id) throw new Error("User ID not found");
      await updateResource("/users", user.id, { password: newPassword });
      Alert.alert("Success", "Password updated successfully.");
      setPasswordVisible(false);
      setNewPassword("");
      setConfirmPassword("");
    } catch (e: any) {
      Alert.alert("Error", e.message || "Failed to update password.");
    } finally {
      setUpdatingPassword(false);
    }
  };

  const handleLogout = () => {
    Alert.alert("Logout", "Are you sure you want to sign out?", [
      { text: "Cancel", style: "cancel" },
      {
        text: "Logout",
        style: "destructive",
        onPress: async () => {
          await signOut();
          router.replace("/login");
        },
      },
    ]);
  };

  const handleItemPress = (id: string) => {
    switch (id) {
      case "profile": setProfileVisible(true); break;
      case "shop": setShopVisible(true); break;
      case "about": setAboutVisible(true); break;
      case "password": setPasswordVisible(true); break;
      default: Alert.alert("Coming Soon", "This feature is currently under development.");
    }
  };

  return (
    <ScrollView style={styles.screen} contentContainerStyle={styles.container}>
      {/* Profile Card */}
      <View style={styles.profileCard}>
        <View style={styles.avatarCircle}>
          <Text style={styles.avatarText}>
            {(user?.displayName ?? "U").slice(0, 1).toUpperCase()}
          </Text>
        </View>
        <View style={styles.profileInfo}>
          <Text style={styles.profileName}>{user?.displayName ?? "User"}</Text>
          <Text style={styles.profileUsername}>@{user?.username ?? "user"}</Text>
          <View style={styles.roleBadge}>
            <Text style={styles.roleBadgeText}>{user?.role || "Cashier"}</Text>
          </View>
        </View>
      </View>

      {/* Sections */}
      {SETTINGS_SECTIONS.map((section) => (
        <View key={section.title} style={styles.section}>
          <Text style={styles.sectionTitle}>{section.title}</Text>
          <View style={styles.sectionCard}>
            {section.items.map((item, idx) => (
              <TouchableOpacity
                key={item.label}
                style={[
                  styles.settingRow,
                  idx < section.items.length - 1 && styles.settingRowBorder,
                ]}
                onPress={() => handleItemPress(item.id)}
                activeOpacity={0.7}
              >
                <View style={styles.iconWrap}>
                  <Ionicons name={item.icon as any} size={20} color="#0f766e" />
                </View>
                <View style={styles.settingText}>
                  <Text style={styles.settingLabel}>{item.label}</Text>
                  <Text style={styles.settingDesc}>{item.desc}</Text>
                </View>
                <Ionicons name="chevron-forward" size={18} color="#94a3b8" />
              </TouchableOpacity>
            ))}
          </View>
        </View>
      ))}

      {/* Logout */}
      <TouchableOpacity style={styles.logoutButton} onPress={handleLogout} activeOpacity={0.85}>
        <Ionicons name="log-out-outline" size={20} color="#fff" />
        <Text style={styles.logoutText}>Sign Out</Text>
      </TouchableOpacity>

      <Text style={styles.version}>GrocerSmart v1.0.0</Text>

      {/* Shop Modal */}
      <Modal visible={shopVisible} animationType="slide" transparent>
        <View style={styles.modalOverlay}>
          <View style={styles.modalCard}>
            <Text style={styles.modalTitle}>Shop Details</Text>
            <View style={styles.inputGroup}>
              <Text style={styles.inputLabel}>Shop Name</Text>
              <TextInput style={styles.input} value={shopName} onChangeText={setShopName} />
            </View>
            <View style={styles.inputGroup}>
              <Text style={styles.inputLabel}>Address</Text>
              <TextInput style={styles.input} value={shopAddress} onChangeText={setShopAddress} multiline />
            </View>
            <View style={styles.inputGroup}>
              <Text style={styles.inputLabel}>Phone</Text>
              <TextInput style={styles.input} value={shopPhone} onChangeText={setShopPhone} keyboardType="phone-pad" />
            </View>
            <View style={styles.modalActions}>
              <TouchableOpacity style={styles.cancelBtn} onPress={() => setShopVisible(false)}>
                <Text style={styles.cancelBtnText}>Cancel</Text>
              </TouchableOpacity>
              <TouchableOpacity style={styles.saveBtn} onPress={saveShopInfo}>
                <Text style={styles.saveBtnText}>Save Changes</Text>
              </TouchableOpacity>
            </View>
          </View>
        </View>
      </Modal>

      {/* Profile Modal */}
      <Modal visible={profileVisible} animationType="fade" transparent>
        <View style={styles.modalOverlay}>
          <View style={styles.modalCard}>
            <View style={{ alignItems: 'center', marginBottom: 20 }}>
              <View style={[styles.avatarCircle, { width: 80, height: 80, borderRadius: 40 }]}>
                <Text style={[styles.avatarText, { fontSize: 36 }]}>{(user?.displayName ?? "U").slice(0, 1).toUpperCase()}</Text>
              </View>
            </View>
            <Text style={[styles.modalTitle, { textAlign: 'center' }]}>Your Profile</Text>
            <View style={styles.infoRow}>
              <Text style={styles.infoLabel}>Full Name</Text>
              <Text style={styles.infoValue}>{user?.displayName}</Text>
            </View>
            <View style={styles.infoRow}>
              <Text style={styles.infoLabel}>Username</Text>
              <Text style={styles.infoValue}>@{user?.username}</Text>
            </View>
            <View style={styles.infoRow}>
              <Text style={styles.infoLabel}>Access Role</Text>
              <Text style={styles.infoValue}>{user?.role || "Cashier"}</Text>
            </View>
            <TouchableOpacity style={[styles.saveBtn, { marginTop: 20, flexDirection: 'row', gap: 8 }]} onPress={() => setProfileVisible(false)}>
              <Ionicons name="close-circle-outline" size={20} color="#fff" />
              <Text style={styles.saveBtnText}>Close Profile</Text>
            </TouchableOpacity>
          </View>
        </View>
      </Modal>

      {/* About Modal */}
      <Modal visible={aboutVisible} animationType="fade" transparent>
        <View style={styles.modalOverlay}>
          <View style={styles.modalCard}>
            <View style={{ alignItems: 'center', marginBottom: 16 }}>
              <Ionicons name="cube" size={48} color="#0f766e" />
              <Text style={{ fontSize: 24, fontWeight: '900', color: '#0f172a', marginTop: 8 }}>GrocerSmart</Text>
              <Text style={{ color: '#64748b' }}>Version 1.0.0 (Build 20240501)</Text>
            </View>
            <Text style={{ color: '#475569', textAlign: 'center', lineHeight: 20, marginBottom: 24 }}>
              A professional full-stack inventory and point-of-sale management system for modern retailers.
            </Text>
            <TouchableOpacity style={styles.saveBtn} onPress={() => setAboutVisible(false)}>
              <Text style={styles.saveBtnText}>Got it</Text>
            </TouchableOpacity>
          </View>
        </View>
      </Modal>
      {/* Security Modal */}
      <Modal visible={passwordVisible} animationType="slide" transparent>
        <View style={styles.modalOverlay}>
          <View style={styles.modalCard}>
            <Text style={styles.modalTitle}>Change Password</Text>
            <View style={styles.inputGroup}>
              <Text style={styles.inputLabel}>New Password</Text>
              <TextInput 
                style={styles.input} 
                value={newPassword} 
                onChangeText={setNewPassword} 
                secureTextEntry
                placeholder="Min 8 characters"
              />
            </View>
            <View style={styles.inputGroup}>
              <Text style={styles.inputLabel}>Confirm Password</Text>
              <TextInput 
                style={styles.input} 
                value={confirmPassword} 
                onChangeText={setConfirmPassword} 
                secureTextEntry
                placeholder="Repeat password"
              />
            </View>
            <View style={styles.modalActions}>
              <TouchableOpacity 
                style={styles.cancelBtn} 
                onPress={() => { setPasswordVisible(false); setNewPassword(""); setConfirmPassword(""); }}
                disabled={updatingPassword}
              >
                <Text style={styles.cancelBtnText}>Cancel</Text>
              </TouchableOpacity>
              <TouchableOpacity 
                style={styles.saveBtn} 
                onPress={handleUpdatePassword}
                disabled={updatingPassword}
              >
                {updatingPassword ? (
                  <ActivityIndicator color="#fff" size="small" />
                ) : (
                  <Text style={styles.saveBtnText}>Update Password</Text>
                )}
              </TouchableOpacity>
            </View>
          </View>
        </View>
      </Modal>
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  screen: {
    flex: 1,
    backgroundColor: "#f4f7fb",
  },
  container: {
    padding: 16,
    paddingBottom: 40,
    gap: 20,
  },
  profileCard: {
    backgroundColor: "#0f172a",
    borderRadius: 24,
    padding: 20,
    flexDirection: "row",
    alignItems: "center",
    gap: 16,
  },
  avatarCircle: {
    width: 64,
    height: 64,
    borderRadius: 32,
    backgroundColor: "#0f766e",
    alignItems: "center",
    justifyContent: "center",
  },
  avatarText: {
    color: "#fff",
    fontSize: 28,
    fontWeight: "800",
  },
  profileInfo: {
    flex: 1,
    gap: 4,
  },
  profileName: {
    color: "#fff",
    fontSize: 18,
    fontWeight: "700",
  },
  profileUsername: {
    color: "#94a3b8",
    fontSize: 14,
  },
  roleBadge: {
    alignSelf: "flex-start",
    backgroundColor: "rgba(15, 118, 110, 0.25)",
    borderRadius: 999,
    paddingHorizontal: 10,
    paddingVertical: 4,
    marginTop: 4,
  },
  roleBadgeText: {
    color: "#5eead4",
    fontSize: 11,
    fontWeight: "700",
    letterSpacing: 0.5,
  },
  section: {
    gap: 8,
  },
  sectionTitle: {
    color: "#64748b",
    fontSize: 12,
    fontWeight: "700",
    letterSpacing: 0.8,
    textTransform: "uppercase",
    paddingHorizontal: 4,
  },
  sectionCard: {
    backgroundColor: "#fff",
    borderRadius: 20,
    overflow: "hidden",
    shadowColor: "#0f172a",
    shadowOpacity: 0.05,
    shadowRadius: 10,
    elevation: 2,
  },
  settingRow: {
    flexDirection: "row",
    alignItems: "center",
    paddingHorizontal: 16,
    paddingVertical: 14,
    gap: 12,
  },
  settingRowBorder: {
    borderBottomWidth: 1,
    borderBottomColor: "#f1f5f9",
  },
  iconWrap: {
    width: 36,
    height: 36,
    borderRadius: 10,
    backgroundColor: "#f0fdfa",
    alignItems: "center",
    justifyContent: "center",
  },
  settingText: {
    flex: 1,
    gap: 2,
  },
  settingLabel: {
    color: "#0f172a",
    fontWeight: "600",
    fontSize: 15,
  },
  settingDesc: {
    color: "#94a3b8",
    fontSize: 12,
  },
  logoutButton: {
    backgroundColor: "#ef4444",
    borderRadius: 18,
    paddingVertical: 16,
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "center",
    gap: 10,
    shadowColor: "#ef4444",
    shadowOpacity: 0.3,
    shadowRadius: 12,
    elevation: 4,
  },
  logoutText: {
    color: "#fff",
    fontWeight: "800",
    fontSize: 16,
  },
  version: {
    textAlign: "center",
    color: "#cbd5e1",
    fontSize: 12,
  },
  modalOverlay: { flex: 1, backgroundColor: "rgba(15, 23, 42, 0.6)", justifyContent: "center", padding: 20 },
  modalCard: { backgroundColor: "#fff", borderRadius: 28, padding: 24, shadowColor: "#000", shadowOpacity: 0.1, shadowRadius: 20, elevation: 10 },
  modalTitle: { fontSize: 20, fontWeight: "800", color: "#0f172a", marginBottom: 20 },
  inputGroup: { marginBottom: 16 },
  inputLabel: { fontSize: 13, fontWeight: "700", color: "#64748b", marginBottom: 8, textTransform: "uppercase" },
  input: { backgroundColor: "#f8fafc", borderRadius: 12, padding: 14, fontSize: 15, color: "#1e293b", borderWidth: 1, borderColor: "#e2e8f0" },
  modalActions: { flexDirection: "row", gap: 12, marginTop: 12 },
  cancelBtn: { flex: 1, paddingVertical: 14, borderRadius: 14, alignItems: "center" },
  cancelBtnText: { color: "#64748b", fontWeight: "700" },
  saveBtn: { backgroundColor: "#0f766e", paddingVertical: 14, paddingHorizontal: 20, borderRadius: 14, alignItems: "center", justifyContent: "center" },
  saveBtnText: { color: "#fff", fontWeight: "800", fontSize: 15 },
  infoRow: { flexDirection: "row", justifyContent: "space-between", paddingVertical: 12, borderBottomWidth: 1, borderBottomColor: "#f1f5f9" },
  infoLabel: { color: "#64748b", fontSize: 14 },
  infoValue: { color: "#1e293b", fontSize: 14, fontWeight: "700" },
});
