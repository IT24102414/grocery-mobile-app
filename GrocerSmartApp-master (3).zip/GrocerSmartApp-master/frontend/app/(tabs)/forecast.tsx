import React, { useState, useEffect } from 'react';
import { View, Text, StyleSheet, FlatList, TouchableOpacity, ActivityIndicator, ScrollView, Alert } from 'react-native';
import { IconSymbol } from '@/components/ui/icon-symbol';

const API_BASE_URL = process.env.EXPO_PUBLIC_API_URL || 'http://10.118.221.102:8000/api';

export default function ForecastScreen() {
  const [products, setProducts] = useState([]);
  const [selectedProduct, setSelectedProduct] = useState(null);
  const [forecastData, setForecastData] = useState(null);
  const [loading, setLoading] = useState(true);
  const [predicting, setPredicting] = useState(false);

  useEffect(() => {
    fetchProducts();
  }, []);

  const fetchProducts = async () => {
    try {
      setLoading(true);
      const response = await fetch(`${API_BASE_URL}/products`);
      const json = await response.json();
      if (json.success) {
        setProducts(json.data.content || []);
      }
    } catch (error) {
      console.error('Failed to fetch products', error);
    } finally {
      setLoading(false);
    }
  };

  const getForecast = async (product) => {
    try {
      setPredicting(true);
      setSelectedProduct(product);
      
      const now = new Date();
      const payload = {
        family: product.family || 'GENERAL',
        store_nbr: product.store_nbr || 1,
        onpromotion: product.onpromotion || 0,
        day_of_week: now.getDay(),
        month: now.getMonth() + 1,
        day_of_month: now.getDate(),
        is_weekend: (now.getDay() === 0 || now.getDay() === 6) ? 1 : 0,
        lag_1: 5.5, // Mock data for demo
        lag_7: 4.2,
        lag_14: 3.8,
        rolling_mean_7: 4.5
      };

      const response = await fetch(`${API_BASE_URL}/ai/predict-forecast-14days`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload)
      });

      const json = await response.json();
      if (json.success) {
        setForecastData(json.data.forecast_14_days);
      } else {
        Alert.alert('Error', json.message || 'Failed to get forecast');
      }
    } catch (error) {
      Alert.alert('Error', 'AI Service not reachable');
      console.error(error);
    } finally {
      setPredicting(false);
    }
  };

  const renderProductItem = ({ item }) => (
    <TouchableOpacity 
      style={[styles.productCard, selectedProduct?._id === item._id && styles.selectedCard]} 
      onPress={() => getForecast(item)}
    >
      <Text style={styles.productName}>{item.name}</Text>
      <Text style={styles.productCategory}>{item.category}</Text>
    </TouchableOpacity>
  );

  return (
    <View style={styles.container}>
      <View style={styles.header}>
        <Text style={styles.headerTitle}>AI Demand Forecast</Text>
      </View>

      <View style={styles.section}>
        <Text style={styles.sectionTitle}>Select Product</Text>
        {loading ? (
          <ActivityIndicator size="small" color="#0000ff" />
        ) : (
          <FlatList
            horizontal
            data={products}
            keyExtractor={(item) => item._id}
            renderItem={renderProductItem}
            showsHorizontalScrollIndicator={false}
            contentContainerStyle={styles.productList}
          />
        )}
      </View>

      <ScrollView style={styles.content}>
        {predicting ? (
          <View style={styles.center}>
            <ActivityIndicator size="large" color="#4F46E5" />
            <Text style={styles.loadingText}>Analyzing patterns...</Text>
          </View>
        ) : forecastData ? (
          <View>
            <View style={styles.statsCard}>
              <Text style={styles.statsTitle}>14-Day Sales Prediction</Text>
              <Text style={styles.statsSubtitle}>Expected units for {selectedProduct?.name}</Text>
              
              <View style={styles.chartContainer}>
                {forecastData.map((val, idx) => (
                  <View key={idx} style={styles.barGroup}>
                    <View style={[styles.bar, { height: Math.max(val * 10, 20) }]} />
                    <Text style={styles.barLabel}>D{idx + 1}</Text>
                    <Text style={styles.barVal}>{Math.round(val)}</Text>
                  </View>
                ))}
              </View>
            </View>

            <View style={styles.insightCard}>
              <IconSymbol name="paperplane.fill" size={24} color="#4F46E5" />
              <View style={styles.insightTextContainer}>
                <Text style={styles.insightTitle}>AI Insight</Text>
                <Text style={styles.insightText}>
                  Based on historical data, we expect a {forecastData[0] > forecastData[13] ? 'decrease' : 'slight increase'} in demand over the next two weeks. 
                  Consider adjusting your reorder point to {Math.ceil(Math.max(...forecastData) * 1.5)} units.
                </Text>
              </View>
            </View>
          </View>
        ) : (
          <View style={styles.emptyState}>
            <IconSymbol name="chart.bar.fill" size={64} color="#D1D5DB" />
            <Text style={styles.emptyText}>Select a product to view AI-powered sales forecasts.</Text>
          </View>
        )}
      </ScrollView>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#F9FAFB',
  },
  header: {
    paddingTop: 60,
    paddingBottom: 20,
    backgroundColor: '#ffffff',
    alignItems: 'center',
    borderBottomWidth: 1,
    borderBottomColor: '#E5E7EB',
  },
  headerTitle: {
    fontSize: 20,
    fontWeight: 'bold',
    color: '#111827',
  },
  section: {
    padding: 16,
  },
  sectionTitle: {
    fontSize: 16,
    fontWeight: '600',
    color: '#374151',
    marginBottom: 12,
  },
  productList: {
    paddingRight: 16,
  },
  productCard: {
    backgroundColor: '#ffffff',
    padding: 12,
    borderRadius: 12,
    marginRight: 12,
    width: 140,
    borderWidth: 1,
    borderColor: '#E5E7EB',
  },
  selectedCard: {
    borderColor: '#4F46E5',
    backgroundColor: '#EEF2FF',
  },
  productName: {
    fontSize: 14,
    fontWeight: 'bold',
    color: '#111827',
  },
  productCategory: {
    fontSize: 11,
    color: '#6B7280',
    marginTop: 4,
  },
  content: {
    flex: 1,
    padding: 16,
  },
  center: {
    marginTop: 100,
    alignItems: 'center',
  },
  loadingText: {
    marginTop: 16,
    color: '#4F46E5',
    fontWeight: '500',
  },
  statsCard: {
    backgroundColor: '#ffffff',
    padding: 16,
    borderRadius: 16,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 4,
    elevation: 3,
  },
  statsTitle: {
    fontSize: 18,
    fontWeight: 'bold',
    color: '#111827',
  },
  statsSubtitle: {
    fontSize: 12,
    color: '#6B7280',
    marginTop: 4,
    marginBottom: 20,
  },
  chartContainer: {
    flexDirection: 'row',
    alignItems: 'flex-end',
    justifyContent: 'space-between',
    height: 150,
    paddingBottom: 20,
  },
  barGroup: {
    alignItems: 'center',
    width: 20,
  },
  bar: {
    width: 8,
    backgroundColor: '#4F46E5',
    borderRadius: 4,
    marginBottom: 8,
  },
  barLabel: {
    fontSize: 8,
    color: '#9CA3AF',
  },
  barVal: {
    fontSize: 8,
    fontWeight: 'bold',
    color: '#374151',
    position: 'absolute',
    top: -15,
  },
  insightCard: {
    backgroundColor: '#EEF2FF',
    padding: 16,
    borderRadius: 16,
    marginTop: 20,
    flexDirection: 'row',
  },
  insightTextContainer: {
    marginLeft: 12,
    flex: 1,
  },
  insightTitle: {
    fontSize: 14,
    fontWeight: 'bold',
    color: '#4F46E5',
  },
  insightText: {
    fontSize: 13,
    color: '#374151',
    lineHeight: 18,
    marginTop: 4,
  },
  emptyState: {
    marginTop: 100,
    alignItems: 'center',
  },
  emptyText: {
    marginTop: 16,
    color: '#9CA3AF',
    textAlign: 'center',
    paddingHorizontal: 40,
  },
});
