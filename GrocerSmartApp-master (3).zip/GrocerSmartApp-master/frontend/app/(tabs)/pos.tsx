import { BASE_URL, getAuthToken } from "@/services/api";
import { Ionicons } from "@expo/vector-icons";
import React, { useEffect, useState } from "react";
import {
  ActivityIndicator,
  Alert,
  FlatList,
  KeyboardAvoidingView,
  Modal,
  ScrollView,
  StyleSheet,
  Text,
  TextInput,
  TouchableOpacity,
  View,
  Platform,
} from "react-native";
import SearchableDropdown from "@/components/searchable-dropdown";
import DateTimePicker from "@react-native-community/datetimepicker";

const apiHeaders = () => ({
  "Content-Type": "application/json",
  ...(getAuthToken() ? { Authorization: `Bearer ${getAuthToken()}` } : {}),
});

const fetchProducts = async () => {
  const res = await fetch(`${BASE_URL}/products?status=ACTIVE&size=1000`, { headers: apiHeaders() });
  const data = await res.json();
  return data?.data?.content ?? data?.data ?? data?.content ?? [];
};

const fetchCreditCustomers = async () => {
  const res = await fetch(`${BASE_URL}/credit-customers?status=ACTIVE&size=1000`, { headers: apiHeaders() });
  const data = await res.json();
  return data?.data?.content ?? data?.data ?? data?.content ?? [];
};

const createSale = async (payload: any) => {
  const res = await fetch(`${BASE_URL}/sales`, {
    method: "POST",
    headers: apiHeaders(),
    body: JSON.stringify(payload),
  });
  const data = await res.json();
  if (!res.ok) throw new Error(data?.message ?? "Checkout failed");
  
  // Confirm sale right after creation if successful
  const saleId = data?.data?.id || data?.id;
  if (saleId) {
    const confirmRes = await fetch(`${BASE_URL}/sales/${saleId}/confirm`, { method: "PUT", headers: apiHeaders() });
    if (!confirmRes.ok) {
      // Clean up the draft order if confirmation (stock deduct) fails
      await fetch(`${BASE_URL}/sales/${saleId}`, { method: "DELETE", headers: apiHeaders() });
      const confirmData = await confirmRes.json();
      throw new Error(confirmData?.message ?? "Failed to confirm order. Stock may be insufficient.");
    }
  }
  return data;
};

const fetchSales = async () => {
  const res = await fetch(`${BASE_URL}/sales?size=50`, { headers: apiHeaders() });
  const data = await res.json();
  return data?.data?.content ?? data?.data ?? data?.content ?? [];
};

const deleteSale = async (id: string) => {
  const res = await fetch(`${BASE_URL}/sales/${id}`, { method: "DELETE", headers: apiHeaders() });
  if (!res.ok) throw new Error("Failed to delete sale");
};

export default function POSScreen() {
  const [products, setProducts] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState("");
  const [cart, setCart] = useState<any[]>([]);
  const [checkoutVisible, setCheckoutVisible] = useState(false);
  const [paymentType, setPaymentType] = useState("CASH");
  const [creditCustomers, setCreditCustomers] = useState<any[]>([]);
  const [creditCustomerId, setCreditCustomerId] = useState<string | null>(null);
  const [processing, setProcessing] = useState(false);
  const [sales, setSales] = useState<any[]>([]);
  const [historyVisible, setHistoryVisible] = useState(false);
  const [filterDate, setFilterDate] = useState<string | null>(null);
  const [showFilterPicker, setShowFilterPicker] = useState(false);
  const [editSaleId, setEditSaleId] = useState<string | null>(null);
  const [isViewOnly, setIsViewOnly] = useState(false);

  useEffect(() => {
    const load = async () => {
      setLoading(true);
      try {
        const [pList, cList, sList] = await Promise.all([
          fetchProducts(), 
          fetchCreditCustomers(),
          fetchSales()
        ]);
        setProducts(Array.isArray(pList) ? pList : []);
        setCreditCustomers(Array.isArray(cList) ? cList : []);
        setSales(Array.isArray(sList) ? sList : []);
      } catch {
        setProducts([]);
        setCreditCustomers([]);
        setSales([]);
      } finally {
        setLoading(false);
      }
    };
    load();
  }, []);

  const addToCart = (product: any) => {
    const maxQty = Number(product.unitQty || 0);
    const existing = cart.find(item => item.id === (product.id || product._id));
    
    if (existing) {
      if (existing.quantity + 1 > maxQty) {
        Alert.alert("Stock Limit Reached", `Only ${maxQty} units available.`);
        return;
      }
      setCart(cart.map(item => 
        item.id === (product.id || product._id) 
        ? { ...item, quantity: item.quantity + 1 } 
        : item
      ));
    } else {
      if (1 > maxQty) {
        Alert.alert("Out of Stock", "This product is out of stock.");
        return;
      }
      setCart([...cart, { 
        id: product.id || product._id, 
        name: product.name, 
        price: product.unitPrice, 
        quantity: 1,
        productId: product.id || product._id
      }]);
    }
  };

  const removeFromCart = (id: string) => {
    setCart(cart.filter(item => item.id !== id));
  };

  const updateQty = (id: string, delta: number) => {
    setCart(cart.map(item => {
      if (item.id === id) {
        const product = products.find(p => (p.id || p._id) === item.productId);
        const maxQty = product ? Number(product.unitQty || 0) : Infinity;
        const newQty = Math.max(1, item.quantity + delta);
        if (newQty > maxQty) {
          Alert.alert("Stock Limit Reached", `Only ${maxQty} units available.`);
          return item;
        }
        return { ...item, quantity: newQty };
      }
      return item;
    }));
  };

  const handleManualQtyChange = (id: string, text: string) => {
    const val = text === "" ? 0 : (parseInt(text) || 0);
    setCart(cart.map(item => {
      if (item.id === id) {
        const product = products.find(p => (p.id || p._id) === item.productId);
        const maxQty = product ? Number(product.unitQty || 0) : Infinity;
        if (val > maxQty) {
          Alert.alert("Stock Limit Reached", `Only ${maxQty} units available.`);
          return { ...item, quantity: maxQty };
        }
        return { ...item, quantity: val };
      }
      return item;
    }));
  };

  const closeCheckout = () => {
    setCheckoutVisible(false);
    if (isViewOnly || editSaleId) {
      setCart([]);
      setEditSaleId(null);
      setIsViewOnly(false);
      setPaymentType("CASH");
      setCreditCustomerId(null);
    }
  };

  const handleEditSale = (sale: any, viewOnly = false) => {
    setEditSaleId(viewOnly ? null : (sale.id || sale._id));
    setIsViewOnly(viewOnly);
    setCart(sale.items.map((it: any) => ({
      id: it.product?._id || it.productId,
      productId: it.product?._id || it.productId,
      name: it.product?.name || "Product",
      price: it.unitPrice || it.price,
      quantity: it.qty || it.quantity
    })));
    setPaymentType(sale.paymentType || "CASH");
    setCreditCustomerId(sale.creditCustomerId || sale.customer?._id || null);
    setHistoryVisible(false);
    setCheckoutVisible(true);
  };

  const total = cart.reduce((sum, item) => sum + (item.price * item.quantity), 0);

  const handleCheckout = async () => {
    if (cart.length === 0) return;
    if (cart.some(item => item.quantity <= 0)) {
      Alert.alert("Invalid Quantity", "Please ensure all items have a quantity of at least 1.");
      return;
    }
    
    // Front-end stock validation
    for (const item of cart) {
      const product = products.find(p => (p.id || p._id) === item.productId);
      if (product && item.quantity > Number(product.unitQty || 0)) {
        Alert.alert("Insufficient Stock", `You only have ${product.unitQty || 0} units of ${item.name} available.`);
        return;
      }
    }
    
    setProcessing(true);
    try {
      const payload = {
        salesDate: new Date().toISOString(),
        paymentType,
        creditCustomerId: paymentType === "CREDIT" ? creditCustomerId : undefined,
        customerId: paymentType === "CREDIT" ? creditCustomerId : undefined,
        items: cart.map(item => ({
          productId: item.productId,
          qty: item.quantity,
          unitPrice: item.price,
          lineTotal: item.price * item.quantity
        }))
      };
      
      if (editSaleId) {
        const res = await fetch(`${BASE_URL}/sales/${editSaleId}`, {
          method: "PUT",
          headers: apiHeaders(),
          body: JSON.stringify(payload),
        });
        if (!res.ok) throw new Error((await res.json())?.message ?? "Update failed");
      } else {
        await createSale(payload);
      }
      
      Alert.alert("Success", editSaleId ? "Order updated" : "Checkout completed");
      setCart([]);
      setEditSaleId(null);
      setIsViewOnly(false);
      setCheckoutVisible(false);
      
      // Refresh history
      const sList = await fetchSales();
      setSales(sList);
    } catch (e: any) {
      Alert.alert("Error", e.message);
    } finally {
      setProcessing(false);
    }
  };


  const handleDeleteSale = (sale: any) => {
    Alert.alert("Delete Order", "Are you sure you want to delete this order? Stock will NOT be automatically returned by soft-delete.", [
      { text: "Cancel", style: "cancel" },
      { text: "Delete", style: "destructive", onPress: async () => {
        try {
          await deleteSale(sale.id || sale._id);
          setSales(sales.filter(s => (s.id || s._id) !== (sale.id || sale._id)));
        } catch (e: any) { Alert.alert("Error", e.message); }
      }}
    ]);
  };

  const filteredSales = sales.filter(s => {
    if (!filterDate) return true;
    return s.createdAt?.slice(0, 10) === filterDate;
  });

  const filteredProducts = products.filter(p => 
    p.name.toLowerCase().includes(search.toLowerCase()) ||
    (p.publicId && p.publicId.toLowerCase().includes(search.toLowerCase()))
  );

  const formatCurrency = (val: number) => `Rs.${val.toLocaleString()}`;

  return (
    <View style={styles.screen}>
      <View style={styles.main}>
        {/* Products List */}
        <View style={styles.productListSection}>
          <View style={styles.headerRow}>
            <View style={styles.searchBar}>
              <Ionicons name="search" size={20} color="#94a3b8" />
              <TextInput 
                style={styles.searchInput}
                placeholder="Search products..."
                value={search}
                onChangeText={setSearch}
              />
            </View>
            <TouchableOpacity style={styles.historyToggle} onPress={() => { setIsViewOnly(false); setCheckoutVisible(true); }}>
              <Ionicons name="cart-outline" size={22} color="#0f766e" />
              {cart.length > 0 && (
                <View style={styles.cartBadge}>
                  <Text style={styles.cartBadgeText}>{cart.length}</Text>
                </View>
              )}
            </TouchableOpacity>
            <TouchableOpacity style={styles.historyToggle} onPress={() => setHistoryVisible(true)}>
              <Ionicons name="time-outline" size={22} color="#0f766e" />
            </TouchableOpacity>
          </View>

          {loading ? (
            <ActivityIndicator size="large" color="#0f766e" />
          ) : (
            <FlatList
              data={filteredProducts}
              keyExtractor={(item) => item.id || item._id}
              numColumns={2}
              columnWrapperStyle={styles.row}
              renderItem={({ item }) => (
                <TouchableOpacity style={styles.productCard} onPress={() => addToCart(item)} activeOpacity={0.7}>
                  <View style={styles.productIconWrap}>
                    <Ionicons name="cube-outline" size={24} color="#0f766e" />
                  </View>
                  <Text style={styles.productName} numberOfLines={2}>{item.name}</Text>
                  <Text style={styles.productPrice}>{formatCurrency(item.unitPrice)}</Text>
                  <View style={styles.addIndicator}>
                    <Ionicons name="add" size={12} color="#fff" />
                  </View>
                </TouchableOpacity>
              )}
            />
          )}
        </View>

        {/* Sidebar Cart (Mobile Bottom Bar implementation) */}
        <View style={styles.cartBar}>
          <View style={styles.cartInfo}>
            <Text style={styles.cartLabel}>{cart.length} Items</Text>
            <Text style={styles.cartTotal}>{formatCurrency(total)}</Text>
          </View>
          <TouchableOpacity 
            style={[styles.checkoutBtn, cart.length === 0 && { backgroundColor: "#94a3b8" }]}
            onPress={() => { if (cart.length > 0) { setIsViewOnly(false); setCheckoutVisible(true); } }}
            disabled={cart.length === 0}
          >
            <Text style={styles.checkoutBtnText}>Review & Pay</Text>
            <Ionicons name="arrow-forward" size={18} color="#fff" />
          </TouchableOpacity>
        </View>
      </View>

      {/* Checkout Modal */}
      <Modal visible={checkoutVisible} animationType="slide" transparent>
        <KeyboardAvoidingView 
          style={styles.modalOverlay} 
          behavior={Platform.OS === "ios" ? "padding" : "height"}
        >
          <View style={styles.modalCard}>
            <View style={styles.modalHeader}>
              <Text style={styles.modalTitle}>Checkout Summary</Text>
              <TouchableOpacity onPress={closeCheckout}>
                <Ionicons name="close" size={24} color="#64748b" />
              </TouchableOpacity>
            </View>

            {!isViewOnly && (
              <View style={{ paddingHorizontal: 20, paddingBottom: 15, borderBottomWidth: 1, borderBottomColor: "#f1f5f9" }}>
                <SearchableDropdown
                  label="Add more items"
                  placeholder="Search to add..."
                  items={products.map(p => ({ label: `${p.name} - ${formatCurrency(p.unitPrice)}`, value: p.id || p._id, product: p }))}
                  value=""
                  onValueChange={(val) => {
                    const selectedItem = products.find(p => (p.id || p._id) === val);
                    if (selectedItem) addToCart(selectedItem);
                  }}
                />
              </View>
            )}

            <ScrollView 
              style={styles.modalScroll} 
              keyboardShouldPersistTaps="handled"
              contentContainerStyle={{ paddingBottom: 30 }}
            >
              {cart.map((item) => (
                <View key={item.id} style={styles.cartItem}>
                  <View style={{ flex: 1 }}>
                    <Text style={styles.cartItemName}>{item.name}</Text>
                    <Text style={styles.cartItemPrice}>{formatCurrency(item.price)}</Text>
                  </View>
                  <View style={styles.qtyControls}>
                    {!isViewOnly && (
                      <TouchableOpacity onPress={() => updateQty(item.id, -1)} style={styles.qtyBtn}>
                        <Ionicons name="remove" size={16} color="#0f766e" />
                      </TouchableOpacity>
                    )}
                    <TextInput 
                      style={styles.qtyInput}
                      value={item.quantity === 0 ? "" : String(item.quantity)}
                      keyboardType="numeric"
                      onChangeText={(txt: string) => handleManualQtyChange(item.id, txt)}
                      editable={!isViewOnly}
                    />
                    {!isViewOnly && (
                      <TouchableOpacity onPress={() => updateQty(item.id, 1)} style={styles.qtyBtn}>
                        <Ionicons name="add" size={16} color="#0f766e" />
                      </TouchableOpacity>
                    )}
                  </View>
                  {!isViewOnly && (
                    <TouchableOpacity onPress={() => removeFromCart(item.id)} style={styles.removeBtn}>
                      <Ionicons name="trash-outline" size={18} color="#ef4444" />
                    </TouchableOpacity>
                  )}
                </View>
              ))}

              <View style={styles.paymentSection}>
                <Text style={styles.paymentTitle}>Payment Method</Text>
                <View style={styles.paymentRow}>
                  {["CASH", "CARD", "CREDIT"].map((type) => (
                    <TouchableOpacity 
                      key={type}
                      style={[styles.payChip, paymentType === type && styles.payChipActive]}
                      onPress={() => !isViewOnly && setPaymentType(type)}
                      activeOpacity={isViewOnly ? 1 : 0.7}
                    >
                      <Text style={[styles.payChipText, paymentType === type && { color: "#fff" }]}>{type}</Text>
                    </TouchableOpacity>
                  ))}
                </View>

                {paymentType === "CREDIT" && (
                  <View style={{ marginTop: 12 }}>
                    <SearchableDropdown
                      label="Select Credit Customer *"
                      placeholder="Search customer..."
                      items={creditCustomers.map(c => ({ label: `${c.name} (${c.phone})`, value: c.id || c._id }))}
                      value={creditCustomerId}
                      onValueChange={setCreditCustomerId}
                      disabled={isViewOnly}
                    />
                    {!creditCustomerId && (
                      <Text style={{ color: "#ef4444", fontSize: 11, marginTop: 4 }}>
                        A customer is required for credit sales
                      </Text>
                    )}
                  </View>
                )}
              </View>

            {!isViewOnly && (
              <View style={styles.summaryFooter}>
                <View style={styles.fullTotalRow}>
                  <Text style={styles.fullTotalLabel}>Grand Total</Text>
                  <Text style={styles.fullTotalValue}>{formatCurrency(total)}</Text>
                </View>
                <TouchableOpacity 
                  style={[
                    styles.finalizeBtn, 
                    paymentType === "CREDIT" && !creditCustomerId && { opacity: 0.5 }
                  ]} 
                  onPress={() => {
                    if (paymentType === "CREDIT" && !creditCustomerId) {
                      return Alert.alert("Required", "Please select a credit customer for this sale.");
                    }
                    handleCheckout();
                  }}
                  disabled={processing || (paymentType === "CREDIT" && !creditCustomerId)}
                >
                  {processing ? (
                    <ActivityIndicator color="#fff" />
                  ) : (
                    <>
                      <Text style={styles.finalizeText}>{editSaleId ? "Update Order" : "Finalize Order"}</Text>
                      <Ionicons name="checkmark-circle" size={20} color="#fff" />
                    </>
                  )}
                </TouchableOpacity>
              </View>
            )}
            {isViewOnly && (
              <View style={styles.summaryFooter}>
                <View style={styles.fullTotalRow}>
                  <Text style={styles.fullTotalLabel}>Grand Total</Text>
                  <Text style={styles.fullTotalValue}>{formatCurrency(total)}</Text>
                </View>
                <TouchableOpacity 
                  style={[styles.finalizeBtn, { backgroundColor: "#64748b" }]} 
                  onPress={closeCheckout}
                >
                  <Text style={styles.finalizeText}>Close Preview</Text>
                </TouchableOpacity>
              </View>
            )}
            </ScrollView>
          </View>
        </KeyboardAvoidingView>
      </Modal>

      {/* History Modal */}
      <Modal visible={historyVisible} animationType="slide" transparent>
        <View style={styles.modalOverlay}>
          <View style={styles.modalCard}>
            <View style={styles.modalHeader}>
              <View>
                <Text style={styles.modalTitle}>Order History</Text>
                <TouchableOpacity onPress={() => setShowFilterPicker(true)} style={{ flexDirection: 'row', alignItems: 'center', gap: 4, marginTop: 4 }}>
                  <Ionicons name="filter" size={14} color="#0f766e" />
                  <Text style={{ color: "#0f766e", fontSize: 13, fontWeight: "600" }}>
                    {filterDate ? `Date: ${filterDate}` : "Show All Dates"}
                  </Text>
                </TouchableOpacity>
              </View>
              <TouchableOpacity onPress={() => setHistoryVisible(false)}>
                <Ionicons name="close" size={24} color="#64748b" />
              </TouchableOpacity>
            </View>

            {showFilterPicker && (
              <DateTimePicker
                value={filterDate ? new Date(filterDate) : new Date()}
                mode="date"
                display={Platform.OS === 'ios' ? 'spinner' : 'default'}
                onChange={(event: any, selectedDate: any) => {
                  setShowFilterPicker(false);
                  if (selectedDate) setFilterDate(selectedDate.toISOString().split('T')[0]);
                }}
              />
            )}
            
            {filterDate && (
              <TouchableOpacity onPress={() => setFilterDate(null)} style={{ alignSelf: 'flex-start', marginBottom: 12 }}>
                <Text style={{ color: "#ef4444", fontSize: 12, fontWeight: "700" }}>Clear Filter</Text>
              </TouchableOpacity>
            )}

            <ScrollView contentContainerStyle={{ paddingBottom: 40 }} showsVerticalScrollIndicator={false}>
              {filteredSales.length === 0 ? (
                <View style={{ alignItems: "center", marginTop: 40 }}>
                  <Text style={{ color: "#94a3b8" }}>No orders found for this date</Text>
                </View>
              ) : (
                filteredSales.map((sale) => (
                  <View key={sale.id || sale._id} style={styles.historyItem}>
                    <View style={{ flex: 1 }}>
                      <Text style={styles.historyInvoice}>{sale.invoiceNo || sale.publicId}</Text>
                      <Text style={styles.historyMeta}>
                        {new Date(sale.createdAt).toLocaleTimeString()} • {sale.paymentType} • {formatCurrency(sale.totalAmount)}
                      </Text>
                    </View>
                    <View style={styles.historyActions}>
                      <TouchableOpacity onPress={() => handleEditSale(sale, true)} style={styles.histActionBtn}>
                        <Ionicons name="eye-outline" size={18} color="#64748b" />
                      </TouchableOpacity>
                      <TouchableOpacity onPress={() => handleEditSale(sale, false)} style={styles.histActionBtn}>
                        <Ionicons name="create-outline" size={18} color="#0f766e" />
                      </TouchableOpacity>
                      <TouchableOpacity onPress={() => handleDeleteSale(sale)} style={styles.histActionBtn}>
                        <Ionicons name="trash-outline" size={18} color="#ef4444" />
                      </TouchableOpacity>
                    </View>
                  </View>
                ))
              )}
            </ScrollView>
          </View>
        </View>
      </Modal>
    </View>
  );
}

const styles = StyleSheet.create({
  screen: { flex: 1, backgroundColor: "#f8fafc" },
  main: { flex: 1 },
  productListSection: { flex: 1, padding: 12 },
  searchBar: {
    flex: 1,
    flexDirection: "row", alignItems: "center", backgroundColor: "#fff",
    borderRadius: 16, paddingHorizontal: 16, paddingVertical: 12,
    shadowColor: "#000", shadowOpacity: 0.04, shadowRadius: 8, elevation: 2,
  },
  searchInput: { flex: 1, marginLeft: 10, color: "#1e293b", fontSize: 16 },
  row: { justifyContent: "space-between", marginBottom: 12 },
  productCard: {
    backgroundColor: "#fff", width: "48.5%", borderRadius: 20, padding: 16,
    alignItems: "center", shadowColor: "#000", shadowOpacity: 0.04, shadowRadius: 10, elevation: 2,
  },
  productIconWrap: { width: 48, height: 48, borderRadius: 16, backgroundColor: "#f0fdfa", alignItems: "center", justifyContent: "center", marginBottom: 10 },
  productName: { color: "#334155", fontWeight: "700", textAlign: "center", fontSize: 13, height: 36 },
  productPrice: { color: "#0f766e", fontWeight: "800", fontSize: 15, marginTop: 4 },
  addIndicator: { position: "absolute", top: 12, right: 12, width: 20, height: 20, borderRadius: 10, backgroundColor: "#0f766e", alignItems: "center", justifyContent: "center" },
  
  cartBar: {
    backgroundColor: "#0f172a", borderTopLeftRadius: 24, borderTopRightRadius: 24,
    padding: 20, paddingBottom: 24, flexDirection: "row", alignItems: "center", justifyContent: "space-between"
  },
  cartInfo: { gap: 2 },
  cartLabel: { color: "#94a3b8", fontSize: 13, fontWeight: "600" },
  cartTotal: { color: "#fff", fontSize: 20, fontWeight: "900" },
  checkoutBtn: {
    backgroundColor: "#0f766e", paddingHorizontal: 20, paddingVertical: 14,
    borderRadius: 16, flexDirection: "row", alignItems: "center", gap: 10
  },
  checkoutBtnText: { color: "#fff", fontWeight: "800", fontSize: 15 },
  
  modalOverlay: { flex: 1, backgroundColor: "rgba(0,0,0,0.6)", justifyContent: "flex-end" },
  modalCard: { backgroundColor: "#fff", borderTopLeftRadius: 32, borderTopRightRadius: 32, height: "85%", padding: 24 },
  modalHeader: { flexDirection: "row", justifyContent: "space-between", alignItems: "center", marginBottom: 20 },
  modalTitle: { fontSize: 20, fontWeight: "900", color: "#0f172a" },
  modalScroll: { flex: 1 },
  cartItem: { flexDirection: "row", alignItems: "center", paddingVertical: 14, borderBottomWidth: 1, borderBottomColor: "#f1f5f9" },
  cartItemName: { fontSize: 15, fontWeight: "700", color: "#1e293b" },
  cartItemPrice: { fontSize: 13, color: "#64748b", marginTop: 2 },
  qtyControls: { flexDirection: "row", alignItems: "center", gap: 14, backgroundColor: "#f8fafc", padding: 6, borderRadius: 12, marginHorizontal: 12 },
  qtyBtn: { width: 28, height: 28, borderRadius: 8, backgroundColor: "#fff", alignItems: "center", justifyContent: "center", elevation: 1 },
  qtyInput: { fontWeight: "800", color: "#0f766e", fontSize: 16, textAlign: "center", minWidth: 30, padding: 0 },
  removeBtn: { padding: 6 },
  cartBadge: { position: "absolute", top: -4, right: -4, backgroundColor: "#ef4444", borderRadius: 8, minWidth: 16, height: 16, alignItems: "center", justifyContent: "center", paddingHorizontal: 4 },
  cartBadgeText: { color: "#fff", fontSize: 9, fontWeight: "900" },
  
  paymentSection: { marginTop: 20, gap: 12 },
  paymentTitle: { fontSize: 14, fontWeight: "800", color: "#475569", textTransform: "uppercase", letterSpacing: 0.5 },
  paymentRow: { flexDirection: "row", gap: 10 },
  payChip: { flex: 1, paddingVertical: 12, borderRadius: 14, borderWidth: 1.5, borderColor: "#e2e8f0", alignItems: "center" },
  payChipActive: { backgroundColor: "#0f766e", borderColor: "#0f766e" },
  payChipText: { fontWeight: "800", color: "#64748b", fontSize: 12 },
  
  summaryFooter: { marginTop: 24, gap: 16, borderTopWidth: 1, borderTopColor: "#f1f5f9", paddingTop: 20 },
  fullTotalRow: { flexDirection: "row", justifyContent: "space-between", alignItems: "center" },
  fullTotalLabel: { fontSize: 15, fontWeight: "600", color: "#64748b" },
  fullTotalValue: { fontSize: 24, fontWeight: "900", color: "#0f172a" },
  finalizeBtn: { backgroundColor: "#0f766e", paddingVertical: 18, borderRadius: 18, alignItems: "center", justifyContent: "center", flexDirection: "row", gap: 12 },
  finalizeText: { color: "#fff", fontWeight: "900", fontSize: 17 },
  
  headerRow: { flexDirection: "row", alignItems: "center", gap: 12, marginBottom: 16 },
  historyToggle: { backgroundColor: "#fff", padding: 12, borderRadius: 16, elevation: 2, shadowColor: "#000", shadowOpacity: 0.04, shadowRadius: 8 },
  
  historyItem: {
    flexDirection: "row", alignItems: "center", padding: 16,
    backgroundColor: "#f8fafc", borderRadius: 16, marginBottom: 12,
  },
  historyInvoice: { fontSize: 15, fontWeight: "800", color: "#1e293b" },
  historyMeta: { fontSize: 12, color: "#64748b", marginTop: 2 },
  historyActions: { flexDirection: "row", gap: 8 },
  histActionBtn: { padding: 8, backgroundColor: "#fff", borderRadius: 10, elevation: 1 },
});
