import { BASE_URL, getAuthToken } from "@/services/api";
import { Ionicons } from "@expo/vector-icons";
import { useEffect, useState } from "react";
import {
  ActivityIndicator,
  Alert,
  ScrollView,
  StyleSheet,
  Text,
  TouchableOpacity,
  View,
} from "react-native";

const apiHeaders = () => ({
  "Content-Type": "application/json",
  ...(getAuthToken() ? { Authorization: `Bearer ${getAuthToken()}` } : {}),
});

const fetchTrash = async () => {
  const res = await fetch(`${BASE_URL}/trash`, { headers: apiHeaders() });
  const data = await res.json();
  return data?.data?.content ?? data?.data ?? data?.content ?? [];
};

const restoreItem = async (id: string, type: string) => {
  const res = await fetch(`${BASE_URL}/trash/${type}/${id}/restore`, {
    method: "POST",
    headers: apiHeaders(),
  });
  const data = await res.json();
  if (!res.ok) throw new Error(data?.message ?? "Restore failed");
  return data;
};

const permanentDelete = async (id: string, type: string) => {
  const res = await fetch(`${BASE_URL}/trash/${type}/${id}/permanent`, { 
    method: "DELETE", 
    headers: apiHeaders() 
  });
  if (!res.ok) {
    const data = await res.json();
    throw new Error(data?.message ?? "Delete failed");
  }
};

const TYPE_COLORS: Record<string, { bg: string; color: string; icon: string }> = {
  product: { bg: "#eff6ff", color: "#1d4ed8", icon: "cube-outline" },
  products: { bg: "#eff6ff", color: "#1d4ed8", icon: "cube-outline" },
  supplier: { bg: "#faf5ff", color: "#7c3aed", icon: "briefcase-outline" },
  suppliers: { bg: "#faf5ff", color: "#7c3aed", icon: "briefcase-outline" },
  customer: { bg: "#fdf4ff", color: "#a21caf", icon: "person-outline" },
  "credit-customers": { bg: "#fdf4ff", color: "#a21caf", icon: "person-outline" },
  cheque: { bg: "#fffbeb", color: "#b45309", icon: "document-text-outline" },
  cheques: { bg: "#fffbeb", color: "#b45309", icon: "document-text-outline" },
  sale: { bg: "#f0fdfa", color: "#0f766e", icon: "receipt-outline" },
  orders: { bg: "#f0fdfa", color: "#0f766e", icon: "receipt-outline" },
};

export default function TrashScreen() {
  const [items, setItems] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [actionLoading, setActionLoading] = useState<string | null>(null);

  const load = async () => {
    setLoading(true);
    try {
      const list = await fetchTrash();
      setItems(Array.isArray(list) ? list : []);
    } catch {
      setItems([]);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => { load(); }, []);

  const handleRestore = (item: any) => {
    Alert.alert("Restore Item", `Restore "${item.name ?? item.title ?? item.id}"?`, [
      { text: "Cancel", style: "cancel" },
      {
        text: "Restore", style: "default",
        onPress: async () => {
          setActionLoading(item.id ?? item._id);
          try {
            await restoreItem(item.id ?? item._id, item.type ?? item.entityType ?? "products");
            load();
          } catch (e: any) {
            Alert.alert("Error", e.message);
          } finally {
            setActionLoading(null);
          }
        },
      },
    ]);
  };

  const handlePermanentDelete = (item: any) => {
    Alert.alert(
      "Permanently Delete",
      `This will PERMANENTLY delete "${item.name ?? item.title ?? item.id}". This cannot be undone.`,
      [
        { text: "Cancel", style: "cancel" },
        {
          text: "Delete Forever", style: "destructive",
          onPress: async () => {
            setActionLoading(item.id ?? item._id);
            try {
              await permanentDelete(item.id ?? item._id, item.type ?? item.entityType ?? "products");
              load();
            } catch (e: any) {
              Alert.alert("Error", e.message);
            } finally {
              setActionLoading(null);
            }
          },
        },
      ]
    );
  };

  const getTypeStyle = (type: string) => TYPE_COLORS[type?.toLowerCase()] ?? { bg: "#f8fafc", color: "#64748b", icon: "archive-outline" };

  return (
    <View style={styles.screen}>
      {/* Header */}
      <View style={styles.headerCard}>
        <View style={styles.headerIcon}>
          <Ionicons name="trash" size={22} color="#fff" />
        </View>
        <View style={{ flex: 1 }}>
          <Text style={styles.headerTitle}>Trash</Text>
          <Text style={styles.headerSub}>Soft-deleted records — restore or purge</Text>
        </View>
        <TouchableOpacity style={styles.refreshBtn} onPress={load}>
          <Ionicons name="refresh" size={18} color="#0f172a" />
        </TouchableOpacity>
      </View>

      {/* Warning Banner */}
      <View style={styles.warningBanner}>
        <Ionicons name="warning" size={18} color="#b45309" />
        <Text style={styles.warningText}>
          Items in trash will be permanently deleted after 30 days.
        </Text>
      </View>

      {loading ? (
        <ActivityIndicator size="large" color="#0f766e" style={{ marginTop: 40 }} />
      ) : (
        <ScrollView style={{ flex: 1 }} contentContainerStyle={styles.list}>
          {items.length === 0 ? (
            <View style={styles.empty}>
              <Ionicons name="checkmark-circle-outline" size={64} color="#86efac" />
              <Text style={styles.emptyTitle}>Trash is empty</Text>
              <Text style={styles.emptyText}>All deleted items will appear here</Text>
            </View>
          ) : (
            items.map((item) => {
              const id = item.id ?? item._id;
              const typeStyle = getTypeStyle(item.type ?? item.entityType);
              const isLoading = actionLoading === id;

              return (
                <View key={id} style={styles.card}>
                  <View style={[styles.typeIcon, { backgroundColor: typeStyle.bg }]}>
                    <Ionicons name={typeStyle.icon as any} size={22} color={typeStyle.color} />
                  </View>
                  <View style={{ flex: 1 }}>
                    <Text style={styles.itemName}>{item.name ?? item.title ?? item.invoiceNo ?? id}</Text>
                    <Text style={styles.itemType}>{(item.type ?? item.entityType ?? "item").toUpperCase()}</Text>
                    {item.deletedAt && (
                      <Text style={styles.itemDate}>Deleted: {new Date(item.deletedAt).toLocaleDateString()}</Text>
                    )}
                  </View>
                  <View style={styles.actions}>
                    {isLoading ? (
                      <ActivityIndicator color="#0f766e" size="small" />
                    ) : (
                      <>
                        <TouchableOpacity style={styles.restoreBtn} onPress={() => handleRestore(item)}>
                          <Ionicons name="refresh-outline" size={16} color="#0f766e" />
                        </TouchableOpacity>
                        <TouchableOpacity style={styles.deleteBtn} onPress={() => handlePermanentDelete(item)}>
                          <Ionicons name="trash-outline" size={16} color="#ef4444" />
                        </TouchableOpacity>
                      </>
                    )}
                  </View>
                </View>
              );
            })
          )}
        </ScrollView>
      )}
    </View>
  );
}

const styles = StyleSheet.create({
  screen: { flex: 1, backgroundColor: "#f4f7fb" },
  headerCard: {
    backgroundColor: "#0f172a", margin: 16, borderRadius: 20,
    padding: 18, flexDirection: "row", alignItems: "center", gap: 14,
  },
  headerIcon: { width: 44, height: 44, borderRadius: 14, backgroundColor: "#ef4444", alignItems: "center", justifyContent: "center" },
  headerTitle: { color: "#fff", fontSize: 16, fontWeight: "800" },
  headerSub: { color: "#94a3b8", fontSize: 12, marginTop: 2 },
  refreshBtn: { width: 40, height: 40, borderRadius: 12, backgroundColor: "#1e293b", alignItems: "center", justifyContent: "center" },
  warningBanner: {
    flexDirection: "row", alignItems: "center", gap: 10,
    backgroundColor: "#fef3c7", marginHorizontal: 16, marginBottom: 12,
    padding: 14, borderRadius: 14,
  },
  warningText: { flex: 1, color: "#92400e", fontSize: 13, lineHeight: 18 },
  list: { padding: 16, paddingTop: 4, gap: 10 },
  empty: { alignItems: "center", paddingTop: 60, gap: 12 },
  emptyTitle: { color: "#0f172a", fontSize: 18, fontWeight: "700" },
  emptyText: { color: "#94a3b8", fontSize: 14 },
  card: {
    backgroundColor: "#fff", borderRadius: 18, padding: 16,
    flexDirection: "row", alignItems: "center", gap: 14,
    shadowColor: "#0f172a", shadowOpacity: 0.04, shadowRadius: 8, elevation: 2,
  },
  typeIcon: { width: 48, height: 48, borderRadius: 14, alignItems: "center", justifyContent: "center" },
  itemName: { color: "#0f172a", fontWeight: "700", fontSize: 15 },
  itemType: { color: "#94a3b8", fontSize: 10, fontWeight: "700", marginTop: 2 },
  itemDate: { color: "#f59e0b", fontSize: 11, marginTop: 4 },
  actions: { flexDirection: "row", gap: 8 },
  restoreBtn: { width: 36, height: 36, borderRadius: 10, backgroundColor: "#f0fdfa", alignItems: "center", justifyContent: "center" },
  deleteBtn: { width: 36, height: 36, borderRadius: 10, backgroundColor: "#fef2f2", alignItems: "center", justifyContent: "center" },
});
