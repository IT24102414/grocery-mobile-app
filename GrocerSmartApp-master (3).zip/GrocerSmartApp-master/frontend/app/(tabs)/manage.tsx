import React, { useState } from 'react';
import { View, Text, StyleSheet, TextInput, TouchableOpacity, ScrollView, Alert, ActivityIndicator } from 'react-native';

const API_BASE_URL = process.env.EXPO_PUBLIC_API_URL || 'http://10.118.221.102:8000/api';

export default function ManageScreen() {
  const [loading, setLoading] = useState(false);
  const [formData, setFormData] = useState({
    name: '',
    category: '',
    unitPrice: '',
    bulkPrice: '',
    retailStock: '',
    bulkStock: '',
  });

  const handleSubmit = async () => {
    if (!formData.name || !formData.category || !formData.unitPrice || !formData.bulkPrice) {
      Alert.alert('Error', 'Please fill all required fields');
      return;
    }

    try {
      setLoading(true);
      const payload = {
        name: formData.name,
        category: formData.category,
        unitPrice: parseFloat(formData.unitPrice),
        bulkPrice: parseFloat(formData.bulkPrice),
        stockLevels: {
            retailQty: parseInt(formData.retailStock) || 0,
            bulkQty: parseFloat(formData.bulkStock) || 0
        },
        unitConfig: {
            bulkUnit: 'Case',
            retailUnit: 'Piece',
            conversionFactor: 1
        },
        reorderPoint: 10,
        status: 'ACTIVE'
      };

      const response = await fetch(`${API_BASE_URL}/products`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload),
      });
      
      const result = await response.json();
      
      // We don't have auth token locally currently, so post might fail if protected. 
      // Ensure backend isn't blocking it in this simple RN example.
      
      if (response.ok || result.success) {
        Alert.alert('Success', 'Product added successfully');
        setFormData({ name: '', category: '', unitPrice: '', bulkPrice: '', retailStock: '', bulkStock: '' });
      } else {
        Alert.alert('Error', result.message || 'Failed to add product');
      }
    } catch (error) {
      Alert.alert('Error', 'Network error');
    } finally {
      setLoading(false);
    }
  };

  return (
    <ScrollView style={styles.container}>
      <View style={styles.header}>
        <Text style={styles.headerTitle}>Add New Product</Text>
      </View>
      <View style={styles.form}>
        <Text style={styles.label}>Product Name *</Text>
        <TextInput 
          style={styles.input} 
          value={formData.name} 
          onChangeText={(v) => setFormData({...formData, name: v})} 
        />

        <Text style={styles.label}>Category *</Text>
        <TextInput 
          style={styles.input} 
          value={formData.category} 
          onChangeText={(v) => setFormData({...formData, category: v})} 
        />

        <View style={styles.row}>
          <View style={{flex: 1, marginRight: 8}}>
            <Text style={styles.label}>Unit Price *</Text>
            <TextInput 
              style={styles.input} 
              keyboardType="numeric" 
              value={formData.unitPrice} 
              onChangeText={(v) => setFormData({...formData, unitPrice: v})} 
            />
          </View>
          <View style={{flex: 1, marginLeft: 8}}>
            <Text style={styles.label}>Bulk Price *</Text>
            <TextInput 
              style={styles.input} 
              keyboardType="numeric" 
              value={formData.bulkPrice} 
              onChangeText={(v) => setFormData({...formData, bulkPrice: v})} 
            />
          </View>
        </View>

        <View style={styles.row}>
          <View style={{flex: 1, marginRight: 8}}>
            <Text style={styles.label}>Retail Stock</Text>
            <TextInput 
              style={styles.input} 
              keyboardType="numeric" 
              value={formData.retailStock} 
              onChangeText={(v) => setFormData({...formData, retailStock: v})} 
            />
          </View>
          <View style={{flex: 1, marginLeft: 8}}>
            <Text style={styles.label}>Bulk Stock</Text>
            <TextInput 
              style={styles.input} 
              keyboardType="numeric" 
              value={formData.bulkStock} 
              onChangeText={(v) => setFormData({...formData, bulkStock: v})} 
            />
          </View>
        </View>

        <TouchableOpacity style={styles.button} onPress={handleSubmit} disabled={loading}>
          {loading ? <ActivityIndicator color="#fff" /> : <Text style={styles.buttonText}>Submit Product</Text>}
        </TouchableOpacity>
      </View>
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#F3F4F6',
  },
  header: {
    paddingTop: 60,
    paddingBottom: 20,
    backgroundColor: '#ffffff',
    alignItems: 'center',
    borderBottomWidth: 1,
    borderBottomColor: '#E5E7EB',
  },
  headerTitle: {
    fontSize: 20,
    fontWeight: 'bold',
    color: '#111827',
  },
  form: {
    padding: 16,
  },
  label: {
    fontSize: 14,
    fontWeight: 'bold',
    color: '#374151',
    marginBottom: 6,
    marginTop: 12,
  },
  input: {
    backgroundColor: '#ffffff',
    padding: 12,
    borderRadius: 8,
    borderWidth: 1,
    borderColor: '#D1D5DB',
  },
  row: {
    flexDirection: 'row',
    justifyContent: 'space-between',
  },
  button: {
    backgroundColor: '#10B981',
    padding: 16,
    borderRadius: 8,
    alignItems: 'center',
    marginTop: 24,
  },
  buttonText: {
    color: '#ffffff',
    fontSize: 16,
    fontWeight: 'bold',
  },
});
