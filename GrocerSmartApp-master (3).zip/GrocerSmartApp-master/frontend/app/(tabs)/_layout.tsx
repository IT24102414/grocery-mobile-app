import SidebarNav from "@/components/sidebar-nav";
import { useAuth } from "@/context/AuthContext";
import { useColorScheme } from "@/hooks/use-color-scheme";
import { Ionicons } from "@expo/vector-icons";
import { Redirect, Stack, usePathname, useRouter } from "expo-router";
import { useState } from "react";
import { useSafeAreaInsets } from "react-native-safe-area-context";
import {
  StyleSheet,
  Text,
  TouchableOpacity,
  View,
} from "react-native";

type BottomTab = {
  name: string;
  label: string;
  icon: string;
  activeIcon: string;
  route: string;
};

const BOTTOM_TABS: BottomTab[] = [
  { name: "index", label: "Dashboard", icon: "home-outline", activeIcon: "home", route: "/(tabs)/" },
  { name: "pos", label: "POS", icon: "cart-outline", activeIcon: "cart", route: "/(tabs)/pos" },
  { name: "settings", label: "Settings", icon: "settings-outline", activeIcon: "settings", route: "/(tabs)/settings" },
];

const PAGE_TITLES: Record<string, string> = {
  index: "Dashboard",
  pos: "Point of Sale",
  inventory: "Products",
  cheques: "Cheques",
  "credit-customers": "Credit Customers",
  suppliers: "Suppliers",
  analytics: "Analytics",
  settings: "Settings",
  users: "Users",
  "convert-stock": "Convert Stock",
  "purchase-orders": "Purchase Orders",
  reports: "Reports",
  trash: "Trash",
};

export default function TabLayout() {
  const colorScheme = useColorScheme();
  const { isAuthenticated } = useAuth();
  const router = useRouter();
  const pathname = usePathname();
  const [isSidebarOpen, setIsSidebarOpen] = useState(false);

  if (!isAuthenticated) {
    return <Redirect href="/login" />;
  }

  const isDark = colorScheme === "dark";

  const topBarBg = isDark ? "#0f172a" : "#ffffff";
  const topBarBorder = isDark ? "#1e293b" : "#e2e8f0";
  const bottomBarBg = isDark ? "#0f172a" : "#ffffff";
  const bottomBarBorder = isDark ? "#1e293b" : "#e2e8f0";
  const activeColor = "#0f766e";
  const inactiveColor = isDark ? "#64748b" : "#94a3b8";
  const textDark = isDark ? "#f1f5f9" : "#0f172a";

  const getActiveTab = () => {
    if (!pathname || pathname === "/" || pathname === "/(tabs)" || pathname === "/(tabs)/") return "index";
    if (pathname.includes("/pos")) return "pos";
    if (pathname.includes("/settings")) return "settings";
    return "other";
  };
  const activeTab = getActiveTab();

  const currentSidebarRoute = (() => {
    if (!pathname || pathname === "/" || pathname === "/(tabs)" || pathname === "/(tabs)/") return "index";
    const segments = pathname.split("/").filter(Boolean);
    return segments[segments.length - 1] ?? "index";
  })();

  const getPageTitle = () => PAGE_TITLES[currentSidebarRoute] ?? "GrocerSmart";

  const insets = useSafeAreaInsets();

  return (
    <View style={[styles.root, { paddingTop: insets.top }]}>
      {/* ── Top Bar ── */}
      <View
        style={[
          styles.topBar,
          { backgroundColor: topBarBg, borderBottomColor: topBarBorder },
        ]}
      >
        <TouchableOpacity
          style={[styles.iconBtn, { backgroundColor: isDark ? "#1e293b" : "#f1f5f9" }]}
          onPress={() => setIsSidebarOpen(true)}
          activeOpacity={0.7}
        >
          <Ionicons name="menu" size={22} color={isDark ? "#e2e8f0" : "#334155"} />
        </TouchableOpacity>

        <Text style={[styles.pageTitle, { color: textDark }]}>{getPageTitle()}</Text>

        <TouchableOpacity
          style={[styles.iconBtn, { backgroundColor: isDark ? "#1e293b" : "#f1f5f9" }]}
          activeOpacity={0.7}
        >
          <Ionicons name="notifications-outline" size={20} color={isDark ? "#e2e8f0" : "#334155"} />
        </TouchableOpacity>
      </View>

      {/* ── Content ── */}
      <View style={styles.content}>
        <Stack screenOptions={{ headerShown: false, animation: "fade" }}>
          <Stack.Screen name="index" />
          <Stack.Screen name="pos" />
          <Stack.Screen name="inventory" />
          <Stack.Screen name="cheques" />
          <Stack.Screen name="credit-customers" />
          <Stack.Screen name="suppliers" />
          <Stack.Screen name="analytics" />
          <Stack.Screen name="settings" />
          <Stack.Screen name="users" />
          <Stack.Screen name="convert-stock" />
          <Stack.Screen name="purchase-orders" />
          <Stack.Screen name="reports" />
          <Stack.Screen name="trash" />
        </Stack>
      </View>

      {/* ── Bottom Tab Bar ── */}
      <View
        style={[
          styles.bottomBar,
          { backgroundColor: bottomBarBg, borderTopColor: bottomBarBorder },
        ]}
      >
        {BOTTOM_TABS.map((tab) => {
          const isActive = activeTab === tab.name;
          return (
            <TouchableOpacity
              key={tab.name}
              style={styles.tabItem}
              onPress={() => router.push(tab.route as any)}
              activeOpacity={0.7}
            >
              <View
                style={[
                  styles.tabPill,
                  isActive && { backgroundColor: "rgba(15,118,110,0.1)" },
                ]}
              >
                <Ionicons
                  name={(isActive ? tab.activeIcon : tab.icon) as any}
                  size={22}
                  color={isActive ? activeColor : inactiveColor}
                />
              </View>
              <Text
                style={[
                  styles.tabLabel,
                  { color: isActive ? activeColor : inactiveColor },
                  isActive && { fontWeight: "700" },
                ]}
              >
                {tab.label}
              </Text>
            </TouchableOpacity>
          );
        })}
      </View>

      {/* ── Sidebar Overlay ── */}
      {isSidebarOpen && (
        <SidebarNav
          currentRoute={currentSidebarRoute}
          onClose={() => setIsSidebarOpen(false)}
        />
      )}
    </View>
  );
}

const styles = StyleSheet.create({
  root: { flex: 1 },
  topBar: {
    height: 60,
    paddingHorizontal: 16,
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "space-between",
    borderBottomWidth: 1,
    zIndex: 10,
    elevation: 4,
  },
  iconBtn: {
    width: 40, height: 40, borderRadius: 12,
    alignItems: "center", justifyContent: "center",
  },
  pageTitle: {
    fontSize: 17, fontWeight: "700",
    flex: 1, textAlign: "center", marginHorizontal: 8,
  },
  content: { flex: 1 },
  bottomBar: {
    flexDirection: "row",
    borderTopWidth: 1,
    paddingBottom: 8,
    paddingTop: 6,
    height: 70,
    zIndex: 10,
    elevation: 8,
  },
  tabItem: {
    flex: 1, alignItems: "center", justifyContent: "center", gap: 4,
  },
  tabPill: {
    width: 50, height: 30, borderRadius: 15,
    alignItems: "center", justifyContent: "center",
  },
  tabLabel: { fontSize: 11, fontWeight: "500" },
});
