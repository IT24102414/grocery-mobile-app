import { BASE_URL, getAuthToken } from "@/services/api";
import { Ionicons } from "@expo/vector-icons";
import { useEffect, useState } from "react";
import {
  ActivityIndicator,
  Alert,
  Modal,
  Pressable,
  ScrollView,
  StyleSheet,
  Text,
  TextInput,
  TouchableOpacity,
  View,
} from "react-native";

const apiHeaders = () => ({
  "Content-Type": "application/json",
  ...(getAuthToken() ? { Authorization: `Bearer ${getAuthToken()}` } : {}),
});

const fetchUsers = async (params: Record<string, any> = {}) => {
  const q = new URLSearchParams(Object.entries(params).filter(([, v]) => v != null).map(([k, v]) => [k, String(v)]));
  const res = await fetch(`${BASE_URL}/users?${q}`, { headers: apiHeaders() });
  const data = await res.json();
  return data;
};

const createUser = async (payload: any) => {
  const res = await fetch(`${BASE_URL}/users`, {
    method: "POST",
    headers: apiHeaders(),
    body: JSON.stringify(payload),
  });
  const data = await res.json();
  if (!res.ok) throw new Error(data?.message ?? "Failed to create user");
  return data;
};

const updateUser = async (id: string, payload: any) => {
  const res = await fetch(`${BASE_URL}/users/${id}`, {
    method: "PUT",
    headers: apiHeaders(),
    body: JSON.stringify(payload),
  });
  const data = await res.json();
  if (!res.ok) throw new Error(data?.message ?? "Failed to update user");
  return data;
};

const deleteUser = async (id: string) => {
  const res = await fetch(`${BASE_URL}/users/${id}`, {
    method: "DELETE",
    headers: apiHeaders(),
  });
  if (!res.ok) {
    const data = await res.json();
    throw new Error(data?.message ?? "Failed to delete user");
  }
};

const ROLES = ["ADMIN", "MANAGER", "CASHIER"];

const ROLE_COLORS: Record<string, string> = {
  ADMIN: "#dc2626",
  MANAGER: "#7c3aed",
  CASHIER: "#0f766e",
};

export default function UsersScreen() {
  const [users, setUsers] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState("");
  const [modalVisible, setModalVisible] = useState(false);
  const [editUser, setEditUser] = useState<any>(null);
  const [saving, setSaving] = useState(false);
  const [form, setForm] = useState({ username: "", fullName: "", password: "", role: "CASHIER", permissions: "" });

  const load = async () => {
    setLoading(true);
    try {
      const data = await fetchUsers({ size: 100 });
      const list = data?.data?.content ?? data?.data ?? data?.content ?? [];
      setUsers(Array.isArray(list) ? list : []);
    } catch (e) {
      setUsers([]);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => { load(); }, []);

  const filtered = users.filter(
    (u) =>
      u.username?.toLowerCase().includes(search.toLowerCase()) ||
      u.fullName?.toLowerCase().includes(search.toLowerCase())
  );

  const openCreate = () => {
    setEditUser(null);
    setForm({ username: "", fullName: "", password: "", role: "CASHIER", permissions: "POS_ACCESS" });
    setModalVisible(true);
  };

  const openEdit = (user: any) => {
    setEditUser(user);
    setForm({ 
      username: user.username ?? "", 
      fullName: user.fullName ?? "", 
      password: "", 
      role: user.role ?? "CASHIER",
      permissions: Array.isArray(user.permissions) ? user.permissions.join(", ") : user.permissions || ""
    });
    setModalVisible(true);
  };

  const handleSave = async () => {
    setSaving(true);
    try {
      if (editUser) {
        const payload: any = { 
          fullName: form.fullName, 
          role: form.role,
          permissions: form.permissions.split(",").map(p => p.trim()).filter(Boolean)
        };
        if (form.password) payload.password = form.password;
        await updateUser(editUser.id ?? editUser._id, payload);
      } else {
        const payload: any = { 
          username: form.username, 
          fullName: form.fullName, 
          password: form.password, 
          role: form.role,
          permissions: form.permissions.split(",").map(p => p.trim()).filter(Boolean)
        };
        await createUser(payload);
      }
      setModalVisible(false);
      load();
    } catch (e: any) {
      Alert.alert("Error", e.message ?? "Operation failed");
    } finally {
      setSaving(false);
    }
  };

  const handleDelete = (user: any) => {
    Alert.alert("Delete User", `Are you sure you want to delete "${user.fullName ?? user.username}"?`, [
      { text: "Cancel", style: "cancel" },
      {
        text: "Delete",
        style: "destructive",
        onPress: async () => {
          try {
            await deleteUser(user.id ?? user._id);
            load();
          } catch (e: any) {
            Alert.alert("Error", e.message);
          }
        },
      },
    ]);
  };

  return (
    <View style={styles.screen}>
      {/* Header */}
      <View style={styles.headerCard}>
        <View style={styles.headerIcon}>
          <Ionicons name="people" size={22} color="#fff" />
        </View>
        <View style={{ flex: 1 }}>
          <Text style={styles.headerTitle}>User Management</Text>
          <Text style={styles.headerSub}>System access and roles</Text>
        </View>
        <TouchableOpacity style={styles.addBtn} onPress={openCreate} activeOpacity={0.8}>
          <Ionicons name="add" size={20} color="#fff" />
          <Text style={styles.addBtnText}>Add User</Text>
        </TouchableOpacity>
      </View>

      {/* Search */}
      <View style={styles.searchRow}>
        <Ionicons name="search" size={18} color="#94a3b8" />
        <TextInput
          style={styles.searchInput}
          placeholder="Search users..."
          placeholderTextColor="#94a3b8"
          value={search}
          onChangeText={setSearch}
        />
      </View>

      {/* List */}
      {loading ? (
        <ActivityIndicator size="large" color="#0f766e" style={{ marginTop: 40 }} />
      ) : (
        <ScrollView
          style={{ flex: 1 }}
          contentContainerStyle={styles.list}
          showsVerticalScrollIndicator={false}
        >
          {filtered.length === 0 ? (
            <View style={styles.empty}>
              <Ionicons name="people-outline" size={48} color="#e2e8f0" />
              <Text style={styles.emptyText}>No users found</Text>
            </View>
          ) : (
            filtered.map((user) => (
              <View key={user.id ?? user._id} style={styles.card}>
                <View style={[styles.avatarCircle, { backgroundColor: ROLE_COLORS[user.role] ?? "#64748b" }]}>
                  <Text style={styles.avatarText}>
                    {(user.fullName ?? user.username ?? "?").slice(0, 1).toUpperCase()}
                  </Text>
                </View>
                <View style={{ flex: 1 }}>
                  <Text style={styles.userName}>{user.fullName ?? user.username}</Text>
                  <Text style={styles.userUsername}>@{user.username}</Text>
                  <View style={[styles.roleBadge, { backgroundColor: `${ROLE_COLORS[user.role] ?? "#64748b"}15` }]}>
                    <Text style={[styles.roleBadgeText, { color: ROLE_COLORS[user.role] ?? "#64748b" }]}>
                      {user.role ?? "CASHIER"}
                    </Text>
                  </View>
                </View>
                <View style={styles.actions}>
                  <TouchableOpacity style={styles.actionBtn} onPress={() => openEdit(user)}>
                    <Ionicons name="create-outline" size={18} color="#0f766e" />
                  </TouchableOpacity>
                  <TouchableOpacity style={[styles.actionBtn, { backgroundColor: "#fef2f2" }]} onPress={() => handleDelete(user)}>
                    <Ionicons name="trash-outline" size={18} color="#ef4444" />
                  </TouchableOpacity>
                </View>
              </View>
            ))
          )}
        </ScrollView>
      )}

      {/* Modal */}
      <Modal visible={modalVisible} animationType="slide" transparent onRequestClose={() => setModalVisible(false)}>
        <View style={styles.modalOverlay}>
          <View style={styles.modalCard}>
            <View style={styles.modalHeader}>
              <Text style={styles.modalTitle}>{editUser ? "Edit User" : "New User"}</Text>
              <TouchableOpacity onPress={() => setModalVisible(false)}>
                <Ionicons name="close" size={22} color="#64748b" />
              </TouchableOpacity>
            </View>

            <ScrollView contentContainerStyle={{ gap: 14 }}>
              {!editUser && (
                <View style={styles.fieldGroup}>
                  <Text style={styles.fieldLabel}>Username *</Text>
                  <TextInput
                    style={styles.fieldInput}
                    value={form.username}
                    onChangeText={(v) => setForm({ ...form, username: v })}
                    autoCapitalize="none"
                    placeholder="johndoe"
                    placeholderTextColor="#94a3b8"
                  />
                </View>
              )}

              <View style={styles.fieldGroup}>
                <Text style={styles.fieldLabel}>Full Name *</Text>
                <TextInput
                  style={styles.fieldInput}
                  value={form.fullName}
                  onChangeText={(v) => setForm({ ...form, fullName: v })}
                  placeholder="John Doe"
                  placeholderTextColor="#94a3b8"
                />
              </View>

              <View style={styles.fieldGroup}>
                <Text style={styles.fieldLabel}>{editUser ? "New Password (optional)" : "Password *"}</Text>
                <TextInput
                  style={styles.fieldInput}
                  value={form.password}
                  onChangeText={(v) => setForm({ ...form, password: v })}
                  secureTextEntry
                  placeholder="••••••••"
                  placeholderTextColor="#94a3b8"
                />
              </View>

              <View style={styles.fieldGroup}>
                <Text style={styles.fieldLabel}>Role *</Text>
                <View style={styles.roleRow}>
                  {ROLES.map((r) => (
                    <TouchableOpacity
                      key={r}
                      style={[
                        styles.roleChip,
                        form.role === r && { backgroundColor: ROLE_COLORS[r] ?? "#0f766e", borderColor: "transparent" },
                      ]}
                      onPress={() => setForm({ ...form, role: r })}
                    >
                      <Text
                        style={[
                          styles.roleChipText,
                          form.role === r && { color: "#fff" },
                        ]}
                      >
                        {r}
                      </Text>
                    </TouchableOpacity>
                  ))}
                </View>
              </View>
            </ScrollView>

            <TouchableOpacity style={styles.saveBtn} onPress={handleSave} disabled={saving} activeOpacity={0.85}>
              {saving ? (
                <ActivityIndicator color="#fff" />
              ) : (
                <Text style={styles.saveBtnText}>{editUser ? "Update User" : "Create User"}</Text>
              )}
            </TouchableOpacity>
          </View>
        </View>
      </Modal>
    </View>
  );
}

const styles = StyleSheet.create({
  screen: { flex: 1, backgroundColor: "#f4f7fb" },
  headerCard: {
    backgroundColor: "#0f172a",
    margin: 16,
    borderRadius: 20,
    padding: 18,
    flexDirection: "row",
    alignItems: "center",
    gap: 14,
  },
  headerIcon: {
    width: 44, height: 44, borderRadius: 14,
    backgroundColor: "#0f766e", alignItems: "center", justifyContent: "center",
  },
  headerTitle: { color: "#fff", fontSize: 16, fontWeight: "800" },
  headerSub: { color: "#94a3b8", fontSize: 12, marginTop: 2 },
  addBtn: {
    flexDirection: "row", alignItems: "center", gap: 6,
    backgroundColor: "#0f766e", borderRadius: 12, paddingHorizontal: 14, paddingVertical: 10,
  },
  addBtnText: { color: "#fff", fontWeight: "700", fontSize: 13 },
  searchRow: {
    flexDirection: "row", alignItems: "center", gap: 10,
    backgroundColor: "#fff", borderRadius: 14, marginHorizontal: 16, marginBottom: 12,
    paddingHorizontal: 14, paddingVertical: 12,
    shadowColor: "#0f172a", shadowOpacity: 0.04, shadowRadius: 8, elevation: 2,
  },
  searchInput: { flex: 1, color: "#0f172a", fontSize: 14 },
  list: { padding: 16, paddingTop: 4, gap: 10 },
  empty: { alignItems: "center", paddingTop: 60, gap: 12 },
  emptyText: { color: "#94a3b8", fontSize: 14, fontWeight: "600" },
  card: {
    backgroundColor: "#fff", borderRadius: 18, padding: 16,
    flexDirection: "row", alignItems: "center", gap: 14,
    shadowColor: "#0f172a", shadowOpacity: 0.04, shadowRadius: 8, elevation: 2,
  },
  avatarCircle: { width: 46, height: 46, borderRadius: 23, alignItems: "center", justifyContent: "center" },
  avatarText: { color: "#fff", fontSize: 18, fontWeight: "800" },
  userName: { color: "#0f172a", fontWeight: "700", fontSize: 15 },
  userUsername: { color: "#94a3b8", fontSize: 12, marginTop: 2 },
  roleBadge: { alignSelf: "flex-start", borderRadius: 999, paddingHorizontal: 10, paddingVertical: 4, marginTop: 6 },
  roleBadgeText: { fontSize: 10, fontWeight: "800", letterSpacing: 0.5 },
  actions: { flexDirection: "row", gap: 8 },
  actionBtn: {
    width: 36, height: 36, borderRadius: 10,
    backgroundColor: "#f0fdfa", alignItems: "center", justifyContent: "center",
  },
  modalOverlay: { flex: 1, backgroundColor: "rgba(0,0,0,0.4)", justifyContent: "flex-end" },
  modalCard: {
    backgroundColor: "#fff", borderTopLeftRadius: 28, borderTopRightRadius: 28,
    padding: 24, gap: 20, maxHeight: "90%",
  },
  modalHeader: { flexDirection: "row", alignItems: "center", justifyContent: "space-between" },
  modalTitle: { color: "#0f172a", fontSize: 20, fontWeight: "800" },
  fieldGroup: { gap: 6 },
  fieldLabel: { color: "#64748b", fontSize: 11, fontWeight: "700", textTransform: "uppercase", letterSpacing: 0.8 },
  fieldInput: {
    backgroundColor: "#f8fafc", borderRadius: 14, paddingHorizontal: 16, paddingVertical: 14,
    color: "#0f172a", fontSize: 15, borderWidth: 1, borderColor: "#e2e8f0",
  },
  roleRow: { flexDirection: "row", gap: 10 },
  roleChip: {
    flex: 1, paddingVertical: 10, borderRadius: 12, alignItems: "center",
    borderWidth: 1.5, borderColor: "#e2e8f0",
  },
  roleChipText: { fontSize: 11, fontWeight: "800", color: "#64748b", letterSpacing: 0.5 },
  saveBtn: {
    backgroundColor: "#0f766e", borderRadius: 16, paddingVertical: 16,
    alignItems: "center", marginTop: 8,
  },
  saveBtnText: { color: "#fff", fontWeight: "800", fontSize: 16 },
});
