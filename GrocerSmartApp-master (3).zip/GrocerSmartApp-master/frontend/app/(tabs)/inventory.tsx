import { BASE_URL, getAuthToken } from "@/services/api";
import { Ionicons } from "@expo/vector-icons";
import { useEffect, useState } from "react";
import {
  ActivityIndicator,
  Alert,
  Modal,
  ScrollView,
  StyleSheet,
  Text,
  TextInput,
  TouchableOpacity,
  View,
  Switch,
  Platform,
} from "react-native";
import SearchableDropdown from "@/components/searchable-dropdown";
import DateTimePicker from "@react-native-community/datetimepicker";

const apiHeaders = () => ({
  "Content-Type": "application/json",
  ...(getAuthToken() ? { Authorization: `Bearer ${getAuthToken()}` } : {}),
});

const fetchProducts = async (params: any = {}) => {
  const q = new URLSearchParams(Object.entries(params).filter(([, v]) => v != null).map(([k, v]) => [k, String(v)]));
  const res = await fetch(`${BASE_URL}/products?${q.toString()}`, { headers: apiHeaders() });
  const data = await res.json();
  return data?.data?.content ?? data?.data ?? data?.content ?? [];
};

const saveProduct = async (product: any, id?: string) => {
  const res = await fetch(`${BASE_URL}/products${id ? `/${id}` : ""}`, {
    method: id ? "PUT" : "POST",
    headers: apiHeaders(),
    body: JSON.stringify(product),
  });
  const data = await res.json();
  if (!res.ok) throw new Error(data?.message ?? "Failed to save product");
  return data;
};

const deleteProduct = async (id: string) => {
  const res = await fetch(`${BASE_URL}/products/${id}`, { method: "DELETE", headers: apiHeaders() });
  if (!res.ok) {
    const data = await res.json();
    throw new Error(data?.message ?? "Failed to delete product");
  }
};

export default function InventoryScreen() {
  const [products, setProducts] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState("");
  const [modalVisible, setModalVisible] = useState(false);
  const [saving, setSaving] = useState(false);
  const [editId, setEditId] = useState<string | null>(null);
  const [form, setForm] = useState({
    name: "",
    category: "",
    unitPrice: "",
    bulkPrice: "",
    purchasePrice: "",
    reorderPoint: "10",
    unitConfig: { bulkUnit: "Case", retailUnit: "Piece", conversionFactor: "1" },
    stockLevels: { bulkQty: "0", retailQty: "0" },
    status: "ACTIVE",
    expiryDate: "",
  });
  const [showDatePicker, setShowDatePicker] = useState(false);

  const categories = Array.from(new Set(products.map(p => p.category).filter(Boolean))).map(c => ({ label: c, value: c }));

  const load = async () => {
    setLoading(true);
    try {
      const data = await fetchProducts({ size: 1000 });
      setProducts(Array.isArray(data) ? data : []);
    } catch {
      setProducts([]);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => { load(); }, []);

  const filtered = products.filter(
    (p) =>
      p.name?.toLowerCase().includes(search.toLowerCase()) ||
      p.publicId?.toLowerCase().includes(search.toLowerCase()) ||
      p.category?.toLowerCase().includes(search.toLowerCase())
  );

  const openCreate = () => {
    setEditId(null);
    setForm({
      name: "", category: "", unitPrice: "", bulkPrice: "", purchasePrice: "", reorderPoint: "10",
      unitConfig: { bulkUnit: "Case", retailUnit: "Piece", conversionFactor: "1" },
      stockLevels: { bulkQty: "0", retailQty: "0" },
      status: "ACTIVE",
      expiryDate: "",
    });
    setModalVisible(true);
  };

  const openEdit = (product: any) => {
    setEditId(product.id ?? product._id);
    setForm({
      name: product.name || "",
      category: product.category || "",
      unitPrice: String(product.unitPrice || ""),
      bulkPrice: String(product.bulkPrice || ""),
      purchasePrice: String(product.purchasePrice || ""),
      reorderPoint: String(product.reorderPoint || "10"),
      unitConfig: {
        bulkUnit: product.unitConfig?.bulkUnit || "Case",
        retailUnit: product.unitConfig?.retailUnit || "Piece",
        conversionFactor: String(product.unitConfig?.conversionFactor || "1"),
      },
      stockLevels: {
        bulkQty: String(product.stockLevels?.bulkQty || "0"),
        retailQty: String(product.stockLevels?.retailQty || "0"),
      },
      status: product.status || "ACTIVE",
      expiryDate: product.batchDetails?.[0]?.expiryDate ? product.batchDetails[0].expiryDate.slice(0, 10) : "",
    });
    setModalVisible(true);
  };

  const handleSave = async () => {
    if (!form.name || !form.unitPrice || !form.bulkPrice) return Alert.alert("Error", "Name, Retail Price and Bulk Price are required");
    setSaving(true);
    try {
      const payload: any = {
        name: form.name,
        category: form.category,
        unitPrice: Number(form.unitPrice),
        bulkPrice: Number(form.bulkPrice),
        purchasePrice: Number(form.purchasePrice),
        reorderPoint: Number(form.reorderPoint),
        unitConfig: { 
          bulkUnit: form.unitConfig.bulkUnit,
          retailUnit: form.unitConfig.retailUnit,
          conversionFactor: Number(form.unitConfig.conversionFactor) 
        },
        stockLevels: { 
          bulkQty: Number(form.stockLevels.bulkQty), 
          retailQty: Number(form.stockLevels.retailQty) 
        },
        status: form.status,
        batchDetails: form.expiryDate ? [{
          expiryDate: new Date(form.expiryDate).toISOString(),
          costPrice: Number(form.purchasePrice),
          batchId: `B-${Date.now()}`
        }] : []
      };
      await saveProduct(payload, editId || undefined);
      setModalVisible(false);
      load();
    } catch (e: any) {
      Alert.alert("Error", e.message);
    } finally {
      setSaving(false);
    }
  };

  const handleDelete = (product: any) => {
    Alert.alert("Archive Product", `Are you sure you want to archive "${product.name}"?`, [
      { text: "Cancel", style: "cancel" },
      { text: "Archive", style: "destructive", onPress: async () => {
          try {
            await deleteProduct(product.id ?? product._id);
            load();
          } catch (e: any) { Alert.alert("Error", e.message); }
        }
      },
    ]);
  };

  const formatCurrency = (val: any) => `Rs.${Number(val || 0).toLocaleString()}`;

  return (
    <View style={styles.screen}>
      {/* Header */}
      <View style={styles.headerCard}>
        <View style={styles.headerIcon}>
          <Ionicons name="cube" size={22} color="#fff" />
        </View>
        <View style={{ flex: 1 }}>
          <Text style={styles.headerTitle}>Products Catalog</Text>
          <Text style={styles.headerSub}>Manage inventory and pricing</Text>
        </View>
        <TouchableOpacity style={styles.addBtn} onPress={openCreate} activeOpacity={0.8}>
          <Ionicons name="add" size={20} color="#fff" />
          <Text style={styles.addBtnText}>New</Text>
        </TouchableOpacity>
      </View>

      {/* Search */}
      <View style={styles.searchRow}>
        <Ionicons name="search" size={18} color="#94a3b8" />
        <TextInput
          style={styles.searchInput}
          placeholder="Search product name, ID, category..."
          placeholderTextColor="#94a3b8"
          value={search}
          onChangeText={setSearch}
        />
      </View>

      {loading ? (
        <ActivityIndicator size="large" color="#0f766e" style={{ marginTop: 40 }} />
      ) : (
        <ScrollView style={{ flex: 1 }} contentContainerStyle={styles.list} showsVerticalScrollIndicator={false}>
          {filtered.length === 0 ? (
            <View style={styles.empty}>
              <Ionicons name="cube-outline" size={48} color="#e2e8f0" />
              <Text style={styles.emptyText}>No products found</Text>
            </View>
          ) : (
            filtered.map((product) => {
              const retailQty = Number(product.stockLevels?.retailQty || 0);
              const reorder = Number(product.reorderPoint || 10);
              const isLowStock = retailQty <= reorder;

              return (
                <View key={product.id ?? product._id} style={styles.card}>
                  <TouchableOpacity 
                    style={styles.cardInfo} 
                    onPress={() => openEdit(product)} 
                    activeOpacity={0.7}
                  >
                    <View style={styles.cardMain}>
                      <Text style={styles.productName}>{product.name}</Text>
                      <View style={styles.categoryBadge}>
                        <Text style={styles.categoryText}>{product.category || "GENERAL"}</Text>
                      </View>
                    </View>
                    <View style={styles.stockInfo}>
                      <View style={[styles.stockBadge, isLowStock && styles.stockBadgeLow]}>
                        <Text style={[styles.stockText, isLowStock && styles.stockTextLow]}>
                          {retailQty} {product.unitConfig?.retailUnit || " units"} left
                        </Text>
                      </View>
                      <Text style={styles.priceText}>{formatCurrency(product.unitPrice)}</Text>
                    </View>
                  </TouchableOpacity>
                  
                  <View style={styles.cardActions}>
                    <TouchableOpacity onPress={() => handleDelete(product)} style={styles.actionBtn}>
                      <Ionicons name="trash-outline" size={18} color="#ef4444" />
                    </TouchableOpacity>
                  </View>
                </View>
              );
            })
          )}
        </ScrollView>
      )}

      {/* Product Modal */}
      <Modal visible={modalVisible} animationType="slide" transparent onRequestClose={() => setModalVisible(false)}>
        <View style={styles.modalOverlay}>
          <View style={styles.modalCard}>
            <View style={styles.modalHeader}>
              <Text style={styles.modalTitle}>{editId ? "Modify Product" : "Register Product"}</Text>
              <TouchableOpacity onPress={() => setModalVisible(false)}>
                <Ionicons name="close" size={22} color="#64748b" />
              </TouchableOpacity>
            </View>

            <ScrollView contentContainerStyle={{ gap: 14 }} showsVerticalScrollIndicator={false}>
              <View style={styles.fieldGroup}>
                <Text style={styles.fieldLabel}>Product Name *</Text>
                <TextInput style={styles.fieldInput} value={form.name} onChangeText={(v) => setForm({...form, name: v})} placeholder="Apple iPhone 15 Pro Max" />
              </View>

              <View style={styles.fieldGroup}>
                <SearchableDropdown
                  label="Category"
                  placeholder="Select or type category..."
                  items={categories}
                  value={form.category}
                  onValueChange={(v) => setForm({...form, category: v})}
                  allowCustom
                />
              </View>



              <View style={styles.row}>
                <View style={[styles.fieldGroup, { flex: 1 }]}>
                  <Text style={styles.fieldLabel}>Retail Price *</Text>
                  <TextInput style={styles.fieldInput} value={form.unitPrice} onChangeText={(v) => setForm({...form, unitPrice: v})} keyboardType="numeric" placeholder="0.00" />
                </View>
                <View style={[styles.fieldGroup, { flex: 1 }]}>
                  <Text style={styles.fieldLabel}>Purchase Price</Text>
                  <TextInput style={styles.fieldInput} value={form.purchasePrice} onChangeText={(v) => setForm({...form, purchasePrice: v})} keyboardType="numeric" placeholder="0.00" />
                </View>
              </View>

              <View style={styles.fieldGroup}>
                <Text style={styles.fieldLabel}>Bulk Price (LKR) *</Text>
                <TextInput style={styles.fieldInput} value={form.bulkPrice} onChangeText={(v) => setForm({...form, bulkPrice: v})} keyboardType="numeric" placeholder="0.00" />
              </View>

              <View style={styles.fieldGroup}>
                <Text style={styles.fieldLabel}>Expiry Date</Text>
                <TouchableOpacity 
                  style={styles.fieldInput} 
                  onPress={() => setShowDatePicker(true)}
                  activeOpacity={0.7}
                >
                  <Text style={{ color: form.expiryDate ? "#0f172a" : "#94a3b8" }}>
                    {form.expiryDate || "Select Expiry Date"}
                  </Text>
                </TouchableOpacity>
                {showDatePicker && (
                  <DateTimePicker
                    value={form.expiryDate ? new Date(form.expiryDate) : new Date()}
                    mode="date"
                    display={Platform.OS === 'ios' ? 'spinner' : 'default'}
                    onChange={(event, selectedDate) => {
                      setShowDatePicker(false);
                      if (selectedDate) {
                        setForm({ ...form, expiryDate: selectedDate.toISOString().split('T')[0] });
                      }
                    }}
                  />
                )}
              </View>

              <View style={styles.row}>
                <View style={[styles.fieldGroup, { flex: 1 }]}>
                  <Text style={styles.fieldLabel}>Retail Stock</Text>
                  <TextInput style={styles.fieldInput} value={form.stockLevels.retailQty} onChangeText={(v) => setForm({...form, stockLevels: {...form.stockLevels, retailQty: v}})} keyboardType="numeric" placeholder="0" />
                </View>
                <View style={[styles.fieldGroup, { flex: 1 }]}>
                  <Text style={styles.fieldLabel}>Reorder Point</Text>
                  <TextInput style={styles.fieldInput} value={form.reorderPoint} onChangeText={(v) => setForm({...form, reorderPoint: v})} keyboardType="numeric" placeholder="10" />
                </View>
              </View>



              <View style={styles.sectionDivider} />
              <Text style={styles.sectionTitle}>Bulk Configuration</Text>

              <View style={styles.row}>
                <View style={[styles.fieldGroup, { flex: 1 }]}>
                  <Text style={styles.fieldLabel}>Bulk Unit</Text>
                  <TextInput style={styles.fieldInput} value={form.unitConfig.bulkUnit} onChangeText={(v) => setForm({...form, unitConfig: {...form.unitConfig, bulkUnit: v}})} placeholder="Case" />
                </View>
                <View style={[styles.fieldGroup, { flex: 1 }]}>
                  <Text style={styles.fieldLabel}>Retail Unit</Text>
                  <TextInput style={styles.fieldInput} value={form.unitConfig.retailUnit} onChangeText={(v) => setForm({...form, unitConfig: {...form.unitConfig, retailUnit: v}})} placeholder="Piece" />
                </View>
              </View>

              <View style={styles.row}>
                <View style={[styles.fieldGroup, { flex: 1 }]}>
                  <Text style={styles.fieldLabel}>Conversion Factor</Text>
                  <TextInput style={styles.fieldInput} value={form.unitConfig.conversionFactor} onChangeText={(v) => setForm({...form, unitConfig: {...form.unitConfig, conversionFactor: v}})} keyboardType="numeric" placeholder="12" />
                </View>
                <View style={[styles.fieldGroup, { flex: 1 }]}>
                  <Text style={styles.fieldLabel}>Bulk Stock</Text>
                  <TextInput style={styles.fieldInput} value={form.stockLevels.bulkQty} onChangeText={(v) => setForm({...form, stockLevels: {...form.stockLevels, bulkQty: v}})} keyboardType="numeric" placeholder="0" />
                </View>
              </View>

              <View style={[styles.row, { alignItems: "center", justifyContent: "space-between", marginTop: 10 }]}>
                <Text style={styles.fieldLabel}>Product Status (Active)</Text>
                <Switch 
                  value={form.status === "ACTIVE"} 
                  onValueChange={(val) => setForm({...form, status: val ? "ACTIVE" : "INACTIVE"})}
                  trackColor={{ false: "#e2e8f0", true: "#0f766e" }}
                />
              </View>

            </ScrollView>

            <TouchableOpacity style={styles.saveBtn} onPress={handleSave} disabled={saving} activeOpacity={0.85}>
              {saving ? <ActivityIndicator color="#fff" /> : <Text style={styles.saveBtnText}>{editId ? "Update Product" : "Save Product"}</Text>}
            </TouchableOpacity>
          </View>
        </View>
      </Modal>
    </View>
  );
}

const styles = StyleSheet.create({
  screen: { flex: 1, backgroundColor: "#f4f7fb" },
  headerCard: {
    backgroundColor: "#0f172a", margin: 16, borderRadius: 20,
    padding: 18, flexDirection: "row", alignItems: "center", gap: 14,
  },
  headerIcon: { width: 44, height: 44, borderRadius: 14, backgroundColor: "#1d4ed8", alignItems: "center", justifyContent: "center" },
  headerTitle: { color: "#fff", fontSize: 16, fontWeight: "800" },
  headerSub: { color: "#94a3b8", fontSize: 12, marginTop: 2 },
  addBtn: { flexDirection: "row", alignItems: "center", gap: 6, backgroundColor: "#0f766e", borderRadius: 12, paddingHorizontal: 16, paddingVertical: 10 },
  addBtnText: { color: "#fff", fontWeight: "700", fontSize: 13 },
  searchRow: {
    flexDirection: "row", alignItems: "center", gap: 10,
    backgroundColor: "#fff", borderRadius: 14, marginHorizontal: 16, marginBottom: 12,
    paddingHorizontal: 14, paddingVertical: 12,
    shadowColor: "#0f172a", shadowOpacity: 0.04, shadowRadius: 8, elevation: 2,
  },
  searchInput: { flex: 1, color: "#0f172a", fontSize: 14 },
  list: { padding: 16, paddingTop: 4, gap: 12 },
  empty: { alignItems: "center", paddingTop: 60, gap: 12 },
  emptyText: { color: "#94a3b8", fontSize: 14, fontWeight: "600" },
  card: {
    backgroundColor: "#fff", borderRadius: 18, padding: 16,
    flexDirection: "row", alignItems: "center", gap: 14,
    shadowColor: "#0f172a", shadowOpacity: 0.04, shadowRadius: 8, elevation: 2,
  },
  cardInfo: { flex: 1, gap: 8 },
  cardMain: { flexDirection: "row", alignItems: "center", gap: 8 },
  productName: { color: "#0f172a", fontWeight: "700", fontSize: 15 },
  categoryBadge: { backgroundColor: "#f1f5f9", borderRadius: 6, paddingHorizontal: 8, paddingVertical: 2 },
  categoryText: { color: "#64748b", fontSize: 10, fontWeight: "800", textTransform: "uppercase" },
  stockInfo: { flexDirection: "row", alignItems: "center", gap: 12 },
  stockBadge: { backgroundColor: "#f0fdf4", borderRadius: 20, paddingHorizontal: 10, paddingVertical: 4 },
  stockBadgeLow: { backgroundColor: "#fef2f2" },
  stockText: { color: "#16a34a", fontSize: 12, fontWeight: "700" },
  stockTextLow: { color: "#ef4444" },
  priceText: { color: "#0f766e", fontWeight: "800", fontSize: 14 },
  cardActions: { gap: 12, paddingLeft: 12, borderLeftWidth: 1, borderLeftColor: "#f1f5f9" },
  actionBtn: { padding: 8, backgroundColor: "#fef2f2", borderRadius: 10 },
  modalOverlay: { flex: 1, backgroundColor: "rgba(0,0,0,0.4)", justifyContent: "flex-end" },
  modalCard: { backgroundColor: "#fff", borderTopLeftRadius: 28, borderTopRightRadius: 28, padding: 24, gap: 18, maxHeight: "90%" },
  modalHeader: { flexDirection: "row", alignItems: "center", justifyContent: "space-between" },
  modalTitle: { color: "#0f172a", fontSize: 20, fontWeight: "800" },
  fieldGroup: { gap: 6 },
  fieldLabel: { color: "#64748b", fontSize: 11, fontWeight: "700", textTransform: "uppercase", letterSpacing: 0.8 },
  fieldInput: { backgroundColor: "#f8fafc", borderRadius: 14, paddingHorizontal: 16, paddingVertical: 14, color: "#0f172a", fontSize: 15, borderWidth: 1, borderColor: "#e2e8f0" },
  row: { flexDirection: "row", gap: 12 },
  sectionDivider: { height: 1, backgroundColor: "#f1f5f9", marginVertical: 4 },
  sectionTitle: { color: "#0f172a", fontSize: 14, fontWeight: "800" },
  saveBtn: { backgroundColor: "#0f766e", borderRadius: 16, paddingVertical: 16, alignItems: "center", marginTop: 8 },
  saveBtnText: { color: "#fff", fontWeight: "800", fontSize: 16 },
});
