import { BASE_URL, getAuthToken } from "@/services/api";
import { Ionicons } from "@expo/vector-icons";
import { useEffect, useState } from "react";
import {
  ActivityIndicator,
  Alert,
  Modal,
  ScrollView,
  StyleSheet,
  Text,
  TextInput,
  TouchableOpacity,
  View,
  Platform,
} from "react-native";
import DateTimePicker from "@react-native-community/datetimepicker";
import SearchableDropdown from "@/components/searchable-dropdown";

const apiHeaders = () => ({
  "Content-Type": "application/json",
  ...(getAuthToken() ? { Authorization: `Bearer ${getAuthToken()}` } : {}),
});

const fetchPurchaseOrders = async () => {
  const res = await fetch(`${BASE_URL}/purchase-orders?size=1000`, { headers: apiHeaders() });
  const data = await res.json();
  return data?.data?.content ?? data?.data ?? data?.content ?? [];
};

const fetchSuppliers = async () => {
  const res = await fetch(`${BASE_URL}/suppliers?size=500`, { headers: apiHeaders() });
  const data = await res.json();
  return data?.data?.content ?? data?.data ?? data?.content ?? [];
};

const fetchProducts = async () => {
  const res = await fetch(`${BASE_URL}/products?status=ACTIVE&size=1000`, { headers: apiHeaders() });
  const data = await res.json();
  return data?.data?.content ?? data?.data ?? data?.content ?? [];
};

const createPO = async (payload: any) => {
  const res = await fetch(`${BASE_URL}/purchase-orders`, {
    method: "POST",
    headers: apiHeaders(),
    body: JSON.stringify(payload),
  });
  const data = await res.json();
  if (!res.ok) throw new Error(data?.message ?? "Failed to create purchase order");
  return data;
};

const deletePO = async (id: string) => {
  const res = await fetch(`${BASE_URL}/purchase-orders/${id}`, { method: "DELETE", headers: apiHeaders() });
  if (!res.ok) {
    const data = await res.json();
    throw new Error(data?.message ?? "Failed to delete purchase order");
  }
};

const markReceived = async (id: string) => {
  const res = await fetch(`${BASE_URL}/purchase-orders/${id}/receive`, { method: "PUT", headers: apiHeaders() });
  if (!res.ok) {
    const data = await res.json();
    throw new Error(data?.message ?? "Failed to mark as received");
  }
};

const formatCurrency = (val: any) => `Rs.${Number(val || 0).toLocaleString()}`;

const STATUS_COLORS: Record<string, string> = {
  PENDING: "#f59e0b",
  RECEIVED: "#0f766e",
  CANCELLED: "#ef4444",
  PARTIAL: "#7c3aed",
};

export default function PurchaseOrdersScreen() {
  const [orders, setOrders] = useState<any[]>([]);
  const [suppliers, setSuppliers] = useState<any[]>([]);
  const [products, setProducts] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState("");
  const [modalVisible, setModalVisible] = useState(false);
  const [saving, setSaving] = useState(false);
  const [selectedOrder, setSelectedOrder] = useState<any>(null);
  const [detailsVisible, setDetailsVisible] = useState(false);
  const [editId, setEditId] = useState<string | null>(null);
  const [showDatePicker, setShowDatePicker] = useState(false);
  const [form, setForm] = useState({
    supplierId: "",
    expectedDeliveryDate: "",
    note: "",
    items: [{ productId: "", quantity: 1, unitCost: 0 }],
  });

  const load = async () => {
    setLoading(true);
    try {
      const [po, sup, prod] = await Promise.all([fetchPurchaseOrders(), fetchSuppliers(), fetchProducts()]);
      setOrders(Array.isArray(po) ? po : []);
      setSuppliers(Array.isArray(sup) ? sup : []);
      setProducts(Array.isArray(prod) ? prod : []);
    } catch {
      setOrders([]);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => { load(); }, []);

  const filtered = orders.filter(
    (o) =>
      o.publicId?.toLowerCase().includes(search.toLowerCase()) ||
      o.supplier?.name?.toLowerCase().includes(search.toLowerCase())
  );

  const openCreate = () => {
    setEditId(null);
    setForm({ supplierId: "", expectedDeliveryDate: "", note: "", items: [{ productId: "", quantity: 1, unitCost: 0 }] });
    setModalVisible(true);
  };

  const openEdit = (order: any) => {
    setEditId(order.id || order._id);
    setForm({
      supplierId: order.supplier?._id || order.supplierId || "",
      expectedDeliveryDate: order.expectedDeliveryDate ? order.expectedDeliveryDate.slice(0, 10) : "",
      note: order.note || "",
      items: order.items.map((it: any) => ({
        productId: it.product?._id || it.productId || "",
        quantity: it.quantity || 1,
        unitCost: it.unitCost || 0
      }))
    });
    setModalVisible(true);
  };

  const handleSave = async () => {
    if (!form.supplierId) return Alert.alert("Error", "Select a supplier");
    if (form.items.some((i) => !i.productId || i.quantity <= 0)) return Alert.alert("Error", "Fill all item fields");

    setSaving(true);
    try {
      if (editId) {
        const res = await fetch(`${BASE_URL}/purchase-orders/${editId}`, {
          method: "PUT",
          headers: apiHeaders(),
          body: JSON.stringify(form),
        });
        if (!res.ok) throw new Error((await res.json())?.message ?? "Update failed");
      } else {
        await createPO(form);
      }
      setModalVisible(false);
      load();
    } catch (e: any) {
      Alert.alert("Error", e.message);
    } finally {
      setSaving(false);
    }
  };

  const handleMarkReceived = async () => {
    if (!selectedOrder) return;
    try {
      setSaving(true);
      await markReceived(selectedOrder.id || selectedOrder._id);
      Alert.alert("Success", "PO marked as RECEIVED and inventory updated");
      setDetailsVisible(false);
      load();
    } catch (e: any) {
      Alert.alert("Error", e.message);
    } finally {
      setSaving(false);
    }
  };

  const handleDelete = (order: any) => {
    Alert.alert("Delete Purchase Order", "Are you sure?", [
      { text: "Cancel", style: "cancel" },
      {
        text: "Delete", style: "destructive",
        onPress: async () => {
          try {
            await deletePO(order.id ?? order._id);
            load();
          } catch (e: any) { Alert.alert("Error", e.message); }
        },
      },
    ]);
  };

  const updateItem = (index: number, field: string, value: any) => {
    const next = [...form.items];
    next[index] = { ...next[index], [field]: value };
    setForm({ ...form, items: next });
  };

  return (
    <View style={styles.screen}>
      {/* Header */}
      <View style={styles.headerCard}>
        <View style={styles.headerIcon}>
          <Ionicons name="cart" size={22} color="#fff" />
        </View>
        <View style={{ flex: 1 }}>
          <Text style={styles.headerTitle}>Purchase Orders</Text>
          <Text style={styles.headerSub}>Supplier procurement records</Text>
        </View>
        <TouchableOpacity style={styles.addBtn} onPress={openCreate} activeOpacity={0.8}>
          <Ionicons name="add" size={20} color="#fff" />
          <Text style={styles.addBtnText}>New PO</Text>
        </TouchableOpacity>
      </View>

      {/* Search */}
      <View style={styles.searchRow}>
        <Ionicons name="search" size={18} color="#94a3b8" />
        <TextInput
          style={styles.searchInput}
          placeholder="Search orders..."
          placeholderTextColor="#94a3b8"
          value={search}
          onChangeText={setSearch}
        />
      </View>

      {loading ? (
        <ActivityIndicator size="large" color="#0f766e" style={{ marginTop: 40 }} />
      ) : (
        <ScrollView style={{ flex: 1 }} contentContainerStyle={styles.list}>
          {filtered.length === 0 ? (
            <View style={styles.empty}>
              <Ionicons name="cart-outline" size={48} color="#e2e8f0" />
              <Text style={styles.emptyText}>No purchase orders</Text>
            </View>
          ) : (
            filtered.map((order) => (
                <View key={order.id ?? order._id} style={styles.card}>
                  <TouchableOpacity
                    style={{ flex: 1 }}
                    activeOpacity={0.7}
                    onPress={() => { setSelectedOrder(order); setDetailsVisible(true); }}
                  >
                    <View style={styles.cardTop}>
                      <Text style={styles.orderId}>PO #{order.publicId ?? order.id}</Text>
                      <View style={[styles.statusBadge, { backgroundColor: `${STATUS_COLORS[order.status] ?? "#94a3b8"}20` }]}>
                        <Text style={[styles.statusText, { color: STATUS_COLORS[order.status] ?? "#94a3b8" }]}>
                          {order.status ?? "PENDING"}
                        </Text>
                      </View>
                    </View>
                    <Text style={styles.supplierName}>{order.supplier?.name ?? "Unknown Supplier"}</Text>
                    <View style={styles.cardMeta}>
                      <Text style={styles.metaText}>
                        {(order.items?.length ?? 0)} items • {formatCurrency(order.totalAmount)}
                      </Text>
                      {order.expectedDeliveryDate && (
                        <Text style={styles.metaDate}>Due: {order.expectedDeliveryDate?.slice(0, 10)}</Text>
                      )}
                    </View>
                  </TouchableOpacity>

                  <View style={styles.cardActions}>
                    <TouchableOpacity
                      style={styles.actionBtn}
                      onPress={() => openEdit(order)}
                    >
                      <Ionicons name="create-outline" size={18} color="#0f766e" />
                    </TouchableOpacity>
                    <TouchableOpacity
                      style={styles.actionBtn}
                      onPress={() => handleDelete(order)}
                    >
                      <Ionicons name="trash-outline" size={18} color="#ef4444" />
                    </TouchableOpacity>
                  </View>
                </View>
            ))
          )}
        </ScrollView>
      )}

      {/* Create Modal */}
      <Modal visible={modalVisible} animationType="slide" transparent onRequestClose={() => setModalVisible(false)}>
        <View style={styles.modalOverlay}>
          <View style={styles.modalCard}>
            <View style={styles.modalHeader}>
              <Text style={styles.modalTitle}>New Purchase Order</Text>
              <TouchableOpacity onPress={() => setModalVisible(false)}>
                <Ionicons name="close" size={22} color="#64748b" />
              </TouchableOpacity>
            </View>

            <ScrollView contentContainerStyle={{ gap: 14 }} showsVerticalScrollIndicator={false}>
              <View style={styles.fieldGroup}>
                <Text style={styles.fieldLabel}>Supplier *</Text>
                <ScrollView horizontal showsHorizontalScrollIndicator={false} style={{ marginTop: 6 }}>
                  {suppliers.map((s) => (
                    <TouchableOpacity
                      key={s.id ?? s._id}
                      style={[styles.supplierChip, form.supplierId === (s.id ?? s._id) && styles.supplierChipActive]}
                      onPress={() => setForm({ ...form, supplierId: s.id ?? s._id })}
                    >
                      <Text style={[styles.supplierChipText, form.supplierId === (s.id ?? s._id) && { color: "#fff" }]}>
                        {s.name}
                      </Text>
                    </TouchableOpacity>
                  ))}
                </ScrollView>
              </View>

              <View style={styles.fieldGroup}>
                <Text style={styles.fieldLabel}>Expected Delivery Date</Text>
                <TouchableOpacity 
                   style={styles.fieldInput} 
                   onPress={() => setShowDatePicker(true)}
                   activeOpacity={0.7}
                >
                  <Text style={{ color: form.expectedDeliveryDate ? "#0f172a" : "#94a3b8" }}>
                    {form.expectedDeliveryDate || "Select Date"}
                  </Text>
                </TouchableOpacity>
                {showDatePicker && (
                  <DateTimePicker
                    value={form.expectedDeliveryDate ? new Date(form.expectedDeliveryDate) : new Date()}
                    mode="date"
                    display={Platform.OS === 'ios' ? 'spinner' : 'default'}
                    onChange={(event, selectedDate) => {
                      setShowDatePicker(false);
                      if (selectedDate) {
                        setForm({ ...form, expectedDeliveryDate: selectedDate.toISOString().split('T')[0] });
                      }
                    }}
                  />
                )}
              </View>

              <View style={styles.fieldGroup}>
                <View style={styles.itemsHeader}>
                  <Text style={styles.fieldLabel}>Order Items</Text>
                  <TouchableOpacity
                    style={styles.addItemBtn}
                    onPress={() => setForm({ ...form, items: [...form.items, { productId: "", quantity: 1, unitCost: 0 }] })}
                  >
                    <Ionicons name="add" size={14} color="#0f766e" />
                    <Text style={styles.addItemText}>Add Item</Text>
                  </TouchableOpacity>
                </View>
                {form.items.map((item, idx) => (
                  <View key={idx} style={styles.itemRow}>
                    <View style={styles.productPickerWrap}>
                      <Text style={styles.itemLabel}>Product</Text>
                      <ScrollView horizontal showsHorizontalScrollIndicator={false}>
                        {products.slice(0, 20).map((p) => (
                          <TouchableOpacity
                            key={p.id ?? p._id}
                            style={[styles.productChip, item.productId === (p.id ?? p._id) && styles.productChipActive]}
                            onPress={() => updateItem(idx, "productId", p.id ?? p._id)}
                          >
                            <Text style={[styles.productChipText, item.productId === (p.id ?? p._id) && { color: "#fff" }]}>
                              {p.name}
                            </Text>
                          </TouchableOpacity>
                        ))}
                      </ScrollView>
                    </View>
                    <View style={styles.itemNumRow}>
                      <View style={{ flex: 1 }}>
                        <Text style={styles.itemLabel}>Qty</Text>
                        <TextInput
                          style={styles.itemInput}
                          value={String(item.quantity)}
                          onChangeText={(v) => updateItem(idx, "quantity", Number(v) || 1)}
                          keyboardType="numeric"
                        />
                      </View>
                      <View style={{ flex: 1 }}>
                        <Text style={styles.itemLabel}>Unit Cost</Text>
                        <TextInput
                          style={styles.itemInput}
                          value={String(item.unitCost)}
                          onChangeText={(v) => updateItem(idx, "unitCost", Number(v) || 0)}
                          keyboardType="numeric"
                        />
                      </View>
                      {form.items.length > 1 && (
                        <TouchableOpacity
                          style={styles.removeItemBtn}
                          onPress={() => setForm({ ...form, items: form.items.filter((_, i) => i !== idx) })}
                        >
                          <Ionicons name="close" size={16} color="#ef4444" />
                        </TouchableOpacity>
                      )}
                    </View>
                  </View>
                ))}
              </View>

              <View style={styles.fieldGroup}>
                <Text style={styles.fieldLabel}>Notes</Text>
                <TextInput
                  style={[styles.fieldInput, { minHeight: 80 }]}
                  value={form.note}
                  onChangeText={(v) => setForm({ ...form, note: v })}
                  multiline
                  placeholder="Optional notes..."
                  placeholderTextColor="#94a3b8"
                />
              </View>
            </ScrollView>

            <TouchableOpacity style={styles.saveBtn} onPress={handleSave} disabled={saving} activeOpacity={0.85}>
              {saving ? <ActivityIndicator color="#fff" /> : <Text style={styles.saveBtnText}>Create Purchase Order</Text>}
            </TouchableOpacity>
          </View>
        </View>
      </Modal>

      {/* Details Modal */}
      <Modal visible={detailsVisible} animationType="slide" transparent onRequestClose={() => setDetailsVisible(false)}>
        <View style={styles.modalOverlay}>
          <View style={styles.modalCard}>
            <View style={styles.modalHeader}>
              <View>
                <Text style={styles.modalTitle}>PO #{selectedOrder?.publicId}</Text>
                <Text style={styles.modalSub}>{selectedOrder?.supplier?.name}</Text>
              </View>
              <TouchableOpacity onPress={() => setDetailsVisible(false)}>
                <Ionicons name="close" size={22} color="#64748b" />
              </TouchableOpacity>
            </View>
            <ScrollView contentContainerStyle={{ gap: 10 }}>
              {(selectedOrder?.items ?? []).map((item: any, i: number) => (
                <View key={i} style={styles.detailItem}>
                  <Text style={styles.detailItemName}>{item.product?.name ?? `Item ${i + 1}`}</Text>
                  <View style={styles.detailItemMeta}>
                    <Text style={styles.detailItemSub}>Qty: {item.quantity}</Text>
                    <Text style={styles.detailItemSub}>Cost: {formatCurrency(item.unitCost)}</Text>
                    <Text style={styles.detailItemTotal}>{formatCurrency(item.lineTotal ?? item.quantity * item.unitCost)}</Text>
                  </View>
                </View>
              ))}
              <View style={styles.detailTotal}>
                <Text style={styles.detailTotalLabel}>Total</Text>
                <Text style={styles.detailTotalValue}>{formatCurrency(selectedOrder?.totalAmount)}</Text>
              </View>

              {selectedOrder?.status !== 'RECEIVED' && (
                <TouchableOpacity style={styles.receiveBtn} onPress={handleMarkReceived} disabled={saving}>
                  <Ionicons name="checkmark-done" size={20} color="#fff" />
                  <Text style={styles.receiveBtnText}>Mark as Received</Text>
                </TouchableOpacity>
              )}
            </ScrollView>
          </View>
        </View>
      </Modal>
    </View>
  );
}

const styles = StyleSheet.create({
  screen: { flex: 1, backgroundColor: "#f4f7fb" },
  headerCard: {
    backgroundColor: "#0f172a", margin: 16, borderRadius: 20,
    padding: 18, flexDirection: "row", alignItems: "center", gap: 14,
  },
  headerIcon: { width: 44, height: 44, borderRadius: 14, backgroundColor: "#b45309", alignItems: "center", justifyContent: "center" },
  headerTitle: { color: "#fff", fontSize: 16, fontWeight: "800" },
  headerSub: { color: "#94a3b8", fontSize: 12, marginTop: 2 },
  addBtn: { flexDirection: "row", alignItems: "center", gap: 6, backgroundColor: "#0f766e", borderRadius: 12, paddingHorizontal: 14, paddingVertical: 10 },
  addBtnText: { color: "#fff", fontWeight: "700", fontSize: 13 },
  searchRow: {
    flexDirection: "row", alignItems: "center", gap: 10,
    backgroundColor: "#fff", borderRadius: 14, marginHorizontal: 16, marginBottom: 12,
    paddingHorizontal: 14, paddingVertical: 12,
    shadowColor: "#0f172a", shadowOpacity: 0.04, shadowRadius: 8, elevation: 2,
  },
  searchInput: { flex: 1, color: "#0f172a", fontSize: 14 },
  list: { padding: 16, paddingTop: 4, gap: 10 },
  empty: { alignItems: "center", paddingTop: 60, gap: 12 },
  emptyText: { color: "#94a3b8", fontSize: 14, fontWeight: "600" },
  card: {
    backgroundColor: "#fff", borderRadius: 18, padding: 16,
    shadowColor: "#0f172a", shadowOpacity: 0.04, shadowRadius: 8, elevation: 2, gap: 8,
    flexDirection: "row", alignItems: "center"
  },
  cardTop: { flexDirection: "row", alignItems: "center", justifyContent: "space-between" },
  orderId: { color: "#0f172a", fontWeight: "800", fontSize: 15 },
  statusBadge: { borderRadius: 999, paddingHorizontal: 10, paddingVertical: 4 },
  statusText: { fontSize: 10, fontWeight: "800" },
  supplierName: { color: "#64748b", fontSize: 13, fontWeight: "600" },
  cardMeta: { flexDirection: "row", justifyContent: "space-between" },
  metaText: { color: "#94a3b8", fontSize: 12 },
  metaDate: { color: "#f59e0b", fontSize: 12, fontWeight: "700" },
  cardActions: { flexDirection: "column", gap: 10, paddingLeft: 12, borderLeftWidth: 1, borderLeftColor: "#f1f5f9" },
  actionBtn: { padding: 6, backgroundColor: "#f8fafc", borderRadius: 8, elevation: 1 },
  modalOverlay: { flex: 1, backgroundColor: "rgba(0,0,0,0.4)", justifyContent: "flex-end" },
  modalCard: { backgroundColor: "#fff", borderTopLeftRadius: 28, borderTopRightRadius: 28, padding: 24, gap: 20, maxHeight: "92%" },
  modalHeader: { flexDirection: "row", alignItems: "flex-start", justifyContent: "space-between" },
  modalTitle: { color: "#0f172a", fontSize: 20, fontWeight: "800" },
  modalSub: { color: "#64748b", fontSize: 13, marginTop: 2 },
  fieldGroup: { gap: 6 },
  fieldLabel: { color: "#64748b", fontSize: 11, fontWeight: "700", textTransform: "uppercase", letterSpacing: 0.8 },
  fieldInput: { backgroundColor: "#f8fafc", borderRadius: 14, paddingHorizontal: 16, paddingVertical: 14, color: "#0f172a", fontSize: 15, borderWidth: 1, borderColor: "#e2e8f0" },
  itemsHeader: { flexDirection: "row", alignItems: "center", justifyContent: "space-between" },
  addItemBtn: { flexDirection: "row", alignItems: "center", gap: 4, backgroundColor: "#f0fdfa", borderRadius: 8, paddingHorizontal: 10, paddingVertical: 6 },
  addItemText: { color: "#0f766e", fontSize: 12, fontWeight: "700" },
  itemRow: { borderWidth: 1, borderColor: "#e2e8f0", borderRadius: 14, padding: 12, gap: 10 },
  productPickerWrap: { gap: 4 },
  itemLabel: { color: "#94a3b8", fontSize: 10, fontWeight: "700", textTransform: "uppercase" },
  productChip: { backgroundColor: "#f8fafc", borderRadius: 8, paddingHorizontal: 12, paddingVertical: 8, marginRight: 8 },
  productChipActive: { backgroundColor: "#0f766e" },
  productChipText: { fontSize: 12, fontWeight: "700", color: "#64748b" },
  itemNumRow: { flexDirection: "row", gap: 10, alignItems: "flex-end" },
  itemInput: { backgroundColor: "#f8fafc", borderRadius: 10, paddingHorizontal: 12, paddingVertical: 10, color: "#0f172a", borderWidth: 1, borderColor: "#e2e8f0", fontSize: 14 },
  removeItemBtn: { padding: 4 },
  supplierChip: { backgroundColor: "#f8fafc", borderRadius: 10, paddingHorizontal: 14, paddingVertical: 8, marginRight: 8 },
  supplierChipActive: { backgroundColor: "#0f766e" },
  supplierChipText: { fontSize: 13, fontWeight: "700", color: "#64748b" },
  saveBtn: { backgroundColor: "#0f766e", borderRadius: 16, paddingVertical: 16, alignItems: "center", marginTop: 8 },
  saveBtnText: { color: "#fff", fontWeight: "800", fontSize: 16 },
  detailItem: { backgroundColor: "#f8fafc", borderRadius: 12, padding: 14, gap: 6 },
  detailItemName: { color: "#0f172a", fontWeight: "700", fontSize: 14 },
  detailItemMeta: { flexDirection: "row", gap: 16, alignItems: "center" },
  detailItemSub: { color: "#64748b", fontSize: 12 },
  detailItemTotal: { color: "#0f766e", fontWeight: "800", fontSize: 14, marginLeft: "auto" },
  detailTotal: { flexDirection: "row", justifyContent: "space-between", alignItems: "center", paddingTop: 12, borderTopWidth: 1, borderTopColor: "#e2e8f0" },
  detailTotalLabel: { color: "#64748b", fontWeight: "700", fontSize: 14 },
  detailTotalValue: { color: "#0f172a", fontWeight: "900", fontSize: 18 },
  receiveBtn: { backgroundColor: "#0f766e", borderRadius: 16, paddingVertical: 14, flexDirection: "row", alignItems: "center", justifyContent: "center", gap: 8, marginTop: 10 },
  receiveBtnText: { color: "#fff", fontWeight: "800", fontSize: 15 },
});
