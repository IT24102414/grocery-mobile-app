import { useMemo, useState } from 'react';
import { Pressable, ScrollView, StyleSheet, TextInput, View } from 'react-native';

import { ThemedText } from '@/components/themed-text';

type CustomerType = 'Credit Account' | 'Cash Account';
type PaymentTerm = '7 Days' | '15 Days' | '30 Days' | '60 Days';
type CustomerStatus = 'Active' | 'Inactive';

type Customer = {
  id: number;
  fullName: string;
  phoneNumber: string;
  address: string;
  creditLimit: string;
  paymentTerms: PaymentTerm;
  customerType: CustomerType;
  status: CustomerStatus;
  outstanding: number;
};

const customerTypes: CustomerType[] = ['Credit Account', 'Cash Account'];
const paymentTerms: PaymentTerm[] = ['7 Days', '15 Days', '30 Days', '60 Days'];

const initialFormState = {
  fullName: '',
  phoneNumber: '',
  address: '',
  creditLimit: '',
  paymentTerms: '30 Days' as PaymentTerm,
  customerType: 'Credit Account' as CustomerType,
  status: 'Active' as CustomerStatus,
};

const filterOptions: CustomerStatus[] = ['Active', 'Inactive'];

export default function CustomersScreen() {
  const [customers, setCustomers] = useState<Customer[]>([]);
  const [editingId, setEditingId] = useState<number | null>(null);
  const [selectedCustomerId, setSelectedCustomerId] = useState<number | null>(null);
  const [form, setForm] = useState(initialFormState);
  const [errors, setErrors] = useState<Record<string, string>>({});
  const [filterStatus, setFilterStatus] = useState<'All' | CustomerStatus>('Active');

  const isFormValid = () => {
    const validationErrors: Record<string, string> = {};
    const trimmedName = form.fullName.trim();
    const trimmedPhone = form.phoneNumber.trim();
    const trimmedAddress = form.address.trim();
    const trimmedCreditLimit = form.creditLimit.trim();

    if (!trimmedName) {
      validationErrors.fullName = 'Full name is required.';
    } else if (!/^[A-Za-z ]+$/.test(trimmedName)) {
      validationErrors.fullName = 'Full name should contain letters only.';
    }

    if (!trimmedPhone) {
      validationErrors.phoneNumber = 'Phone number is required.';
    } else if (!/^\d{10}$/.test(trimmedPhone)) {
      validationErrors.phoneNumber = 'Phone number must be exactly 10 digits.';
    }

    if (!trimmedAddress) {
      validationErrors.address = 'Address is required.';
    }

    if (!trimmedCreditLimit) {
      validationErrors.creditLimit = 'Credit limit is required.';
    } else if (Number(trimmedCreditLimit) <= 0 || Number.isNaN(Number(trimmedCreditLimit))) {
      validationErrors.creditLimit = 'Credit limit must be a positive number.';
    }

    setErrors(validationErrors);
    return Object.keys(validationErrors).length === 0;
  };

  const resetForm = () => {
    setForm(initialFormState);
    setEditingId(null);
    setErrors({});
  };

  const handleSave = () => {
    if (!isFormValid()) {
      return;
    }

    if (editingId !== null) {
      setCustomers((prev) =>
        prev.map((customer) =>
          customer.id === editingId
            ? {
                ...customer,
                fullName: form.fullName.trim(),
                phoneNumber: form.phoneNumber.trim(),
                address: form.address.trim(),
                creditLimit: form.creditLimit.trim(),
                paymentTerms: form.paymentTerms,
                customerType: form.customerType,
                status: form.status,
              }
            : customer,
        ),
      );
    } else {
      setCustomers((prev) => [
        ...prev,
        {
          id: Date.now(),
          fullName: form.fullName.trim(),
          phoneNumber: form.phoneNumber.trim(),
          address: form.address.trim(),
          creditLimit: form.creditLimit.trim(),
          paymentTerms: form.paymentTerms,
          customerType: form.customerType,
          status: form.status,
          outstanding: 0,
        },
      ]);
    }

    resetForm();
  };

  const handleEdit = (customer: Customer) => {
    setSelectedCustomerId(null);
    setEditingId(customer.id);
    setForm({
      fullName: customer.fullName,
      phoneNumber: customer.phoneNumber,
      address: customer.address,
      creditLimit: customer.creditLimit,
      paymentTerms: customer.paymentTerms,
      customerType: customer.customerType,
      status: customer.status,
    });
    setErrors({});
  };

  const handleDelete = (id: number) => {
    setCustomers((prev) => prev.filter((customer) => customer.id !== id));
    if (editingId === id) {
      resetForm();
    }
    if (selectedCustomerId === id) {
      setSelectedCustomerId(null);
    }
  };

  const handleView = (id: number) => {
    setSelectedCustomerId(id);
  };

  const submitButtonLabel = editingId !== null ? 'Update Customer' : 'Add Customer';

  const totalCreditLimit = useMemo(
    () => customers.reduce((sum, customer) => sum + Number(customer.creditLimit), 0),
    [customers],
  );
  const totalOutstanding = useMemo(
    () => customers.reduce((sum, customer) => sum + customer.outstanding, 0),
    [customers],
  );
  const availableCredit = totalCreditLimit - totalOutstanding;

  const filteredCustomers = useMemo(() => {
    if (filterStatus === 'All') {
      return customers;
    }
    return customers.filter((customer) => customer.status === filterStatus);
  }, [customers, filterStatus]);

  const hasCustomers = filteredCustomers.length > 0;
  const customerCountText = useMemo(
    () => `${filteredCustomers.length} customer${filteredCustomers.length === 1 ? '' : 's'} shown`,
    [filteredCustomers.length],
  );

  return (
    <ScrollView contentContainerStyle={styles.container}>
      <ThemedText type="title" style={styles.title}>
        Credit Customers
      </ThemedText>
      <ThemedText type="subtitle" style={styles.subtitle}>
        Manage credit accounts and outstanding balances
      </ThemedText>

      <View style={styles.summaryGrid}>
        <View style={styles.summaryCard}>
          <ThemedText type="defaultSemiBold">Total Outstanding</ThemedText>
          <ThemedText type="title">Rs.{totalOutstanding.toFixed(0)}</ThemedText>
          <ThemedText type="default">Real-time dynamic data</ThemedText>
        </View>
        <View style={styles.summaryCard}>
          <ThemedText type="defaultSemiBold">Total Credit Limit</ThemedText>
          <ThemedText type="title">Rs.{totalCreditLimit.toFixed(0)}</ThemedText>
          <ThemedText type="default">Real-time dynamic data</ThemedText>
        </View>
        <View style={styles.summaryCard}>
          <ThemedText type="defaultSemiBold">Available Credit</ThemedText>
          <ThemedText type="title">Rs.{availableCredit.toFixed(0)}</ThemedText>
          <ThemedText type="default">Real-time dynamic data</ThemedText>
        </View>
      </View>

      <View style={styles.filterRow}>
        <View style={styles.filterButtons}>
          <Pressable
            style={[styles.filterButton, filterStatus === 'Active' && styles.filterButtonActive]}
            onPress={() => setFilterStatus('Active')}>
            <ThemedText style={filterStatus === 'Active' ? styles.filterTextActive : styles.filterText}>Active</ThemedText>
          </Pressable>
          <Pressable
            style={[styles.filterButton, filterStatus === 'Inactive' && styles.filterButtonActive]}
            onPress={() => setFilterStatus('Inactive')}>
            <ThemedText style={filterStatus === 'Inactive' ? styles.filterTextActive : styles.filterText}>Inactive</ThemedText>
          </Pressable>
          <Pressable
            style={[styles.filterButton, filterStatus === 'All' && styles.filterButtonActive]}
            onPress={() => setFilterStatus('All')}>
            <ThemedText style={filterStatus === 'All' ? styles.filterTextActive : styles.filterText}>All</ThemedText>
          </Pressable>
        </View>
      </View>

      <ThemedText type="subtitle" style={styles.sectionTitle}>{customerCountText}</ThemedText>

      {selectedCustomerId !== null ? (
        (() => {
          const selected = customers.find((customer) => customer.id === selectedCustomerId);
          if (!selected) {
            return <ThemedText>No customer selected.</ThemedText>;
          }
          return (
            <View style={styles.viewCard}>
              <ThemedText type="defaultSemiBold">Viewing Customer Details</ThemedText>
              <ThemedText>Name: {selected.fullName}</ThemedText>
              <ThemedText>Phone: {selected.phoneNumber}</ThemedText>
              <ThemedText>Address: {selected.address}</ThemedText>
              <ThemedText>Credit Limit: Rs. {selected.creditLimit}</ThemedText>
              <ThemedText>Outstanding: Rs. {selected.outstanding.toFixed(0)}</ThemedText>
              <ThemedText>Available: Rs. {(Number(selected.creditLimit) - selected.outstanding).toFixed(0)}</ThemedText>
              <ThemedText>Payment Terms: {selected.paymentTerms}</ThemedText>
              <ThemedText>Customer Type: {selected.customerType}</ThemedText>
              <ThemedText>Status: {selected.status}</ThemedText>
              <Pressable style={styles.closeViewButton} onPress={() => setSelectedCustomerId(null)}>
                <ThemedText style={styles.closeViewText}>Close</ThemedText>
              </Pressable>
            </View>
          );
        })()
      ) : null}

      {hasCustomers ? (
        filteredCustomers.map((customer) => (
          <View key={customer.id} style={styles.card}>
            <View style={styles.cardHeader}>
              <ThemedText type="defaultSemiBold">{customer.fullName}</ThemedText>
              <View style={styles.tag}>
                <ThemedText style={styles.tagText}>{customer.status}</ThemedText>
              </View>
            </View>
            <ThemedText>Phone: {customer.phoneNumber}</ThemedText>
            <ThemedText>Address: {customer.address}</ThemedText>
            <ThemedText>Credit Limit: Rs. {customer.creditLimit}</ThemedText>
            <ThemedText>Payment Terms: {customer.paymentTerms}</ThemedText>
            <View style={styles.cardActions}>
              <Pressable style={styles.actionButton} onPress={() => handleView(customer.id)}>
                <ThemedText style={styles.actionText}>View</ThemedText>
              </Pressable>
              <Pressable style={styles.actionButton} onPress={() => handleEdit(customer)}>
                <ThemedText style={styles.actionText}>Edit</ThemedText>
              </Pressable>
              <Pressable style={[styles.actionButton, styles.deleteButton]} onPress={() => handleDelete(customer.id)}>
                <ThemedText style={[styles.actionText, styles.deleteText]}>Delete</ThemedText>
              </Pressable>
            </View>
          </View>
        ))
      ) : (
        <ThemedText>No customers match the selected filter.</ThemedText>
      )}

      <ThemedText type="subtitle" style={styles.sectionTitle}>
        {editingId !== null ? 'Edit Customer' : 'Add Customer'}
      </ThemedText>

      <View style={styles.formGroup}>
        <ThemedText>Full Name</ThemedText>
        <TextInput
          style={[styles.input, errors.fullName && styles.inputError]}
          placeholder="Enter full name"
          value={form.fullName}
          onChangeText={(text) => setForm((prev) => ({ ...prev, fullName: text }))}
          autoCapitalize="words"
        />
        {errors.fullName ? <ThemedText type="default" style={styles.errorText}>{errors.fullName}</ThemedText> : null}
      </View>

      <View style={styles.formGroup}>
        <ThemedText>Phone Number</ThemedText>
        <TextInput
          style={[styles.input, errors.phoneNumber && styles.inputError]}
          placeholder="10 digit phone number"
          keyboardType="number-pad"
          maxLength={10}
          value={form.phoneNumber}
          onChangeText={(text) => setForm((prev) => ({ ...prev, phoneNumber: text.replace(/[^0-9]/g, '') }))}
        />
        {errors.phoneNumber ? <ThemedText type="default" style={styles.errorText}>{errors.phoneNumber}</ThemedText> : null}
      </View>

      <View style={styles.formGroup}>
        <ThemedText>Address</ThemedText>
        <TextInput
          style={[styles.input, styles.textArea, errors.address && styles.inputError]}
          placeholder="Enter address"
          value={form.address}
          onChangeText={(text) => setForm((prev) => ({ ...prev, address: text }))}
          multiline
          numberOfLines={3}
        />
        {errors.address ? <ThemedText type="default" style={styles.errorText}>{errors.address}</ThemedText> : null}
      </View>

      <View style={styles.rowGroup}>
        <View style={styles.flexField}>
          <ThemedText>Credit Limit (Rs.)</ThemedText>
          <TextInput
            style={[styles.input, errors.creditLimit && styles.inputError]}
            placeholder="0"
            keyboardType="numeric"
            value={form.creditLimit}
            onChangeText={(text) => setForm((prev) => ({ ...prev, creditLimit: text.replace(/[^0-9.]/g, '') }))}
          />
          {errors.creditLimit ? <ThemedText type="default" style={styles.errorText}>{errors.creditLimit}</ThemedText> : null}
        </View>

        <View style={styles.flexField}>
          <ThemedText>Payment Terms</ThemedText>
          <View style={styles.pickerGroup}>
            {paymentTerms.map((term) => (
              <Pressable
                key={term}
                style={[styles.optionButton, form.paymentTerms === term && styles.optionButtonActive]}
                onPress={() => setForm((prev) => ({ ...prev, paymentTerms: term }))}>
                <ThemedText style={form.paymentTerms === term ? styles.optionTextActive : styles.optionText}>{term}</ThemedText>
              </Pressable>
            ))}
          </View>
        </View>
      </View>

      <View style={styles.formGroup}>
        <ThemedText>Customer Type</ThemedText>
        <View style={styles.pickerGroup}>            
          {customerTypes.map((type) => (
            <Pressable
              key={type}
              style={[styles.optionButton, form.customerType === type && styles.optionButtonActive]}
              onPress={() => setForm((prev) => ({ ...prev, customerType: type }))}>
              <ThemedText style={form.customerType === type ? styles.optionTextActive : styles.optionText}>{type}</ThemedText>
            </Pressable>
          ))}
        </View>
      </View>

      <View style={styles.formGroup}>
        <ThemedText>Status</ThemedText>
        <View style={styles.pickerGroup}>
          {filterOptions.map((status) => (
            <Pressable
              key={status}
              style={[styles.optionButton, form.status === status && styles.optionButtonActive]}
              onPress={() => setForm((prev) => ({ ...prev, status }))}>
              <ThemedText style={form.status === status ? styles.optionTextActive : styles.optionText}>{status}</ThemedText>
            </Pressable>
          ))}
        </View>
      </View>

      <View style={styles.buttonRow}>
        <Pressable style={styles.primaryButton} onPress={handleSave}>
          <ThemedText style={styles.primaryButtonText}>{submitButtonLabel}</ThemedText>
        </Pressable>
        <Pressable style={styles.secondaryButton} onPress={resetForm}>
          <ThemedText style={styles.secondaryButtonText}>Clear</ThemedText>
        </Pressable>
      </View>
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: {
    padding: 16,
    gap: 16,
  },
  title: {
    marginBottom: 4,
  },
  sectionTitle: {
    marginTop: 16,
  },
  formGroup: {
    gap: 8,
  },
  input: {
    borderWidth: 1,
    borderColor: '#C7C7CC',
    borderRadius: 10,
    padding: 12,
    backgroundColor: '#fff',
  },
  textArea: {
    minHeight: 80,
    textAlignVertical: 'top',
  },
  inputError: {
    borderColor: '#D32F2F',
  },
  errorText: {
    color: '#D32F2F',
    marginTop: 4,
  },
  rowGroup: {
    flexDirection: 'row',
    gap: 12,
  },
  flexField: {
    flex: 1,
    gap: 8,
  },
  pickerGroup: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    gap: 8,
    marginTop: 8,
  },
  optionButton: {
    borderWidth: 1,
    borderColor: '#C7C7CC',
    borderRadius: 10,
    paddingVertical: 10,
    paddingHorizontal: 14,
    backgroundColor: '#F5F5F7',
  },
  optionButtonActive: {
    borderColor: '#34C759',
    backgroundColor: '#E6F4EA',
  },
  optionText: {
    color: '#1C1C1E',
  },
  optionTextActive: {
    color: '#0B6623',
    fontWeight: '600',
  },
  buttonRow: {
    flexDirection: 'row',
    gap: 12,
  },
  primaryButton: {
    flex: 1,
    backgroundColor: '#34C759',
    paddingVertical: 14,
    borderRadius: 10,
    alignItems: 'center',
  },
  primaryButtonText: {
    color: '#fff',
    fontWeight: '700',
  },
  secondaryButton: {
    flex: 1,
    borderWidth: 1,
    borderColor: '#C7C7CC',
    paddingVertical: 14,
    borderRadius: 10,
    alignItems: 'center',
  },
  secondaryButtonText: {
    color: '#1C1C1E',
    fontWeight: '700',
  },
  card: {
    padding: 16,
    borderWidth: 1,
    borderColor: '#E5E5EA',
    borderRadius: 14,
    backgroundColor: '#FFFFFF',
    gap: 8,
  },
  cardHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
  },
  tag: {
    backgroundColor: '#EFF7FF',
    borderRadius: 12,
    paddingHorizontal: 10,
    paddingVertical: 4,
  },
  tagText: {
    color: '#007AFF',
    fontSize: 12,
  },
  cardActions: {
    flexDirection: 'row',
    gap: 12,
    marginTop: 8,
  },
  actionButton: {
    flex: 1,
    borderWidth: 1,
    borderColor: '#C7C7CC',
    borderRadius: 10,
    paddingVertical: 10,
    alignItems: 'center',
  },
  deleteButton: {
    borderColor: '#D32F2F',
  },
  actionText: {
    color: '#1C1C1E',
    fontWeight: '600',
  },
  deleteText: {
    color: '#D32F2F',
  },
  subtitle: {
    color: '#6B7280',
    marginBottom: 12,
  },
  summaryGrid: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    gap: 12,
    justifyContent: 'space-between',
  },
  summaryCard: {
    flex: 1,
    minWidth: '30%',
    borderWidth: 1,
    borderColor: '#E5E5EA',
    borderRadius: 16,
    padding: 16,
    backgroundColor: '#FFFFFF',
    gap: 8,
  },
  filterRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
  },
  filterButtons: {
    flexDirection: 'row',
    gap: 10,
  },
  filterButton: {
    borderWidth: 1,
    borderColor: '#C7C7CC',
    borderRadius: 999,
    paddingVertical: 10,
    paddingHorizontal: 16,
    backgroundColor: '#F5F5F7',
  },
  filterButtonActive: {
    borderColor: '#34C759',
    backgroundColor: '#E6F4EA',
  },
  filterText: {
    color: '#1C1C1E',
  },
  filterTextActive: {
    color: '#0B6623',
    fontWeight: '700',
  },
  viewCard: {
    padding: 16,
    borderWidth: 1,
    borderColor: '#E5E5EA',
    borderRadius: 14,
    backgroundColor: '#F8FBFF',
    gap: 8,
  },
  closeViewButton: {
    marginTop: 10,
    alignSelf: 'flex-start',
    borderWidth: 1,
    borderColor: '#C7C7CC',
    borderRadius: 10,
    paddingVertical: 10,
    paddingHorizontal: 14,
    backgroundColor: '#FFFFFF',
  },
  closeViewText: {
    color: '#1C1C1E',
    fontWeight: '700',
  },
});
