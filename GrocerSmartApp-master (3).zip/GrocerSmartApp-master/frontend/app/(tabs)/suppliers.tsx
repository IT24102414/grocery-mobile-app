import { BASE_URL, getAuthToken } from "@/services/api";
import { Ionicons } from "@expo/vector-icons";
import { useEffect, useState } from "react";
import {
  ActivityIndicator,
  Alert,
  Modal,
  ScrollView,
  StyleSheet,
  Text,
  TextInput,
  TouchableOpacity,
  View,
} from "react-native";
import SearchableDropdown from "@/components/searchable-dropdown";

const apiHeaders = () => ({
  "Content-Type": "application/json",
  ...(getAuthToken() ? { Authorization: `Bearer ${getAuthToken()}` } : {}),
});

const fetchSuppliers = async (params: any = {}) => {
  const q = new URLSearchParams(Object.entries(params).filter(([, v]) => v != null).map(([k, v]) => [k, String(v)]));
  const res = await fetch(`${BASE_URL}/suppliers?${q.toString()}`, { headers: apiHeaders() });
  const data = await res.json();
  return data?.data?.content ?? data?.data ?? data?.content ?? [];
};

const saveSupplier = async (payload: any, id?: string) => {
  const res = await fetch(`${BASE_URL}/suppliers${id ? `/${id}` : ""}`, {
    method: id ? "PUT" : "POST",
    headers: apiHeaders(),
    body: JSON.stringify(payload),
  });
  const data = await res.json();
  if (!res.ok) throw new Error(data?.message ?? "Failed to save supplier");
  return data;
};

const deleteSupplier = async (id: string) => {
  const res = await fetch(`${BASE_URL}/suppliers/${id}`, { method: "DELETE", headers: apiHeaders() });
  if (!res.ok) {
    const data = await res.json();
    throw new Error(data?.message ?? "Failed to delete supplier");
  }
};

export default function SuppliersScreen() {
  const [suppliers, setSuppliers] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState("");
  const [modalVisible, setModalVisible] = useState(false);
  const [saving, setSaving] = useState(false);
  const [editId, setEditId] = useState<string | null>(null);
  const [form, setForm] = useState({
    name: "",
    contactPerson: "",
    email: "",
    phone: "",
    address: "",
    status: "ACTIVE",
    supplyCategories: "",
    outstandingPayable: "0"
  });

  const load = async () => {
    setLoading(true);
    try {
      const data = await fetchSuppliers({ size: 1000 });
      setSuppliers(Array.isArray(data) ? data : []);
    } catch {
      setSuppliers([]);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => { load(); }, []);

  const filtered = suppliers.filter(
    (s) =>
      s.name?.toLowerCase().includes(search.toLowerCase()) ||
      s.contactPerson?.toLowerCase().includes(search.toLowerCase()) ||
      s.phone?.toLowerCase().includes(search.toLowerCase())
  );

  const openCreate = () => {
    setEditId(null);
    setForm({ name: "", contactPerson: "", email: "", phone: "", address: "", status: "ACTIVE", supplyCategories: "", outstandingPayable: "0" });
    setModalVisible(true);
  };

  const openEdit = (supplier: any) => {
    setEditId(supplier.id ?? supplier._id);
    setForm({
      name: supplier.name || "",
      contactPerson: supplier.contactPerson || "",
      email: supplier.email || "",
      phone: supplier.phone || "",
      address: supplier.address || "",
      status: supplier.status || "ACTIVE",
      supplyCategories: Array.isArray(supplier.supplyCategories) ? supplier.supplyCategories.join(", ") : supplier.supplyCategories || "",
      outstandingPayable: String(supplier.outstandingPayable || "0")
    });
    setModalVisible(true);
  };

  const handleSave = async () => {
    if (!form.name || !form.phone) return Alert.alert("Error", "Name and Phone are required");
    setSaving(true);
    try {
      const payload = {
        ...form,
        supplyCategories: form.supplyCategories.split(",").map(s => s.trim()).filter(Boolean),
        outstandingPayable: Number(form.outstandingPayable || 0)
      };
      await saveSupplier(payload, editId || undefined);
      setModalVisible(false);
      load();
    } catch (e: any) {
      Alert.alert("Error", e.message);
    } finally {
      setSaving(false);
    }
  };

  const handleDelete = (supplier: any) => {
    Alert.alert("Archive Supplier", `Are you sure you want to archive "${supplier.name}"?`, [
      { text: "Cancel", style: "cancel" },
      { text: "Archive", style: "destructive", onPress: async () => {
          try {
            await deleteSupplier(supplier.id ?? supplier._id);
            load();
          } catch (e: any) { Alert.alert("Error", e.message); }
        }
      },
    ]);
  };

  return (
    <View style={styles.screen}>
      {/* Header */}
      <View style={styles.headerCard}>
        <View style={styles.headerIcon}>
          <Ionicons name="briefcase" size={22} color="#fff" />
        </View>
        <View style={{ flex: 1 }}>
          <Text style={styles.headerTitle}>Suppliers Registry</Text>
          <Text style={styles.headerSub}>Procurement and vendor management</Text>
        </View>
        <TouchableOpacity style={styles.addBtn} onPress={openCreate} activeOpacity={0.8}>
          <Ionicons name="add" size={20} color="#fff" />
          <Text style={styles.addBtnText}>New Vendor</Text>
        </TouchableOpacity>
      </View>

      {/* Search */}
      <View style={styles.searchRow}>
        <Ionicons name="search" size={18} color="#94a3b8" />
        <TextInput
          style={styles.searchInput}
          placeholder="Search vendor, contact, or phone..."
          placeholderTextColor="#94a3b8"
          value={search}
          onChangeText={setSearch}
        />
      </View>

      {loading ? (
        <ActivityIndicator size="large" color="#0f766e" style={{ marginTop: 40 }} />
      ) : (
        <ScrollView style={{ flex: 1 }} contentContainerStyle={styles.list} showsVerticalScrollIndicator={false}>
          {filtered.length === 0 ? (
            <View style={styles.empty}>
              <Ionicons name="briefcase-outline" size={48} color="#e2e8f0" />
              <Text style={styles.emptyText}>No suppliers found</Text>
            </View>
          ) : (
            filtered.map((supplier) => (
                <View key={supplier.id ?? supplier._id} style={styles.card}>
                  <TouchableOpacity 
                    style={{ flex: 1 }} 
                    onPress={() => openEdit(supplier)} 
                    activeOpacity={0.7}
                  >
                    <View style={styles.cardHeader}>
                      <View style={styles.vendorAvatar}>
                        <Ionicons name="business" size={20} color="#334155" />
                      </View>
                      <View style={{ flex: 1 }}>
                        <Text style={styles.vendorName}>{supplier.name}</Text>
                        <Text style={styles.contactPerson}>{supplier.contactPerson || "No contact person"}</Text>
                      </View>
                      <View style={[styles.statusBadge, { backgroundColor: supplier.status === 'ACTIVE' ? '#f0fdf4' : '#f1f5f9' }]}>
                        <Text style={[styles.statusText, { color: supplier.status === 'ACTIVE' ? '#16a34a' : '#64748b' }]}>
                          {supplier.status || "ACTIVE"}
                        </Text>
                      </View>
                    </View>

                    <View style={styles.contactInfo}>
                      <View style={styles.contactRow}>
                        <Ionicons name="call-outline" size={14} color="#64748b" />
                        <Text style={styles.contactText}>{supplier.phone}</Text>
                      </View>
                      {supplier.email ? (
                        <View style={styles.contactRow}>
                          <Ionicons name="mail-outline" size={14} color="#64748b" />
                          <Text style={styles.contactText}>{supplier.email}</Text>
                        </View>
                      ) : null}
                    </View>
                  </TouchableOpacity>
                  
                  <TouchableOpacity style={styles.archiveActionBtn} onPress={() => handleDelete(supplier)}>
                    <Ionicons name="archive-outline" size={18} color="#ef4444" />
                  </TouchableOpacity>
                </View>
            ))
          )}
        </ScrollView>
      )}

      {/* Supplier Modal */}
      <Modal visible={modalVisible} animationType="slide" transparent onRequestClose={() => setModalVisible(false)}>
        <View style={styles.modalOverlay}>
          <View style={styles.modalCard}>
            <View style={styles.modalHeader}>
              <Text style={styles.modalTitle}>{editId ? "Edit Supplier" : "Register Supplier"}</Text>
              <TouchableOpacity onPress={() => setModalVisible(false)}>
                <Ionicons name="close" size={22} color="#64748b" />
              </TouchableOpacity>
            </View>

            <ScrollView contentContainerStyle={{ gap: 14 }} showsVerticalScrollIndicator={false}>
              <View style={styles.fieldGroup}>
                <Text style={styles.fieldLabel}>Company Name *</Text>
                <TextInput style={styles.fieldInput} value={form.name} onChangeText={(v) => setForm({...form, name: v})} placeholder="Ceylon Trading Co." />
              </View>

              <View style={styles.fieldGroup}>
                <Text style={styles.fieldLabel}>Contact Person</Text>
                <TextInput style={styles.fieldInput} value={form.contactPerson} onChangeText={(v) => setForm({...form, contactPerson: v})} placeholder="John Smith" />
              </View>

              <View style={styles.row}>
                <View style={[styles.fieldGroup, { flex: 1 }]}>
                  <Text style={styles.fieldLabel}>Phone Number *</Text>
                  <TextInput style={styles.fieldInput} value={form.phone} onChangeText={(v) => setForm({...form, phone: v})} keyboardType="phone-pad" placeholder="011 234 5678" />
                </View>
                <View style={[styles.fieldGroup, { flex: 1 }]}>
                  <Text style={styles.fieldLabel}>Email Address</Text>
                  <TextInput style={styles.fieldInput} value={form.email} onChangeText={(v) => setForm({...form, email: v})} keyboardType="email-address" autoCapitalize="none" placeholder="info@ceylon.com" />
                </View>
              </View>

              <View style={styles.fieldGroup}>
                <Text style={styles.fieldLabel}>Office Address</Text>
                <TextInput style={[styles.fieldInput, { height: 60 }]} value={form.address} onChangeText={(v) => setForm({...form, address: v})} multiline placeholder="Primary warehouse or office address" />
              </View>

              <View style={styles.row}>
                <View style={[styles.fieldGroup, { flex: 1 }]}>
                  <SearchableDropdown
                    label="Supply Category"
                    placeholder="Search or add category..."
                    items={Array.from(new Set(suppliers.flatMap(s => s.supplyCategories || []))).map(c => ({ label: c, value: c }))}
                    value={Array.isArray(form.supplyCategories) ? form.supplyCategories[0] : form.supplyCategories.split(",")[0]}
                    onValueChange={(v) => setForm({...form, supplyCategories: v})}
                    allowCustom
                  />
                </View>
                <View style={[styles.fieldGroup, { flex: 1 }]}>
                  <Text style={styles.fieldLabel}>Outstanding Payable</Text>
                  <TextInput style={styles.fieldInput} value={form.outstandingPayable} onChangeText={(v) => setForm({...form, outstandingPayable: v})} keyboardType="numeric" placeholder="0.00" />
                </View>
              </View>
            </ScrollView>

            <TouchableOpacity style={styles.saveBtn} onPress={handleSave} disabled={saving} activeOpacity={0.85}>
              {saving ? <ActivityIndicator color="#fff" /> : <Text style={styles.saveBtnText}>{editId ? "Update Supplier" : "Save Supplier"}</Text>}
            </TouchableOpacity>
          </View>
        </View>
      </Modal>
    </View>
  );
}

const styles = StyleSheet.create({
  screen: { flex: 1, backgroundColor: "#f4f7fb" },
  headerCard: {
    backgroundColor: "#0f172a", margin: 16, borderRadius: 20,
    padding: 18, flexDirection: "row", alignItems: "center", gap: 14,
  },
  headerIcon: { width: 44, height: 44, borderRadius: 14, backgroundColor: "#334155", alignItems: "center", justifyContent: "center" },
  headerTitle: { color: "#fff", fontSize: 16, fontWeight: "800" },
  headerSub: { color: "#94a3b8", fontSize: 12, marginTop: 2 },
  addBtn: { flexDirection: "row", alignItems: "center", gap: 6, backgroundColor: "#0f766e", borderRadius: 12, paddingHorizontal: 16, paddingVertical: 10 },
  addBtnText: { color: "#fff", fontWeight: "700", fontSize: 13 },
  searchRow: {
    flexDirection: "row", alignItems: "center", gap: 10,
    backgroundColor: "#fff", borderRadius: 14, marginHorizontal: 16, marginBottom: 12,
    paddingHorizontal: 14, paddingVertical: 12,
    shadowColor: "#0f172a", shadowOpacity: 0.04, shadowRadius: 8, elevation: 2,
  },
  searchInput: { flex: 1, color: "#0f172a", fontSize: 14 },
  list: { padding: 16, paddingTop: 4, gap: 12 },
  empty: { alignItems: "center", paddingTop: 60, gap: 12 },
  emptyText: { color: "#94a3b8", fontSize: 14, fontWeight: "600" },
  card: {
    backgroundColor: "#fff", borderRadius: 20, padding: 16, gap: 12,
    shadowColor: "#0f172a", shadowOpacity: 0.05, shadowRadius: 10, elevation: 2,
  },
  cardHeader: { flexDirection: "row", alignItems: "center", gap: 12 },
  vendorAvatar: { width: 40, height: 40, borderRadius: 12, backgroundColor: "#f1f5f9", alignItems: "center", justifyContent: "center" },
  vendorName: { color: "#0f172a", fontWeight: "700", fontSize: 15 },
  contactPerson: { color: "#94a3b8", fontSize: 12 },
  statusBadge: { borderRadius: 8, paddingHorizontal: 8, paddingVertical: 4 },
  statusText: { fontSize: 9, fontWeight: "800", textTransform: "uppercase" },
  contactInfo: { flexDirection: "row", flexWrap: "wrap", gap: 12, borderTopWidth: 1, borderTopColor: "#f1f5f9", paddingTop: 12, alignItems: "center" },
  contactRow: { flexDirection: "row", alignItems: "center", gap: 6 },
  contactText: { color: "#64748b", fontSize: 12, fontWeight: "500" },
  archiveActionBtn: { padding: 12, backgroundColor: "#fef2f2", borderRadius: 12, marginLeft: 8 },
  row: { flexDirection: "row", gap: 12 },
  modalOverlay: { flex: 1, backgroundColor: "rgba(0,0,0,0.4)", justifyContent: "flex-end" },
  modalCard: { backgroundColor: "#fff", borderTopLeftRadius: 28, borderTopRightRadius: 28, padding: 24, gap: 18, maxHeight: "90%" },
  modalHeader: { flexDirection: "row", alignItems: "center", justifyContent: "space-between" },
  modalTitle: { color: "#0f172a", fontSize: 20, fontWeight: "800" },
  fieldGroup: { gap: 6 },
  fieldLabel: { color: "#64748b", fontSize: 11, fontWeight: "700", textTransform: "uppercase", letterSpacing: 0.8 },
  fieldInput: { backgroundColor: "#f8fafc", borderRadius: 14, paddingHorizontal: 16, paddingVertical: 14, color: "#0f172a", fontSize: 15, borderWidth: 1, borderColor: "#e2e8f0" },
  saveBtn: { backgroundColor: "#0f766e", borderRadius: 16, paddingVertical: 16, alignItems: "center", marginTop: 8 },
  saveBtnText: { color: "#fff", fontWeight: "800", fontSize: 16 },
});
