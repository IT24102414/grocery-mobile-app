import { useState } from 'react';
import { Redirect, useRouter } from 'expo-router';
import { Pressable, StyleSheet, Text, TextInput, View } from 'react-native';
import { useAuth } from '@/context/AuthContext';

export default function LoginScreen() {
  const router = useRouter();
  const { isAuthenticated, signIn } = useAuth();
  const [username, setUsername] = useState('admin');
  const [password, setPassword] = useState('admin123');
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');

  if (isAuthenticated) {
    return <Redirect href="/(tabs)" />;
  }

  const handleLogin = async () => {
    try {
      setLoading(true);
      setError('');
      await signIn({ username, password });
      router.replace('/(tabs)');
    } catch (loginError) {
      setError(loginError instanceof Error ? loginError.message : 'Login failed.');
    } finally {
      setLoading(false);
    }
  };

  return (
    <View style={styles.screen}>
      <View style={styles.glowOne} />
      <View style={styles.glowTwo} />

      <View style={styles.card}>
        <Text style={styles.kicker}>GROCERSMART</Text>
        <Text style={styles.title}>Sign in to continue</Text>
        <Text style={styles.description}>
          Access POS, inventory, cheques, credit customers, suppliers, and analytics from one place.
        </Text>

        <View style={styles.form}>
          <TextInput
            placeholder="Username"
            value={username}
            onChangeText={setUsername}
            autoCapitalize="none"
            style={styles.input}
          />
          <TextInput
            placeholder="Password"
            value={password}
            onChangeText={setPassword}
            secureTextEntry
            style={styles.input}
          />

          {error ? <Text style={styles.error}>{error}</Text> : null}

          <Pressable style={[styles.button, loading && styles.buttonDisabled]} onPress={handleLogin}>
            <Text style={styles.buttonText}>{loading ? 'Signing in...' : 'Login'}</Text>
          </Pressable>
        </View>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  screen: {
    flex: 1,
    backgroundColor: '#061120',
    justifyContent: 'center',
    padding: 20,
  },
  glowOne: {
    position: 'absolute',
    top: '12%',
    right: '-12%',
    width: 220,
    height: 220,
    borderRadius: 999,
    backgroundColor: 'rgba(59, 130, 246, 0.22)',
  },
  glowTwo: {
    position: 'absolute',
    bottom: '10%',
    left: '-16%',
    width: 260,
    height: 260,
    borderRadius: 999,
    backgroundColor: 'rgba(16, 185, 129, 0.18)',
  },
  card: {
    backgroundColor: 'rgba(15, 23, 42, 0.92)',
    borderRadius: 32,
    padding: 24,
    borderWidth: 1,
    borderColor: 'rgba(148, 163, 184, 0.18)',
  },
  kicker: {
    color: '#93c5fd',
    letterSpacing: 1.4,
    fontSize: 12,
    marginBottom: 8,
  },
  title: {
    color: '#ffffff',
    fontSize: 30,
    fontWeight: '800',
  },
  description: {
    color: '#cbd5e1',
    marginTop: 10,
    lineHeight: 22,
  },
  form: {
    marginTop: 24,
    gap: 14,
  },
  input: {
    borderRadius: 18,
    backgroundColor: '#ffffff',
    paddingHorizontal: 16,
    paddingVertical: 14,
    color: '#0f172a',
  },
  button: {
    marginTop: 6,
    borderRadius: 18,
    paddingVertical: 14,
    alignItems: 'center',
    backgroundColor: '#22c55e',
  },
  buttonDisabled: {
    opacity: 0.75,
  },
  buttonText: {
    color: '#ffffff',
    fontWeight: '800',
  },
  error: {
    color: '#fda4af',
  },
});