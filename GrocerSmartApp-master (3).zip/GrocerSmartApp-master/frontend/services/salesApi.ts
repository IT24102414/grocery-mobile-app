import { BASE_URL, getAuthToken } from "./api";

const headers = () => ({
  "Content-Type": "application/json",
  ...(getAuthToken() ? { Authorization: `Bearer ${getAuthToken()}` } : {}),
});

const apiRequest = async (path: string, init?: RequestInit) => {
  const res = await fetch(`${BASE_URL}${path}`, {
    headers: headers(),
    ...init,
  });
  const ct = res.headers.get("content-type") ?? "";
  const data = ct.includes("application/json") ? await res.json() : await res.text();
  if (!res.ok) throw new Error((data as any)?.message ?? `Request failed: ${res.status}`);
  return data;
};

export const getSales = (params?: Record<string, any>) => {
  const q = new URLSearchParams();
  if (params) Object.entries(params).forEach(([k, v]) => v != null && q.set(k, String(v)));
  return apiRequest(`/sales?${q}`);
};

export const createSale = (data: any) =>
  apiRequest("/sales", { method: "POST", body: JSON.stringify(data) });

export const updateSale = (id: string, data: any) =>
  apiRequest(`/sales/${id}`, { method: "PUT", body: JSON.stringify(data) });

export const deleteSale = (id: string) =>
  apiRequest(`/sales/${id}`, { method: "DELETE" });

export const confirmSale = (id: string) =>
  apiRequest(`/sales/${id}/confirm`, { method: "POST" });

export const getDailySalesStats = (from: string, to: string) =>
  apiRequest(`/sales/stats/daily?from=${from}&to=${to}`);

export const getTopProductsStats = (from: string, to: string, limit = 5) =>
  apiRequest(`/sales/stats/top-products?from=${from}&to=${to}&limit=${limit}`);
