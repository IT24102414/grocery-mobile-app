import { BASE_URL, getAuthToken } from "./api";

const headers = () => ({
  "Content-Type": "application/json",
  ...(getAuthToken() ? { Authorization: `Bearer ${getAuthToken()}` } : {}),
});

const apiRequest = async (path: string, init?: RequestInit) => {
  const res = await fetch(`${BASE_URL}${path}`, {
    headers: headers(),
    ...init,
  });
  
  const ct = res.headers.get("content-type") ?? "";
  const data = ct.includes("application/json") ? await res.json() : await res.text();
  
  if (!res.ok) throw new Error((data as any)?.message ?? `Request failed: ${res.status}`);
  
  // Unwrap if it's in the standard envelope
  return data.data !== undefined ? data.data : data;
};

export const getSalesTargets = () => apiRequest("/analytics/targets");

export const setSalesTarget = (data: { month: string; targetAmount: number; category?: string }) =>
  apiRequest("/analytics/targets", { method: "POST", body: JSON.stringify(data) });

export const updateSalesTarget = (id: string, data: any) =>
  apiRequest(`/analytics/targets/${id}`, { method: "PUT", body: JSON.stringify(data) });

export const deleteSalesTarget = (id: string) =>
  apiRequest(`/analytics/targets/${id}`, { method: "DELETE" });

export const getFinancialSummary = () => apiRequest("/analytics/summary");

// Helper to get analytics data from existing endpoints if needed, 
// or you could add a dedicated /analytics/dashboard endpoint on the backend.
