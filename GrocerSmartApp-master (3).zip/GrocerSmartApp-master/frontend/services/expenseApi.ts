import { BASE_URL, getAuthToken } from "./api";

const headers = () => ({
  "Content-Type": "application/json",
  ...(getAuthToken() ? { Authorization: `Bearer ${getAuthToken()}` } : {}),
});

const apiRequest = async (path: string, init?: RequestInit) => {
  const res = await fetch(`${BASE_URL}${path}`, {
    headers: headers(),
    ...init,
  });
  const ct = res.headers.get("content-type") ?? "";
  const data = ct.includes("application/json") ? await res.json() : await res.text();
  if (!res.ok) throw new Error((data as any)?.message ?? `Request failed: ${res.status}`);
  return data.data !== undefined ? data.data : data;
};

export const getExpenses = () => apiRequest("/expenses");

export const createExpense = (data: any) =>
  apiRequest("/expenses", { method: "POST", body: JSON.stringify(data) });

export const updateExpense = (id: string, data: any) =>
  apiRequest(`/expenses/${id}`, { method: "PUT", body: JSON.stringify(data) });

export const deleteExpense = (id: string) =>
  apiRequest(`/expenses/${id}`, { method: "DELETE" });
