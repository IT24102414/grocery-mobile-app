const BASE_URL =
  process.env.EXPO_PUBLIC_API_BASE_URL?.replace(/\/$/, "") ?? "https://grocersmart-backend-production.up.railway.app/api";

let authToken: string | null = null;

export function setAuthToken(token: string | null) {
  authToken = token;
}

export function getAuthToken() {
  return authToken;
}

type ApiEnvelope<T> = {
  success?: boolean;
  message?: string;
  data?: T;
  details?: unknown;
  content?: T;
};

function unwrapResponse<T>(payload: unknown): T {
  if (payload && typeof payload === "object") {
    const envelope = payload as ApiEnvelope<T> & Record<string, unknown>;
    if ("data" in envelope) {
      return envelope.data as T;
    }
    if ("content" in envelope) {
      return envelope.content as T;
    }
  }

  return payload as T;
}

async function request<T>(path: string, init?: RequestInit): Promise<T> {
  const response = await fetch(`${BASE_URL}${path}`, {
    headers: {
      "Content-Type": "application/json",
      ...(authToken ? { Authorization: `Bearer ${authToken}` } : {}),
      ...(init?.headers ?? {}),
    },
    ...init,
  });

  const contentType = response.headers.get("content-type") ?? "";
  const payload = contentType.includes("application/json")
    ? await response.json()
    : await response.text();

  if (!response.ok) {
    if (payload && typeof payload === "object" && "message" in payload) {
      throw new Error(
        String(
          (payload as Record<string, unknown>).message ??
            `Request failed with status ${response.status}`,
        ),
      );
    }

    if (typeof payload === "string" && payload.trim()) {
      throw new Error(payload);
    }

    throw new Error(`Request failed with status ${response.status}`);
  }

  if (response.status === 204) {
    return undefined as T;
  }

  return unwrapResponse<T>(payload);
}

export async function getResourceList<T>(endpoint: string): Promise<T[]> {
  try {
    const payload = await request<unknown>(endpoint);

    if (Array.isArray(payload)) {
      return payload as T[];
    }

    if (payload && typeof payload === "object") {
      const value = payload as { content?: T[]; data?: T[] };
      if (Array.isArray(value.content)) {
        return value.content;
      }
      if (Array.isArray(value.data)) {
        return value.data;
      }
    }

    return [];
  } catch (error) {
    console.error(`Error fetching ${endpoint}:`, error);
    return [];
  }
}

export async function getResource<T>(endpoint: string): Promise<T | null> {
  try {
    return await request<T>(endpoint);
  } catch (error) {
    console.error(`Error fetching ${endpoint}:`, error);
    return null;
  }
}

export async function createResource<T>(
  endpoint: string,
  payload: Record<string, unknown>,
): Promise<T> {
  return request<T>(endpoint, {
    method: "POST",
    body: JSON.stringify(payload),
  });
}

export async function updateResource<T>(
  endpoint: string,
  id: string,
  payload: Record<string, unknown>,
): Promise<T> {
  return request<T>(`${endpoint}/${id}`, {
    method: "PUT",
    body: JSON.stringify(payload),
  });
}

export async function deleteResource(
  endpoint: string,
  id: string,
): Promise<void> {
  await request<void>(`${endpoint}/${id}`, {
    method: "DELETE",
  });
}

export const getOrders = async () => getResourceList<any>("/orders");

export const createOrder = async (order: any) =>
  createResource("/orders", order);

export const deleteOrder = async (id: string) => deleteResource("/orders", id);

export const updateOrder = async (id: string, data: any) =>
  updateResource("/orders", id, data);

export { BASE_URL };

