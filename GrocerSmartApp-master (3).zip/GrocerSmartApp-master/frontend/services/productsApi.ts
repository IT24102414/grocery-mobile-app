import { BASE_URL, getAuthToken } from "./api";

const headers = () => ({
  "Content-Type": "application/json",
  ...(getAuthToken() ? { Authorization: `Bearer ${getAuthToken()}` } : {}),
});

const apiRequest = async (path: string, init?: RequestInit) => {
  const res = await fetch(`${BASE_URL}${path}`, {
    headers: headers(),
    ...init,
  });
  const ct = res.headers.get("content-type") ?? "";
  const data = ct.includes("application/json") ? await res.json() : await res.text();
  if (!res.ok) throw new Error((data as any)?.message ?? `Request failed: ${res.status}`);
  return data;
};

export const getProducts = (params?: Record<string, any>) => {
  const q = new URLSearchParams();
  if (params) Object.entries(params).forEach(([k, v]) => v != null && q.set(k, String(v)));
  return apiRequest(`/products?${q}`);
};

export const createProduct = (data: any) =>
  apiRequest("/products", { method: "POST", body: JSON.stringify(data) });

export const updateProduct = (id: string, data: any) =>
  apiRequest(`/products/${id}`, { method: "PUT", body: JSON.stringify(data) });

export const deleteProduct = (id: string) =>
  apiRequest(`/products/${id}`, { method: "DELETE" });

export const convertStock = (data: any) =>
  apiRequest("/inventory/convert", { method: "POST", body: JSON.stringify(data) });
