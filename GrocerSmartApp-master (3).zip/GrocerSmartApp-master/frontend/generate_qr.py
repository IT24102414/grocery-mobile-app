import qrcode
from PIL import Image

url = "exp://u.expo.dev/0c0fa6f0-9bb3-475c-b300-a42a10cdafaa?group=4c2a4ad6-d7ec-4617-91b8-4aadd00ee00c"
qr = qrcode.QRCode(version=1, box_size=10, border=5)
qr.add_data(url)
qr.make(fit=True)

img = qr.make_image(fill_color="black", back_color="white")
img.save("/Users/chemini/.gemini/antigravity/brain/a1282c9d-d6c2-4411-95a5-e72912bb25ff/expo_qr.png")
print("QR code saved to /Users/chemini/.gemini/antigravity/brain/a1282c9d-d6c2-4411-95a5-e72912bb25ff/expo_qr.png")
