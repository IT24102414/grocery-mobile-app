# API Documentation - GrocerSmart System

This document provides a comprehensive list of all API endpoints implemented in the GrocerSmart backend.

## Authentication Module
| Method | Endpoint | Description | Access |
| :--- | :--- | :--- | :--- |
| `POST` | `/api/auth/login` | Authenticates a user and returns a JWT token. | Public |
| `GET` | `/api/auth/status` | Connectivity and system status check. | Public |

## Product & Inventory Management
| Method | Endpoint | Description | Access |
| :--- | :--- | :--- | :--- |
| `GET` | `/api/products` | Retrieve all active products (paginated). | Authenticated |
| `POST` | `/api/products` | Create a new product. | Admin/Manager |
| `GET` | `/api/products/:id`| Get detailed information for a specific product. | Authenticated |
| `PUT` | `/api/products/:id`| Update an existing product. | Admin/Manager |
| `DELETE`| `/api/products/:id`| Archive (soft-delete) a product. | Admin/Manager |
| `GET` | `/api/products/search`| Search products by name, SKU, or public ID. | Authenticated |
| `POST` | `/api/products/bulk-import`| Bulk import products via JSON payload. | Admin/Manager |
| `POST` | `/api/products/convert`| Convert bulk units into retail stock. | Admin/Manager |

## Sales & Purchase Order Management
| Method | Endpoint | Description | Access |
| :--- | :--- | :--- | :--- |
| `GET` | `/api/sales` | List all sales transactions. | Authenticated |
| `POST` | `/api/sales` | Initialize a new sale (POS). | Authenticated |
| `PUT` | `/api/sales/:id/confirm`| Finalize a sale and deduct inventory. | Authenticated |
| `GET` | `/api/purchase-orders` | List all procurement orders. | Authenticated |
| `POST` | `/api/purchase-orders` | Create a new purchase order. | Authenticated |
| `PUT` | `/api/purchase-orders/:id/receive`| Mark order as received and update stock. | Authenticated |
| `GET` | `/api/sales/analytics/daily`| Get daily sales statistics. | Authenticated |
| `GET` | `/api/sales/analytics/top-products`| Get top selling products analysis. | Authenticated |

## Supplier Management
| Method | Endpoint | Description | Access |
| :--- | :--- | :--- | :--- |
| `GET` | `/api/suppliers` | List all registered suppliers. | Authenticated |
| `POST` | `/api/suppliers` | Add a new business supplier. | Admin/Manager |
| `GET` | `/api/suppliers/summary`| Get summary stats (total payable, active count). | Authenticated |
| `PUT` | `/api/suppliers/:id`| Update supplier contact/business details. | Admin/Manager |
| `DELETE`| `/api/suppliers/:id`| Archive a supplier record. | Admin/Manager |

## Credit Customer Management
| Method | Endpoint | Description | Access |
| :--- | :--- | :--- | :--- |
| `GET` | `/api/credit-customers`| List all customers with credit accounts. | Authenticated |
| `POST` | `/api/credit-customers`| Register a new credit customer. | Authenticated |
| `GET` | `/api/credit-customers/:id/ledger`| Get transaction history/ledger for a customer. | Authenticated |
| `POST` | `/api/credit-customers/:id/payments`| Record a debt repayment. | Authenticated |
| `POST` | `/api/credit-customers/:id/calculate-risk`| Calculate AI-based credit risk score. | Authenticated |

## Bank & Cheque Management
| Method | Endpoint | Description | Access |
| :--- | :--- | :--- | :--- |
| `GET` | `/api/cheques` | List all recorded cheques. | Authenticated |
| `POST` | `/api/cheques` | Record a new cheque payment. | Authenticated |
| `PUT` | `/api/cheques/:id/status`| Update cheque status (CLEARED, BOUNCED, etc).| Authenticated |
| `GET` | `/api/cheques/summary`| Get summary of pending vs cleared cheques. | Authenticated |

## System Administration & User Management
| Method | Endpoint | Description | Access |
| :--- | :--- | :--- | :--- |
| `GET` | `/api/users` | List all system users. | Admin |
| `POST` | `/api/users` | Register a new staff member. | Admin |
| `PATCH`| `/api/users/:id/permissions`| Update RBAC permissions for a user. | Admin |
| `GET` | `/api/users/:id/activity-logs`| Audit trail of user actions. | Admin |

## Trash & Recovery
| Method | Endpoint | Description | Access |
| :--- | :--- | :--- | :--- |
| `GET` | `/api/trash` | List all soft-deleted records. | Admin |
| `POST` | `/api/trash/:type/:id/restore`| Restore an archived item. | Admin |
| `DELETE`| `/api/trash/:type/:id/permanent`| Purge a record permanently. | Admin |

## Reporting & PDF Exports
| Method | Endpoint | Description | Access |
| :--- | :--- | :--- | :--- |
| `GET` | `/api/reports/sales/pdf` | Export sales report as PDF. | Authenticated |
| `GET` | `/api/reports/inventory/pdf`| Export current stock levels as PDF. | Authenticated |
| `GET` | `/api/reports/suppliers/:id/pdf`| Export supplier profile and history as PDF. | Authenticated |
| `GET` | `/api/reports/credit-customers/:id/ledger.pdf`| Export customer ledger as PDF. | Authenticated |

## Advanced Analytics & Financial Health
| Method | Endpoint | Description | Access |
| :--- | :--- | :--- | :--- |
| `GET` | `/api/analytics/summary` | Get P&L summary (Revenue, COGS, Expenses, Net Profit). | Authenticated |
| `GET` | `/api/analytics/targets` | List all monthly revenue/sales targets. | Authenticated |
| `POST` | `/api/analytics/targets` | Set a new monthly revenue goal. | Admin/Manager |
| `PUT` | `/api/analytics/targets/:id`| Update a specific monthly target amount. | Admin/Manager |
| `DELETE`| `/api/analytics/targets/:id`| Remove a sales target record. | Admin/Manager |

## Expense Management
| Method | Endpoint | Description | Access |
| :--- | :--- | :--- | :--- |
| `GET` | `/api/expenses` | List all recorded business expenses. | Authenticated |
| `POST` | `/api/expenses` | Record a new expense (Rent, Salaries, etc). | Authenticated |
| `PUT` | `/api/expenses/:id` | Update an existing expense record. | Authenticated |
| `DELETE`| `/api/expenses/:id` | Remove an expense record. | Authenticated |

