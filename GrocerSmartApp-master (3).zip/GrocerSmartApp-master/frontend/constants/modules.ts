import { Ionicons } from "@expo/vector-icons";
import type { ComponentProps } from "react";

export type IconName = ComponentProps<typeof Ionicons>["name"];

export type ResourceField = {
  key: string;
  label: string;
  placeholder: string;
  keyboardType?: "default" | "numeric" | "email-address" | "phone-pad";
  multiline?: boolean;
};

export type ResourceConfig = {
  key: string;
  title: string;
  description: string;
  endpoint: string;
  icon: IconName;
  accent: string;
  emptyMessage: string;
  titleField: string;
  summaryFields: string[];
  fields: ResourceField[];
  buildPayload: (values: Record<string, string>) => Record<string, unknown>;
  hydrateValues: (
    record?: Record<string, unknown> | null,
  ) => Record<string, string>;
};

const readNestedString = (
  record: Record<string, unknown> | null | undefined,
  key: string,
  fallback = "",
) => {
  return String(record?.[key] ?? fallback);
};

const readNestedNumber = (
  record: Record<string, unknown> | null | undefined,
  key: string,
  fallback = 0,
) => {
  const parsed = Number(record?.[key] ?? fallback);
  return String(Number.isFinite(parsed) ? parsed : fallback);
};

export const resourceConfigs: ResourceConfig[] = [
  {
    key: "inventory",
    title: "Inventory",
    description: "Product master data and stock levels",
    endpoint: "/products",
    icon: "cube",
    accent: "#1d4ed8",
    emptyMessage: "No products found.",
    titleField: "name",
    summaryFields: ["category", "unitPrice", "bulkPrice", "reorderPoint"],
    fields: [
      { key: "name", label: "Product Name", placeholder: "Cooking Oil" },
      { key: "category", label: "Category", placeholder: "Groceries" },
      { key: "unitPrice", label: "Unit Price", placeholder: "0", keyboardType: "numeric" },
      { key: "bulkPrice", label: "Bulk Price", placeholder: "0", keyboardType: "numeric" },
      { key: "purchasePrice", label: "Purchase Price", placeholder: "0", keyboardType: "numeric" },
      { key: "bulkUnit", label: "Bulk Unit", placeholder: "Case" },
      { key: "retailUnit", label: "Retail Unit", placeholder: "Piece" },
      { key: "conversionFactor", label: "Conversion Factor", placeholder: "1", keyboardType: "numeric" },
      { key: "bulkQty", label: "Bulk Quantity", placeholder: "0", keyboardType: "numeric" },
      { key: "retailQty", label: "Retail Quantity", placeholder: "0", keyboardType: "numeric" },
      { key: "reorderPoint", label: "Reorder Point", placeholder: "10", keyboardType: "numeric" },
      { key: "status", label: "Status", placeholder: "ACTIVE / DISCONTINUED" },
    ],
    buildPayload: (values) => ({
      name: values.name,
      category: values.category,
      unitPrice: Number(values.unitPrice || 0),
      bulkPrice: Number(values.bulkPrice || 0),
      purchasePrice: Number(values.purchasePrice || 0),
      unitConfig: {
        bulkUnit: values.bulkUnit || "Case",
        retailUnit: values.retailUnit || "Piece",
        conversionFactor: Number(values.conversionFactor || 1),
      },
      stockLevels: {
        bulkQty: Number(values.bulkQty || 0),
        retailQty: Number(values.retailQty || 0),
      },
      reorderPoint: Number(values.reorderPoint || 10),
      status: values.status || "ACTIVE",
    }),
    hydrateValues: (record = null) => ({
      name: readNestedString(record, "name"),
      category: readNestedString(record, "category"),
      unitPrice: readNestedNumber(record, "unitPrice"),
      bulkPrice: readNestedNumber(record, "bulkPrice"),
      purchasePrice: readNestedNumber(record, "purchasePrice"),
      bulkUnit: String((record?.unitConfig as any)?.bulkUnit ?? "Case"),
      retailUnit: String((record?.unitConfig as any)?.retailUnit ?? "Piece"),
      conversionFactor: String((record?.unitConfig as any)?.conversionFactor ?? 1),
      bulkQty: String((record?.stockLevels as any)?.bulkQty ?? 0),
      retailQty: String((record?.stockLevels as any)?.retailQty ?? 0),
      reorderPoint: readNestedNumber(record, "reorderPoint", 10),
      status: readNestedString(record, "status", "ACTIVE"),
    }),
  },
  {
    key: "cheques",
    title: "Cheques",
    description: "Incoming and outgoing cheque tracking",
    endpoint: "/cheques",
    icon: "document-text",
    accent: "#b45309",
    emptyMessage: "No cheques recorded yet.",
    titleField: "chequeNumber",
    summaryFields: ["bankName", "amount", "dueDate", "status"],
    fields: [
      { key: "chequeNumber", label: "Cheque Number", placeholder: "123456" },
      { key: "bankName", label: "Bank Name", placeholder: "Bank name" },
      { key: "branch", label: "Branch", placeholder: "Branch name" },
      { key: "chequeType", label: "Cheque Type", placeholder: "Incoming / Outgoing" },
      { key: "amount", label: "Amount", placeholder: "0", keyboardType: "numeric" },
      { key: "issueDate", label: "Issue Date", placeholder: "YYYY-MM-DD" },
      { key: "dueDate", label: "Due Date", placeholder: "YYYY-MM-DD" },
      { key: "status", label: "Status", placeholder: "PENDING / DEPOSITED / CLEARED / BOUNCED" },
      { key: "customerId", label: "Customer ID", placeholder: "Optional credit customer ID" },
      { key: "note", label: "Note", placeholder: "Optional note", multiline: true },
    ],
    buildPayload: (values) => ({
      chequeNumber: values.chequeNumber,
      bankName: values.bankName,
      branch: values.branch,
      chequeType: values.chequeType || "Incoming",
      amount: Number(values.amount || 0),
      issueDate: values.issueDate,
      dueDate: values.dueDate,
      status: values.status || "PENDING",
      customerId: values.customerId || undefined,
      note: values.note || undefined,
    }),
    hydrateValues: (record = null) => ({
      chequeNumber: readNestedString(record, "chequeNumber"),
      bankName: readNestedString(record, "bankName"),
      branch: readNestedString(record, "branch"),
      chequeType: readNestedString(record, "chequeType", "Incoming"),
      amount: readNestedNumber(record, "amount"),
      issueDate: record?.issueDate ? String(record.issueDate).slice(0, 10) : "",
      dueDate: record?.dueDate ? String(record.dueDate).slice(0, 10) : "",
      status: readNestedString(record, "status", "PENDING"),
      customerId: readNestedString(record, "customerId"),
      note: readNestedString(record, "note"),
    }),
  },
  {
    key: "credit-customers",
    title: "Credit Customers",
    description: "Outstanding balances and recovery",
    endpoint: "/credit-customers",
    icon: "people",
    accent: "#7c3aed",
    emptyMessage: "No credit customers found.",
    titleField: "name",
    summaryFields: ["phone", "creditLimit", "currentBalance", "status"],
    fields: [
      { key: "name", label: "Customer Name", placeholder: "John Silva" },
      { key: "phone", label: "Phone", placeholder: "+94...", keyboardType: "phone-pad" },
      { key: "address", label: "Address", placeholder: "Optional address", multiline: true },
      { key: "creditLimit", label: "Credit Limit", placeholder: "0", keyboardType: "numeric" },
      { key: "paymentTermsDays", label: "Payment Terms Days", placeholder: "30", keyboardType: "numeric" },
      { key: "customerType", label: "Customer Type", placeholder: "CREDIT / CASH" },
      { key: "status", label: "Status", placeholder: "ACTIVE / INACTIVE" },
    ],
    buildPayload: (values) => ({
      name: values.name,
      phone: values.phone,
      address: values.address,
      creditLimit: Number(values.creditLimit || 0),
      paymentTermsDays: Number(values.paymentTermsDays || 30),
      customerType: values.customerType || "CREDIT",
      status: values.status || "ACTIVE",
    }),
    hydrateValues: (record = null) => ({
      name: readNestedString(record, "name"),
      phone: readNestedString(record, "phone"),
      address: readNestedString(record, "address"),
      creditLimit: readNestedNumber(record, "creditLimit"),
      paymentTermsDays: readNestedNumber(record, "paymentTermsDays", 30),
      customerType: readNestedString(record, "customerType", "CREDIT"),
      status: readNestedString(record, "status", "ACTIVE"),
    }),
  },
  {
    key: "suppliers",
    title: "Suppliers",
    description: "Vendor records and contact details",
    endpoint: "/suppliers",
    icon: "briefcase",
    accent: "#334155",
    emptyMessage: "No suppliers added yet.",
    titleField: "name",
    summaryFields: ["contactPerson", "phone", "outstandingPayable", "status"],
    fields: [
      { key: "name", label: "Supplier Name", placeholder: "ABC Traders" },
      { key: "contactPerson", label: "Contact Person", placeholder: "Supplier rep" },
      { key: "phone", label: "Phone", placeholder: "+94...", keyboardType: "phone-pad" },
      { key: "email", label: "Email", placeholder: "supplier@example.com", keyboardType: "email-address" },
      { key: "address", label: "Address", placeholder: "Supplier address", multiline: true },
    ],
    buildPayload: (values) => ({
      name: values.name,
      contactPerson: values.contactPerson,
      phone: values.phone,
      email: values.email,
      address: values.address,
      status: "ACTIVE",
    }),
    hydrateValues: (record = null) => ({
      name: readNestedString(record, "name"),
      contactPerson: readNestedString(record, "contactPerson"),
      phone: readNestedString(record, "phone"),
      email: readNestedString(record, "email"),
      address: readNestedString(record, "address"),
    }),
  },
];

export const resourceConfigMap = Object.fromEntries(
  resourceConfigs.map((config) => [config.key, config]),
) as Record<string, ResourceConfig>;

// ALL Dashboard Modules (Finalized List)
export const dashboardCards = [
  { key: "pos", title: "Point of Sale", description: "Cart & Checkout", icon: "cart" as IconName, accent: "#0f766e" },
  { key: "inventory", title: "Products", description: "Stock Control", icon: "cube" as IconName, accent: "#1d4ed8" },
  { key: "convert-stock", title: "Stock Conversion", description: "Bulk to Retail", icon: "swap-horizontal" as IconName, accent: "#7c3aed" },
  { key: "credit-customers", title: "Credit Recovery", description: "Debt Management", icon: "people" as IconName, accent: "#7c3aed" },
  { key: "cheques", title: "Cheques", description: "Banking Logic", icon: "document-text" as IconName, accent: "#b45309" },
  { key: "suppliers", title: "Suppliers", description: "Procurement", icon: "briefcase" as IconName, accent: "#334155" },
  { key: "purchase-orders", title: "Purchase Orders", description: "Supply Chain", icon: "cart-outline" as IconName, accent: "#b45309" },
  { key: "analytics", title: "Analytics", description: "Business Insights", icon: "bar-chart" as IconName, accent: "#0369a1" },
  { key: "reports", title: "Reports", description: "PDF Export", icon: "document-attach" as IconName, accent: "#0369a1" },
  { key: "users", title: "Staff Members", description: "Access Control", icon: "people-circle" as IconName, accent: "#dc2626" },
  { key: "trash", title: "Trash Bin", description: "Restore Deleted", icon: "trash" as IconName, accent: "#ef4444" },
  { key: "settings", title: "System Setup", description: "App Configuration", icon: "settings" as IconName, accent: "#475569" },
];
