// Order data model for POS module

export type OrderStatus = 'pending' | 'completed' | 'cancelled';

export interface OrderItem {
  productId: string; // Reference to product module
  quantity: number;
  price: number;
}

export interface Order {
  id: string;
  customerId: string; // Reference to credit customers module
  items: OrderItem[];
  total: number;
  status: OrderStatus;
  createdAt: string;
  updatedAt?: string;
}

// Updated validation function to include stricter checks
export function validateOrder(order: Partial<Order>): string[] {
  const errors: string[] = [];

  if (!order.customerId || order.customerId.trim() === '') {
    errors.push('Customer ID is required.');
  }

  if (!order.items || order.items.length === 0) {
    errors.push('At least one item is required.');
  } else {
    order.items.forEach((item, idx) => {
      if (!item.productId || item.productId.trim() === '') {
        errors.push(`Product ID is required for item #${idx + 1}.`);
      }
      if (!item.quantity || item.quantity <= 0) {
        errors.push(`Quantity must be greater than 0 for item #${idx + 1}.`);
      }
      if (!item.price || item.price < 0) {
        errors.push(`Price must be 0 or greater for item #${idx + 1}.`);
      }
    });
  }

  return errors;
}
