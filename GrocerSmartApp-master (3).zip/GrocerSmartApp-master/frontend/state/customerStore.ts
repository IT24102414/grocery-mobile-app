import create from 'zustand';

export type Customer = {
  id: string;
  name: string;
  email: string;
  phone: string;
};

type CustomerState = {
  customers: Customer[];
  addCustomer: (customer: Customer) => void;
  getCustomerById: (id: string) => Customer | undefined;
};

export const useCustomerStore = create<CustomerState>((set) => ({
  customers: [],

  addCustomer: (customer) =>
    set((state) => ({
      customers: [...state.customers, customer],
    })),

  getCustomerById: (id) => {
    return (state.customers.find((customer) => customer.id === id));
  },
}));