import create from 'zustand';

export type Product = {
  id: string;
  name: string;
  price: number;
  stock: number;
};

type ProductState = {
  products: Product[];
  addProduct: (product: Product) => void;
  getProductById: (id: string) => Product | undefined;
};

export const useProductStore = create<ProductState>((set) => ({
  products: [],

  addProduct: (product) =>
    set((state) => ({
      products: [...state.products, product],
    })),

  getProductById: (id) => {
    return (state.products.find((product) => product.id === id));
  },
}));